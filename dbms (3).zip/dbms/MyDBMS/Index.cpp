#include "Index.h"


Index::Index(Ui::cmd *ui): ui(ui)
{

}
//  0      1       2          3      4       5
//create index xxx(indexname) on tablename (列名)



void Index::build_Index_File(QStringList &strList,QString currentPath){
    QStringList fieldList;
    QString str = strList.join(" ");//把字符串数组重新变回QString,为了找出（）中间的列名，相当于恢复之前的命令语句
    int index1 = str.indexOf('(');//第一个出现的‘（’
    int index2 = str.lastIndexOf(')');//查找最后出现的一个‘）’
    QString result = str.mid(index1+1, index2-index1-1);//找到（ ）中间的语句

    if(strList[3].compare("on")!=0)//格式不对
        ui->plainTextEdit->appendPlainText("Wrong Sentence;");
    else{

        QString Index_File_Name=strList[2];//索引名
        QString tablename=strList[4].mid(0,strList[4].indexOf('('));//获取表名
        QStringList ColumnName=result.split(",");//把中间的命令用，拆分,也就是拆分为一个个列名（创建多个索引时）

        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
             ui->plainTextEdit->appendPlainText("Please select database first;");
        }
        else//已经选择了使用的数据库
        {

            QString Index_FolderPath = currentPath+"/"+tablename+".ix";//索引文件夹的路径
            QDir dir(Index_FolderPath);
            QFile frm_File(currentPath+"/"+tablename+".frm");//数据定义文件的路径;
            QFile trd_File(currentPath+"/"+tablename+".trd");//数据存储文件的路径;


            if (dir.exists()) {//如果该索引文件夹已经存在
            }
            else//之前不存在，需要新建
            {
               if (!dir.mkpath(".")) {//if语句判断dir.mkpath(".")的返回值是否为真。如果为真，则索引文件夹创建成功
                   ui->plainTextEdit->appendPlainText("Failed to create Index_Folder;");
                   return;
               }
            }

            //打开数据定义文件
            if (!frm_File.exists()) //如果数据结构文件不存在
            {
                ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                return;
            }
            else{//之前已经创建过这个表，可以查询他的结构
                if (frm_File.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
                {
                    QTextStream in(&frm_File); // 使用QTextStream读取文件内容
                    while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line = in.readLine(); // 一行一行读取内容
                        QStringList List = line.split(" ");//根据空格拆分
                        fieldList<<List[0];//把每个属性名称追加到字符串数组中
                    }
                    frm_File.close(); // 关闭文件
                 }
             }
            for (const QString &strColumn : ColumnName) {//遍历ColumnName
                int flag=0;
                foreach(QString str, fieldList) {//属性名容错
                    if (str == strColumn)
                        flag=1;
                }
                if(flag==0){
                    ui->plainTextEdit->appendPlainText("this column doesnot exits;");
                    return;
                }

                QFile Index_File(Index_FolderPath+"/"+Index_File_Name+" "+strColumn);//索引文件的路径;
                if (Index_File.exists()) // 检查数据结构文件是否已经存在
                {
                    ui->plainTextEdit->appendPlainText("This index has already exists;");
                    return;
                }
                else
                {
                    if (Index_File.open(QIODevice::WriteOnly)| QIODevice::Text)//文件创建成功,以文本模式打开
                    {
                        QTextStream stream(&Index_File); //创建一个 QTextStream 对象，并关联文件

                        std::vector<data> dataList;
                        int columnIndex = 0; // 初始化行数
                        foreach(QString str, fieldList) {//找到对应的位置，从而在trd文件中确定是第几列
                                // 检查当前字符串是否与目标字符串相等
                                if (str == strColumn) {

                                    //确定好行数后需要去trd文件中查找
                                    if (!trd_File.exists()) //如果现在还没有插入数据
                                    {

                                        ui->plainTextEdit->appendPlainText("This table's data has not exists;");
                                        return;
                                    }
                                    else{
                                        if (trd_File.open(QIODevice::ReadOnly)) //打开文件
                                        {
                                            QTextStream in(&trd_File); // 使用QTextStream读取文件内容
                                            int rowIndex=0;
                                            while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
                                            {
                                                QString row = in.readLine(); // 一行一行读取内容
                                                QStringList rowList = row.split(",");//根据逗号拆分
                                                data d={rowList[columnIndex],rowIndex};
                                                dataList.push_back(d);//把该列的数据加到dataList（结构体数组）中
                                                rowIndex++;
                                            }
                                            trd_File.close(); // 关闭文件
                                         }
                                     }


                                    break; // 找到目标后，可以选择退出循环
                                }
                                ++columnIndex; // 增加行数
                         }

                        // 对向量中的元素按照content成员升序排列
                        sort(dataList.begin(), dataList.end(), compareData);

        //                for (const auto& test : dataList) {
        //                        qDebug()<< test.content << " " << test.rownumber;
        //                    }

                        //把要建立索引的关键词和它所对应的行数写入索引文件中
                        for(int i=0;i<dataList.size();i++)
                           stream<<dataList[i].content<<" "<<dataList[i].rownumber<< endl;//在行末添加换行符

                        Index_File.close();

                    }
                    else
                    {
                        ui->plainTextEdit->appendPlainText("Failed to create this index;");
                     }


            }
        }
            ui->plainTextEdit->appendPlainText("successfully create this index;");


}

        }
}

//DROP INDEX index_name ON table_name;
void Index::drop_Index(QStringList &strList,QString currentPath,int defaultValue){
    qDebug() << "到drop了";
    if(strList.size()!=5||strList[3].compare("on")!=0)//格式不对
        ui->plainTextEdit->appendPlainText("Wrong Sentence;");
    else{
        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
             ui->plainTextEdit->appendPlainText("Please select database first;");
        }
        else//已经选择了使用的数据库
        {
            QString table_name=strList[4];
            QString index_name=strList[2];
            QString Index_FolderPath = currentPath+"/"+table_name+".ix";//索引文件夹的路径
            QDir dir(Index_FolderPath);

            if (!dir.exists()) {//如果该索引文件夹不存在
                ui->plainTextEdit->appendPlainText("Failed to drop this index;");
            }
            else{
                QStringList filters; // 创建字符串列表，用于过滤文件名

                filters << "*" + index_name + "*"; // 将包含指定字符串的文件名添加到过滤列表中，使用通配符"*"匹配字符串任意位置
                dir.setNameFilters(filters); // 设置目录的文件名过滤器
                dir.setFilter(QDir::Files | QDir::NoSymLinks); // 设置目录过滤器，只获取普通文件，不包括符号链接

                QFileInfoList fileList = dir.entryInfoList(); // 获取符合过滤条件的文件信息列表
                if (fileList.isEmpty()) { // 如果文件列表为空
                    ui->plainTextEdit->appendPlainText("this index doesn't exists;");
                }
                else{
                    // 遍历文件信息列表
                    foreach (QFileInfo fileInfo, fileList) {
                    // 获取文件路径
                    QString filePath = fileInfo.filePath();
                    // 删除文件
                    if (QFile::remove(filePath)) {
                       ui->plainTextEdit->appendPlainText("succeed to drop this index;");
                    } else {
                       ui->plainTextEdit->appendPlainText("Failed to drop this index;");
                    }
                    }
                }

                //更新创建索引语句文件，通过删除索引名来删除指定表名.txt文件下相关create语句
                //为1说明是通过默认命令行删除，则更新文件，否则，若为0说明是在重创索引，不可以修改然后create，否则会造成索引文件丢失
                if(defaultValue == 1) {
                    // 读取原始索引语句文件
                    QString filePath = currentPath + "/" + table_name + ".txt";
                    QFile file(filePath);
                    if (!file.open(QIODevice::ReadWrite | QIODevice::Text)) {
                        ui->plainTextEdit->appendPlainText("Failed to open index file for update;");
                        return;
                    }
                    QTextStream in(&file);
                    QStringList indexStatements;
                    while (!in.atEnd()) {
                        QString line = in.readLine();
                        // 检查是否包含指定表名和索引名，不包含则添加到列表中
                        if (!line.contains(index_name) || !line.contains(table_name)) {
                            indexStatements.append(line);
                        }
                    }
                    file.close();

                    // 将更新后的语句重新写入到文件中
                    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text)) {
                        ui->plainTextEdit->appendPlainText("Failed to open index file for update;");
                        return;
                    }

                    QTextStream out(&file);
                    for (const QString& statement : indexStatements) {
                        out << statement << "\n";
                    }
                    file.close();
                }
            }
        }
    }
}

bool Index::build_struct(QString currentPath,QString tablename,QString attribute,QString value,int &rownum){
    QString Index_FolderPath = currentPath+"/"+tablename+".ix";//索引文件夹的路径
    QDir dir(Index_FolderPath);
    //std::vector<data> dataList;//结构体数组
    QHash<QString, data> indexHash; //创建哈希表

    if (!dir.exists()) {//如果该索引文件夹不存在
        return false;
    }
    else{
            QStringList filters; // 创建字符串列表，用于过滤文件名

            filters << "*" + attribute + "*"; // 将包含指定字符串的文件名添加到过滤列表中，使用通配符"*"匹配字符串任意位置
            dir.setNameFilters(filters); // 设置目录的文件名过滤器
            dir.setFilter(QDir::Files | QDir::NoSymLinks); // 设置目录过滤器，只获取普通文件，不包括符号链接

            QFileInfoList fileList = dir.entryInfoList(); // 获取符合过滤条件的文件信息列表
            if (fileList.isEmpty()) { // 如果文件列表为空
                return false; // 这个属性没有建立索引
            }
            else{//有索引。打开文件
            for (const QFileInfo &fileInfo : fileList) {
                //qDebug() << fileInfo.fileName();
                QFile file(currentPath+"/"+tablename+".ix/"+fileInfo.fileName());//索引文件的路径;

                if (!file.exists()) // 这个属性没有建立索引
                {
                    return false;
                }
                else//打开读取
                {
                    // 打开文件
                    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                        return false;//打开失败
                    }
                    // 读取文件内容
                    QTextStream in(&file);
                    while (!in.atEnd()) {
                        QString line = in.readLine();
                        QStringList strList = line.split(" ");//根据空格拆分
                        data d;
                        d.content=strList[0];
                        d.rownumber=strList[1].toInt();
                        indexHash[d.content] = d;
                        //qDebug() << d.content <<" "<<d.rownumber;
                    }

                    //调用索引函数（哈希表）
                    data va = indexHash.value(value);  //查找对应的结构体

                    rownum=va.rownumber;

                    // 关闭文件
                    file.close();

                }
              }
            }

    }

}


