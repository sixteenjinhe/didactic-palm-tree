#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "cmd.h"
#include "user.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("QMainWindow {background-image:url(D:/dbms/picture/login.jpg)}");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    FILE *fusers; // 文件指针，用于存储用户名和密码
    char line[256]; // 用于读取文件中的每行数据
    bool found = false; // 标记是否找到匹配的用户名和密码

//    bool hasrange = user::hasPermission("lyx","all privileges","*","*");
//    if(hasrange){
//        qDebug()<<"有权限";
//    }else qDebug() << "无权限";

    QString username = ui->lineEdit_username->text(); // 获取输入的用户名
    QString password = ui->lineEdit_password->text(); // 获取输入的密码
    QString combined = username + ":" + password; // 将用户名和密码组合成一行

    fusers = fopen("D:/dbms/File/users.txt", "r"); // 打开存储用户数据的文件
    if (fusers == NULL) {
        qDebug() << "Error opening user file"; // 文件打开失败
    } else {
        while (fgets(line, sizeof(line), fusers)) { // 读取文件中的每一行
            if (QString(line).trimmed() == combined.trimmed()) { // 比较去除尾部空白的字符串
                found = true;
                break;
            }
        }
        fclose(fusers); // 关闭文件
    }

    if (found) {
        this->close(); // 隐藏当前窗口
        user::username = username;
        cmd *cmdwindow = new cmd();
        cmdwindow->setUsername(username);//传入当前用户名
        cmdwindow->show(); // 显示主命令窗口
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误，请重新输入！"); // 弹出错误提示
        ui->lineEdit_username->clear(); // 清空用户名输入框
        ui->lineEdit_password->clear(); // 清空密码输入框
        ui->lineEdit_username->setFocus(); // 将光标定位到用户名输入框
    }
}
