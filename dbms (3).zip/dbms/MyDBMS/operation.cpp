#include "operation.h"
#include "cmd.h"
#include "ui_cmd.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Index.h"
#include "user.h"
#include <QRegularExpression>
#include <QDebug>
#include <QString>
#include <QDate>
operation::operation(Ui::cmd *ui): ui(ui)
{
    iscmd = 1;
}
operation::operation(Ui::showwindow *ui): uis(ui)
{
    iscmd = 0;
}

void operation::createDataBase(QStringList &strList){
    //create，*.*

    qDebug() << "ui的username" << user::username;
    //权限检查
    bool hasgrant = user::hasPermission(user::username,"create","*","*");

    if(!hasgrant){
        qDebug() << "没有权限！";
        return;
    }

     if(strList.size()==3){//语句输入形式正确
         QString databaseName = strList[2];  // 获取数据库名称
         QString databasefolderPath = "D:/dbms/File/"+strList[2];
         QDir dir(databasefolderPath);
         if (dir.exists() && iscmd == 1) {//如果该文件夹已经存在
             ui->plainTextEdit->appendPlainText("Database already exists;");
          }
         else
         {
            if (dir.mkpath(".")) {//if语句判断dir.mkpath(".")的返回值是否为真。如果为真，则目录创建成功
             if(iscmd == 1)
                 ui->plainTextEdit->appendPlainText("Database created successfully;");
             //将数据库名保存到文件中
             QFile file("D:/dbms/File/database.txt");
             if (file.open(QIODevice::Append | QIODevice::Text)) {  // 确保文件以追加模式打开
                 QTextStream out(&file);
                 out << databaseName << "\n";  // 写入数据库名和换行符
                 file.close();  // 关闭文件
             } else {
                 //ui->plainTextEdit->appendPlainText("Failed to save database name to file;");
               }
            }
            //else
             //ui->plainTextEdit->appendPlainText("Failed to create Database;");
         }
     }
     //else
      //ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
}

QString operation::useDataBase(QStringList &strList){

    QString currentPath;
    if(strList.size()==2){//语句输入形式正确
        QString DataBaseName = strList[1];//用户要打开的数据库名称
        QDir dir("D:/dbms/File");

        if(dir.exists(DataBaseName))//如果已经存在这个数据库
        {
            currentPath = "D:/dbms/File/"+DataBaseName;//改变全局变量，获取当前数据库的目录地址，相当于打开数据库
            //ui->plainTextEdit->appendPlainText("Database changed;");
        }
        else//不存在这个数据库，报错
        {
            //ui->plainTextEdit->appendPlainText("Error:The Database is not exist;");
        }
    }
    else {
        //ui->plainTextEdit->appendPlainText("Wrong Sentence;");
    }
    return currentPath;//返回数据库路径

}


void operation::createTable(QStringList &strList,QString currentPath){
    //create databasename.*
    //qDebug() << "ui中的用户名称now"<< user::username;
    QString currentPath0 = currentPath;
    QString databaseName = currentPath0.remove("D:/dbms/File/");
    //qDebug() << "databasename：" << databaseName;
    //权限检查
    bool hasgrant = user::hasPermission(user::username,"create",databaseName,"*");

    if(!hasgrant){
        qDebug() << "没有权限！";
        return;
    }

    //qDebug()<<currentPath;
    QString str = strList.join(" ");//把字符串数组重新变回QString,为了找出（）中间的语句，相当于恢复之前的命令语句
    int index1 = str.indexOf('(');//第一个出现的‘（’
    int index2 = str.lastIndexOf(')');//查找最后出现的一个‘）’，因为中间语句也许有），比如VARCHAR(10)
    if(index2!=str.length()-1){//容错：最后）和；之间还有字符
        //ui->plainTextEdit->appendPlainText("Wrong Sentence;");
    }
    if (index1 == -1||index2==-1) {//容错：没有（或）
         ui->plainTextEdit->appendPlainText("Error Character( or ) not found;");
    }
     else {
        QString result = str.mid(index1+1, index2-index1-1);//找到（ ）中间的语句，即要存储的内容
        QStringList  resultList = result.split(",");//把中间的命令用，拆分,也就是拆分为一个个属性
//        for(int i=0;i<resultList.size();i++)
//            qDebug()<<resultList[i];

        QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名

        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
             //ui->plainTextEdit->appendPlainText("Please select database first;");
        }
        else//已经选择了使用的数据库
        {
            QFile file(currentPath+"/"+tablename+".frm");//数据定义文件的路径;

            if (file.exists()) // 检查数据结构文件是否已经存在
            {
                //ui->plainTextEdit->appendPlainText("This table has already exists;");
                return;
            }
            else
            {
                if (file.open(QIODevice::WriteOnly)| QIODevice::Text)//文件创建成功,以文本模式打开
                {
                    QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                    for(int i=0;i<resultList.size();i++)// 将用户写的表结构写入数据定义文件.frm
                       stream << resultList[i]<< endl;//在行末添加换行符，一个属性在文件里一行
                    file.close();
                    // 表结构文件创建成功后，将表名写入 table.txt
                    QFile tableList(currentPath + "/table.txt");  // 定位到 table.txt 文件
                    if (tableList.open(QIODevice::Append | QIODevice::Text)) {
                        QTextStream out(&tableList);
                        out << tablename << '\n';  // 追加表名到文件
                        tableList.close();
                        //ui->plainTextEdit->appendPlainText("Successfully create this table;");
                    } else {
                        //ui->plainTextEdit->appendPlainText("Failed to record table name;");
                    }

                    //ui->plainTextEdit->appendPlainText("successfully create this table;");

                }
                else
                {
                    //ui->plainTextEdit->appendPlainText("Failed to create this table;");

                }
            }
        }

    }
}

void operation::descTable(QStringList &strList,QString currentPath){
    QStringList fieldList;//字符串数组，每个元素存储一行，也就是一个属性的结构
    if(strList.size()==2){//语句输入形式正确
        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
            ui->plainTextEdit->appendPlainText("Please select database first;");


        }
        else{//已经打开了数据库
            QFile file(currentPath+"/"+strList[1]+".frm");//数据定义文件的路径;
            if (!file.exists()) //如果数据结构文件不存在
            {
                ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");

                return;
            }
            else{//之前已经创建过这个表，可以查询他的结构
                if (file.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
                {
                    QTextStream in(&file); // 使用QTextStream读取文件内容
                    while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line = in.readLine(); // 一行一行读取内容
                        fieldList<<line;//把每个属性的那一行追加到字符串数组中
                    }
                    file.close(); // 关闭文件

//                  for(int i=0;i<fieldList.size();i++)
//                    qDebug()<<fieldList[i];
                    int row=fieldList.size();//输出有几行，也就是一共几个属性
                    QString property[row][5];//输出的表结构相当于一个二维数组，列有fiel,type,null,key,default
                    for(int i=0;i<row;i++){
                       if(fieldList[i].size()<2)
                            ui->plainTextEdit->appendPlainText("Wrong sentence;");

                       else{
                          property[i][0] = fieldList[i].section(" ", 0, 0);//获取第一个空格前的内容，即属性名

                          int SpaceIndex1=fieldList[i].indexOf(' ');  // 获取第一个和第二个空格的索引
                          int SpaceIndex2=fieldList[i].indexOf(' ',SpaceIndex1+1);
                          //获取第二个词语，也就是类型
                          property[i][1]=fieldList[i].mid(SpaceIndex1+1,SpaceIndex2-SpaceIndex1-1);

                          if (fieldList[i].contains("not null")) {//如果有‘not null'
                              property[i][2]="NO";
                              fieldList[i].remove(" not null");//删去该字符串，使得最后就剩key关键字
                          }
                          else property[i][2]="Yes";

                          if(fieldList[i].contains("default")){//如果有默认
                              QStringList rowList = fieldList[i].split(" ");//拆分，为了查default下一个
                              int indexdv = rowList.indexOf("default");
                              if (indexdv != -1 && indexdv + 1 < rowList.size()){
                                  property[i][3] = rowList.at(indexdv + 1);
                                  fieldList[i].remove(" default");
                                  fieldList[i].remove(property[i][3]);//删去该字符串，使得最后就剩key关键字
                              }
                          }
                          else property[i][3]="None";

                          if (SpaceIndex2!=-1)
                             property[i][4] = fieldList[i].mid(SpaceIndex2 + 1);//获取key关键字
                        }
                    }


//                    for(int i=0;i<row;i++)
//                        qDebug()<<fieldList[i];

                    ui->plainTextEdit->appendPlainText("Field  Type  Null  Default  key");//输出结构表
                    ui->plainTextEdit->appendPlainText("------------------------------------");
                    for(int i=0;i<row;i++){
                    ui->plainTextEdit->appendPlainText(property[i][0]+" "+property[i][1]+" "+property[i][2]+" "
                               +property[i][3]+" "+property[i][4]);
                     ui->plainTextEdit->appendPlainText("------------------------------------");
                    }
                     ui->plainTextEdit->appendPlainText("This is the table you want to check;");

                }
                else {
                    ui->plainTextEdit->appendPlainText("Failed to open this table file;");


                    return;
                }
            }
        }
    }
    else{
        ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误

    }
}

void operation::dropDatabase(QStringList &strList){
    //drop *.*
    QString databaseName = strList[2];

    //权限检查
    bool hasgrant = user::hasPermission(user::username,"drop","*","*");

    if(!hasgrant){
        qDebug() << "没有权限！";
        return;
    }

    if(strList.size()==3){//语句输入形式正确
        QString databasefolderPath = "D:/dbms/File/"+strList[2];
        QDir dir(databasefolderPath);
        if (dir.exists()) {//如果该文件夹已经存在
            if (dir.removeRecursively()) {
                    //ui->plainTextEdit->appendPlainText("successfully drop;");

                    // 更新 database.txt 文件
                    QFile file("D:/dbms/File/database.txt");
                    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                        QString content;
                        QTextStream in(&file);
                        bool found = false;

                        while (!in.atEnd()) {
                            QString line = in.readLine();
                            if (line.trimmed() != databaseName) {
                                content += line + "\n";
                            } else {
                                found = true;  // 标记找到并将删除的行
                            }
                        }
                        file.close();

                        if (found) {  // 如果找到并需要删除的行，重新写入更新后的内容
                            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                                QTextStream out(&file);
                                out << content;  // 写入除了被删除的数据库名称外的所有内容
                                file.close();
                            } else {
                                //ui->plainTextEdit->appendPlainText("Failed to update database list;");
                            }
                        }
                    } else {
                        //ui->plainTextEdit->appendPlainText("Failed to open database list file;");
                    }

                } else {
                    //ui->plainTextEdit->appendPlainText("Failed drop;");
                }
         }
        else
        {
           //ui->plainTextEdit->appendPlainText("Database has not exists yet,please create it first;");
        }
    }
    else{
        //ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
}

void operation::dropTable(QStringList &strList,QString currentPath){
    //drop databasename.*
    QString tableName = strList[2];

    QString currentPath0 = currentPath;
    QString databaseName = currentPath0.remove("D:/dbms/File/");

    qDebug() << "tablename：" << tableName;
    //权限检查
    bool hasgrant = user::hasPermission(user::username,"drop",databaseName,tableName);

    if(!hasgrant){
        qDebug() << "没有权限！";
        return;
    }

    if(strList.size()==3){//语句输入形式正确
        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
             //ui->plainTextEdit->appendPlainText("Please select database first;");
        }
        else//已经选择了使用的数据库
        {
            QFile file1(currentPath+"/"+strList[2]+".frm");//要删除的数据定义文件的路径;
            QFile file2(currentPath+"/"+strList[2]+".trd");//要删除的数据内容文件的路径;

            if (file1.exists()) // 检查要删除的数据结构文件是否存在
            {
                if(file2.exists()){//如果已经插入过数据
                    if (file1.remove()&&file2.remove()) {
                        //ui->plainTextEdit->appendPlainText("table successfully drop;");
                    } else {
                        //ui->plainTextEdit->appendPlainText("Failed to drop table;");
                    }
                }
                else{
                    if(file1.remove()){
                        //ui->plainTextEdit->appendPlainText("table successfully drop;");

                        // 从 table.txt 中删除表名
                        QFile tableListFile(currentPath + "/table.txt");
                        if (tableListFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
                            QString content;
                            QTextStream in(&tableListFile);
                            bool found = false;

                            while (!in.atEnd()) {
                                QString line = in.readLine().trimmed();
                                if (line != tableName) {
                                    content += line + "\n";
                                } else {
                                    found = true; // 标记找到需要删除的行
                                }
                            }
                            tableListFile.close();

                            if (found) { // 重新写入更新后的内容
                                if (tableListFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
                                    QTextStream out(&tableListFile);
                                    out << content;
                                    tableListFile.close();
                                } else {
                                    //ui->plainTextEdit->appendPlainText("Failed to update table list;");
                                }
                            }
                        } else {
                            //ui->plainTextEdit->appendPlainText("Failed to open table list file;");
                        }

                    }else{
                        //ui->plainTextEdit->appendPlainText("Failed to drop table;");
                    }
                }
            }

        }
    }
    else{
        //ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
}



QStringList operation::getFieldList(QStringList &strList,QString currentPath) {
    QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名——规定表名前后都必须有空格
    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList;//字符串数组，每个元素存储一行，也就是一个属性的结构
    int rowfield = 0;
    QFile readfile(currentPath+"/"+tablename+".frm");//对应数据库与表名的文件
    if (!readfile.exists()) //如果数据结构文件不存在
    {
        qDebug() << "This table has not exists,please create it first;";
    }
    else {//存在表字段文件
        if (readfile.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
        {
            QTextStream in(&readfile); // 使用QTextStream读取文件内容
            while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
            {
                QString line = in.readLine(); // 一行一行读取内容
                fieldList<<line;//把每个属性的那一行追加到字符串数组中
            }
            readfile.close(); // 关闭文件
        }
        else {
            qDebug() << "Failed to open this table file;";
        }

    }
    return fieldList;
}

void operation::readField(QStringList &strList,QString currentPath,QString (*property)[5]) {
    QStringList fieldList = getFieldList(strList,currentPath);
    int rowfield=fieldList.size();//输出有几行，也就是一共几个属性
    for(int i=0;i<rowfield;i++){
       if(fieldList[i].size()<2)
          qDebug()<<"Wrong sentence";
       else{
          property[i][0] = fieldList[i].section(" ", 0, 0);//获取第一个空格前的内容，即属性名

          int SpaceIndex1=fieldList[i].indexOf(' ');  // 获取第一个和第二个空格的索引
          int SpaceIndex2=fieldList[i].indexOf(' ',SpaceIndex1+1);
          //获取第二个词语，也就是类型
          property[i][1]=fieldList[i].mid(SpaceIndex1+1,SpaceIndex2-SpaceIndex1-1);

          if (fieldList[i].contains("not null")) {//如果有‘not null'
              property[i][2]="NO";
              fieldList[i].remove(" not null");//删去该字符串，使得最后就剩key关键字
          }
          else property[i][2]="Yes";

          if(fieldList[i].contains("default")){//如果有默认
              QStringList rowList = fieldList[i].split(" ");//拆分，为了查default下一个
              int indexdv = rowList.indexOf("default");
              if (indexdv != -1 && indexdv + 1 < rowList.size()){
                  property[i][3] = rowList.at(indexdv + 1);
                  fieldList[i].remove(" default");
                  fieldList[i].remove(property[i][3]);//删去该字符串，使得最后就剩key关键字
              }
          }
          else property[i][3]="None";

          if (SpaceIndex2!=-1)
             property[i][4] = fieldList[i].mid(SpaceIndex2 + 1);//获取key关键字
        }
    }
}

void operation::insertToTable(QStringList &strList,QString currentPath,QString str){
    //insert databasename.tablename

    //调用insert语句检查函数，查验输入的str是否符合条件——如括号匹配，逗号等
    QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名——规定表名前后都必须有空格
    qDebug() << "tablename：" << tablename;

    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
    int rowfield = fieldList.size();
    QString property[rowfield][5];
    readField(strList,currentPath,property);//获取字段信息二维数组
    //打印查看获取的字段数组是否准确-----------------------
    qDebug()<<" Field  Type  Null  Default  key";//输出结构表
    qDebug()<<"------------------------------------";
    for(int i=0;i<rowfield;i++){
       qDebug()<<property[i][0]+" "+property[i][1]+" "+property[i][2]+" "
               +property[i][3]+" "+property[i][4];
       qDebug()<<"------------------------------------";
    }
    qDebug()<<"This is the table you want to check;";
    //--------------------------------------


    //strList[3]为列参数表，则为有列参数表，strList[3]为values，则为无列参数表，即全参
    bool hasFieldParameters;//标记有无列参数表
    int startpos = strList[3].indexOf("(");//查找第一个出现的 "("
    int endpos = strList[3].indexOf(")");//查找第一个出现的 ")"
    QString fieldresult;//存放列参数字符串
    QStringList fieldNameList;//存放获取的列参数表，即字段名称
    //判断有无参数列表
    if(startpos != -1 && endpos != -1 && endpos > startpos) {
        hasFieldParameters = true;
    }else if(strList[3].compare("values")==0) {
        hasFieldParameters = false;
    }else {
        qDebug() << "wrong insert sentence;";
        return;
    }

    if(hasFieldParameters){ //有参数列表
        //获取列参数表
        fieldresult = strList[3].mid(startpos+1,endpos-startpos-1);//获取参数列表
        fieldNameList = fieldresult.split(",");//把中间的命令用，拆分,获得列参数数组，如[sno,sname,sage]
    }else { //无参数列表，即为全参数
        for(int i = 0; i < rowfield; i++) {
            fieldNameList.append(property[i][0]);
        }
    }
    qDebug() << "fieldNameList:" << fieldNameList;//打印获取的列参数表验证


    //获取数据列表，以()括号内内容为一条数据，()间以，隔开，并判断语句正确性
    QStringList dataList;//一维数组，一个元素表示一条记录
    QString dataStr;//存放要插入的总数据
    int enddataIndex;//表示记录结束位置
    //获取数据记录dataStr
    if(hasFieldParameters) { //有参数列表，说明strList[5]为数据
        enddataIndex = strList[5].lastIndexOf(";") - 1;
        dataStr = strList[5].mid(0,enddataIndex);
    } else { //无参数列表，说明strList[4]为数据
        enddataIndex = strList[4].lastIndexOf(";") - 1;
        dataStr = strList[4].mid(0,enddataIndex);
    }
    //将dataStr拆分成dataList
    int bracketOpenIndex = -1;//左括号索引
    int bracketCloseIndex = -1;//右括号索引
    int rowdata = 0;//数据记录数

    if (dataStr.isEmpty()) {
        qDebug() << "Data string is empty!";
        return;
    }
    qDebug() << "dataStr:" << dataStr;
    //循环提取每对括号内的数据
    dataStr = " " + dataStr + " ";//在数据串前后加一个空格以整体判断
    for (int i = 0; i < dataStr.length(); i++) {
        if (dataStr.at(i) == '(' && (dataStr.at(i-1) == ' ' || dataStr.at(i-1) == ',')) {//匹配到左括号，左括号前是空格或，号
            bracketOpenIndex = i;//更新左括号索引为当前
        }
        else if (dataStr.at(i) == ')' && (dataStr.at(i+1) == ' ' || dataStr.at(i+1) == ',')) {//匹配到右括号,右括号后是,号
            bracketCloseIndex = i;//更新右括号索引为当前
            QString data = dataStr.mid(bracketOpenIndex + 1, bracketCloseIndex - bracketOpenIndex - 1);//将左右括号间的值放入数组中位一条记录
            dataList.append(data);
            rowdata++;//更新数据记录行数
        }
    }
    qDebug() << "DataList:" << dataList;
    qDebug() << "rowdata:" << rowdata;
    //将dataList按","拆分成dataRecord二维数组，之后用二维数组精准判断插入数据是否合法
    // 创建二维数组
    QVector<QVector<QString>> dataRecord(rowdata, QVector<QString>());
    int columndata[rowdata];
    memset(columndata, 0, sizeof(columndata));//显式循环初始化数组值为0
    // 遍历 dataList，对每个元素按逗号拆分并存入二维数组
    for (int i = 0; i < rowdata; i++) {
        QStringList elements = dataList[i].split(",");
        for (int j = 0; j < elements.size(); ++j) {
            dataRecord[i].append(elements[j]);
            columndata[i]++;
        }
    }
    for(int i = 0; i < rowdata; i++) {
       qDebug() << "columndata:" << columndata[i];
    }

    // 输出二维数组
    for (int i = 0; i < dataRecord.size(); ++i) {
        QString rowOutput; // 存储当前行的输出
        for (int j = 0; j < dataRecord[i].size(); ++j) {
            rowOutput += dataRecord[i][j] + " "; // 拼接每个元素的字符串形式，并添加空格分隔
        }
        qDebug() << rowOutput; // 打印整行
        qDebug() << "---------"; // 每行之间添加分隔符
    }


    //匹配判断插入数据的合理性——包括数据格式是否正确，数据是否和列参数表匹配，列参数表是否合法，是否符合约束条件
    bool isfieldNameListMatch = true;//标记列参数表是否匹配文件中字段
    for (const QString& fieldName : fieldNameList) {
        bool found = false;
        for (int i = 0; i < rowfield; i++) {
            if (fieldName == property[i][0]) {
                found = true;  // 找到了当前元素
                break;
            }
        }
        if (!found) {
            isfieldNameListMatch = false;  // 当前元素未找到，返回假
        }
    }
    qDebug() << "isfieldNameListMatch:" << isfieldNameListMatch;

    bool isdatacolumnListMatch = true;//标记单行数据个数是否匹配列参数表
    for (int i = 0; i < rowdata; i++) {
        if(columndata[i] != fieldNameList.size()){
            isdatacolumnListMatch = false;
        }
    }
    qDebug() << "isdatacolumnListMatch:" << isdatacolumnListMatch;

    bool rightdataStr = true;
    QVector<QVector<QString>> newdataRecord(rowdata, QVector<QString>());
    if(isfieldNameListMatch && isdatacolumnListMatch) { //列参数表和文件中匹配且每行数据的个数和列参数表一样
        //对于字段约束，循环判断一条记录
        for(int i = 0; i < rowdata; i++) {
            //调整dataRecord的数量和位置以符合文件中的全参数表，在列参数表未出现的地方赋NULL
            QVector<QString> dataRecordnew(rowfield,NULL);
            for (int k = 0; k < fieldNameList.size(); k++) {
                for(int j = 0; j < rowfield; j++) {
                    if(fieldNameList[k].compare(property[j][0]) == 0){//在全参中找到列参中对应的字段名
                        dataRecordnew[j] = dataRecord[i][k];
                    }
                }
            }
            bool caninsert0 = dataRecordJudge(property,dataRecordnew,rowfield,columndata[i],fieldNameList);//调用函数检查本条记录是否合法
            for (int k = 0; k < rowfield; k++)
            {
                qDebug() << "xin:" << dataRecordnew[k];
            }
            newdataRecord[i] = dataRecordnew; //获取填充好的数组存入文件

            bool caninsert1 = true;//检验Check条件——一个大工程

            if (caninsert0 == false || caninsert1 == false) {
                rightdataStr = false;
                break;//一旦检测到不能插入的数据记录，则退出循环
            }
        }
        for (int k = 0; k < rowdata; k++)
        {
            qDebug() << "xindata:" << newdataRecord[k];
        }
        //对于表约束，对全数据判断——表约束要先读取数据文件中所有数据
        if(!tableLC(strList,currentPath,tablename,newdataRecord)){
            rightdataStr = false;
        }

        if(rightdataStr == true) {
            //数据保存到文件中——在特定名数据库文件夹下，创建一个与表名同名文件，后缀为trd
            saveDataToFile(currentPath,newdataRecord,tablename);

            //删除原索引文件，创建新索引文件——即索引文件的更新
            processIndexFiles(currentPath,tablename);//删除与创建

            ui->plainTextEdit->appendPlainText ("successfully insert datas;");
        }else
            ui->plainTextEdit->appendPlainText("Incorrect data format, insertion failed;");

    }
}

//从数据文件中读取所有数据
QVector<QVector<QString>> operation::readData(QString currentPath,QString tablename) {
    QStringList dataList;
    int rowdata = 0;
    QFile file(currentPath+"/"+tablename+".trd");  // 替换为实际的文件名
    if (file.open(QIODevice::WriteOnly | QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) { //逐行读取文件内容，直到文件末尾
            QString line = in.readLine();
            dataList << line;//把每一行数据追加到字符串数组中
            rowdata++;
        }
        file.close();//关闭文件
        QVector<QVector<QString>> data(rowdata, QVector<QString>());
        qDebug() <<"dataList.size():" << dataList.size();
        // 遍历dataList，对每个元素按逗号拆分并存入二维数组
        for (int i = 0; i < dataList.size(); i++) {
            QStringList elements = dataList[i].split(",");
            qDebug() <<"elements.size():" << elements.size();
            for (int j = 0; j < elements.size(); j++) {
                data[i].append(elements[j]);
            }
        }
        qDebug() << data;
        return data;
    }else
        qDebug() << "Failed to open this data file";
}

//对数据文件中表约束条件的判断
bool operation::tableLC(QStringList &strList,QString currentPath,QString tablename,QVector<QVector<QString>> newdataRecord) { //
    //unique和primary
    QVector<QVector<QString>> data = readData(currentPath,tablename);//获取文件中数据的二维数组
    for (const auto &row : newdataRecord) { //将文件中数据和新添数据合并到一起
        data.append(row);
    }
    data.erase(std::remove(data.begin(), data.end(), QVector<QString>{""}), data.end());//去除空数据行
    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
    int rowfield = fieldList.size();
    QString property[rowfield][5];
    readField(strList,currentPath,property);//获取字段信息二维数组
    //primary判断——唯一，非空
    qDebug() << data;
    for(int i = 0; i < rowfield; i++) {
        if(property[i][4].compare("primary")==0) {//第i个属性为主键
            qDebug() << "存在主键";
            for(int j = 0; j < data.size(); j++) {
                for(int k = 0; k < data.size(); k++) {
                    if(data[j][i]==data[k][i] && k != j) {//主键存在相同元素
                        return false;
                    }
                }
                if(data[j][i]==NULL) {//主键为空
                    return false;
                }
            }
        }else if(property[i][4].compare("unique")==0) {//第i个为unique
            for(int j = 0; j < data.size(); j++) {
                for(int k = 0; k < data.size(); k++) {
                    if(data[j][i]==data[k][i] && k != j) {//主键存在相同元素
                        return false;
                    }
                }
            }
        }
    }
    return true;
}


void operation::alterTableField(QStringList &strList,QString currentPath,QString str) {
    //alter databasename.tablename
    QString tablename = strList[2];//获取表名
    //读取表中已有字段信息，存储在property二维数组中
    QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
    int rowfield = fieldList.size();
    QString property[rowfield][5];
    readField(strList,currentPath,property);//获取字段信息二维数组
    //检验数据库中是否存在表名
    if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
             ui->plainTextEdit->appendPlainText("Please select database first;");
        return;
    }
    else{//已经打开了数据库
        QFile file(currentPath+"/"+tablename+".frm");//数据定义文件的路径;
        if (!file.exists()) //如果数据结构文件不存在
        {
            ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
            return;
        }
        else{//确保数据库打开，表存在，可执行表字段操作
            if (strList[3].compare("add")==0) {
                int addfieldNum = 0;
                QStringList addfieldstr;
                //定义正则表达式模式-例：add sno int
                QRegularExpression addregex("add ([^,]+)");
                QRegularExpressionMatchIterator matchIterator = addregex.globalMatch(str);//在字符串中查找匹配项
                // 遍历匹配结果
                while (matchIterator.hasNext()) {
                    QRegularExpressionMatch match = matchIterator.next();
                    QString data = match.captured(1);
                    addfieldNum++;//获取新增的字段数量
                    addfieldstr.append(data);
                    qDebug() << data;
                }
                // 创建新字段信息二维数组，格式为{{列名，数据类型，[完整性约束]},{表级完整性约束}}
                // <表示句子错误，=2表示无完整性约束，=3表示有完整性约束，=1表示为表级完整性约束
                QVector<QVector<QString>> addfieldinfo(addfieldNum, QVector<QString>());//新增字段信息的二维数组
                //按空格拆分成二维数组
                for (int i = 0; i < addfieldNum; i++) {
                    QStringList elements = addfieldstr[i].split(" ");
                    for (int j = 0; j < elements.size(); ++j) {
                        addfieldinfo[i].append(elements[j]);
                    }
                }
                qDebug() <<addfieldinfo;


                bool canAddField = true;//标记新增字段能否插入表文件,默认为可添加，若遇到重复字段则不能添加

                for (int i = 0; i < addfieldinfo.size(); i++) {//循环判断每一行是否符合插入条件
                    if(addfieldinfo[i].size() < 2) { //语句出错
                       ui->plainTextEdit->appendPlainText("wrong alter sentence;");
                        return;
                    }else if(addfieldinfo[i].size()>=2) { //该行不是表级约束条件
                        //判断字段名是否重复——与文件中比较
                        for(int k = 0; k < rowfield; k++) {
                            if(addfieldinfo[i][0].compare(property[k][0])==0) {
                                canAddField = false;
                                break;
                            }
                        }
                        qDebug() << "与文件canaddfield:" << canAddField;
                        //与自身比较
                        for(int k = 0; k < addfieldNum; k++) {
                            if(addfieldinfo[i][0].compare(addfieldinfo[k][0])==0 && i!=k) {
                                canAddField = false;
                                break;
                            }
                        }
                        qDebug() << "与自身canaddfield:" << canAddField;
                        //判断数据类型是否合理
                        if(!rightDataType(addfieldinfo[i][1])) {
                            canAddField = false;
                            break;
                        }
                        qDebug() << "数据类型canaddfield:" << canAddField;
                    }else if(addfieldinfo[i].size()==1) {//该行是表级约束

                    }
                }
                qDebug() << "canaddfield:" << canAddField;

                if(canAddField) { //没有被限制添加，则将新字段信息加入表定义文件中
                    if (file.open(QIODevice::WriteOnly|QIODevice::Append | QIODevice::Text))//文件创建成功,以文本模式打开
                    {
                        QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                        for(int i=0;i<addfieldstr.size();i++)// 将用户写的表结构写入数据定义文件.frm
                           stream << addfieldstr[i] << endl;//在行末添加换行符，一个属性在文件里一行
                        file.close();
                       ui->plainTextEdit->appendPlainText("successfully add field;");
                    }
                    else
                    {
                        ui->plainTextEdit->appendPlainText("Failed to add field;");
                    }
                }else ui->plainTextEdit->appendPlainText ("fieldname or fieldtype is wrong!");
            }else if (strList[3].compare("modify")==0) {//修改字段
                int modifyfieldNum = 0;
                QStringList modifyfieldstr;
                //定义正则表达式模式-例：modify column sno int
                QRegularExpression modifyregex("modify column ([^,]+)");
                QRegularExpressionMatchIterator matchIterator = modifyregex.globalMatch(str);//在字符串中查找匹配项
                // 遍历匹配结果
                while (matchIterator.hasNext()) {
                    QRegularExpressionMatch match = matchIterator.next();
                    QString data = match.captured(1);
                    modifyfieldNum++;//获取新增的字段数量
                    modifyfieldstr.append(data);
                    qDebug() << data;
                }
                // 创建新字段信息二维数组，格式为{列名，数据类型}
                QVector<QVector<QString>> modifyfieldinfo(modifyfieldNum, QVector<QString>());//新增字段信息的二维数组
                //按空格拆分成二维数组
                for (int i = 0; i < modifyfieldNum; i++) {
                    QStringList elements = modifyfieldstr[i].split(" ");
                    for (int j = 0; j < elements.size(); ++j) {
                        modifyfieldinfo[i].append(elements[j]);
                    }
                }
                qDebug() <<modifyfieldinfo;

                bool canModifyField = true;//标记修改字段是否合法，默认为合法，若遇到查找不到字段/新数据类型不合理，则设为false

                for (int i = 0; i < modifyfieldinfo.size(); i++) {//循环判断每一行是否符合修改条件
                    bool modifyFlag = false;//默认该字段名还没找到
                    if(modifyfieldinfo[i].size() != 2) { //语句出错
                       ui->plainTextEdit->appendPlainText("wrong alter sentence;");
                        return;
                    }else if(modifyfieldinfo[i].size() == 2) { //语句格式正确
                        //判断字段名是否在文件中找到
                        for(int k = 0; k < rowfield; k++) {
                            if(modifyfieldinfo[i][0].compare(property[k][0])==0) {//找到了
                                modifyFlag = true;
                                property[k][1] = modifyfieldinfo[i][1];//将文件中对应字段信息更改
                                break;
                            }
                        }
                        if(modifyFlag == false) {
                            canModifyField = false;//遍历完循环还未找到
                        }
                        qDebug() << "与文件canmodifyfield:" << canModifyField;

                        //判断数据类型是否合理
                        if(!rightDataType(modifyfieldinfo[i][1])) {
                            canModifyField = false;
                            break;
                        }
                        qDebug() << "数据类型canmodifyfield:" << canModifyField;
                    }
                }
                if(canModifyField) { //没有被限制添加，则将修改好的字段信息加入表定义文件中
                    qDebug() << "你好1";
                    if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) // 以文本模式打开并清空原有内容
                    {
                        QTextStream stream(&file); // 创建 QTextStream 对象，并关联文件
                        for(int i = 0; i < rowfield; i++) // 遍历每一行
                        {
                            for(int j = 0; j < 5; j++) // 遍历每一行的每一个元素
                            {
                                if (j == 2) // 特殊处理第三列
                                {
                                    if (property[i][j] == "No")
                                    {
                                        stream << "not null";
                                    }
                                    else if (property[i][j] == "Yes")
                                    {
                                        continue; // 跳过这一列
                                    }
                                }
                                else if (j == 3) // 特殊处理第四列
                                {
                                    if (property[i][j] != "None")
                                    {
                                        stream << "default " << property[i][j];
                                    }
                                    // 如果是 "None"，不存储这一列
                                }
                                else // 其他列正常处理
                                {
                                    stream << property[i][j];
                                }

                                if (j < 4) // 如果不是行末最后一个元素，添加空格
                                    stream << " ";
                            }
                            stream << endl; // 行结束后添加换行符
                        }
                        file.close();
                        ui->plainTextEdit->appendPlainText("Successfully modified field.");
                    }
                    else
                    {
                        ui->plainTextEdit->appendPlainText("Failed to modify field;");
                    }
                }else ui->plainTextEdit->appendPlainText ("fieldname or fieldtype is wrong!");

            }else if (strList[3].compare("drop")==0) {//删除字段
                QStringList dropFieldStr;
                    // 定义正则表达式模式：drop column sno
                    QRegularExpression dropRegex("drop(?: column)? (.+)");
                    QRegularExpressionMatchIterator matchIterator = dropRegex.globalMatch(str); // 在字符串中查找匹配项

                    // 遍历匹配结果
                    while (matchIterator.hasNext()) {
                        QRegularExpressionMatch match = matchIterator.next();
                        QString data = match.captured(1);
                        dropFieldStr.append(data);
                        qDebug() << data;
                    }

                    QVector<QVector<QString>> remainingFields;
                    bool fieldFound = false;
                    int newrowfield = 0;

                    // 查找并移除字段
                    for (int i = 0; i < rowfield; i++) {
                        fieldFound = false;
                        for (const QString& field : dropFieldStr) {
                            if (property[i][0].compare(field) == 0) {
                                fieldFound = true;
                                break;
                            }
                        }
                        if (!fieldFound) { // 如果该字段不在删除列表中，保留整行数据
                            QVector<QString> rowVector;
                            for (int j = 0; j < 5; j++) {  // Assuming there are always 5 elements in the property[i] array
                                rowVector.push_back(property[i][j]);
                            }
                            remainingFields.push_back(rowVector);
                            newrowfield++;
                        }
                    }
                    if (newrowfield < rowfield) { // 如果找到至少一个字段并删除
                        if (file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) // 以文本模式打开并清空原有内容
                        {
                            QTextStream stream(&file); // 创建 QTextStream 对象，并关联文件
                            for(int i = 0; i < newrowfield; i++) // 遍历每一行
                            {
                                for(int j = 0; j < 5; j++) // 遍历每一行的每一个元素
                                {
                                    if (j == 2) // 特殊处理第三列
                                    {
                                        if (remainingFields[i][j] == "No")
                                        {
                                            stream << "not null";
                                        }
                                        else if (remainingFields[i][j] == "Yes")
                                        {
                                            continue; // 跳过这一列
                                        }
                                    }
                                    else if (j == 3) // 特殊处理第四列
                                    {
                                        if (remainingFields[i][j] != "None")
                                        {
                                            stream << "default " << remainingFields[i][j];
                                        }
                                        // 如果是 "None"，不存储这一列
                                    }
                                    else // 其他列正常处理
                                    {
                                        stream << remainingFields[i][j];
                                    }

                                    if (j < 4) // 如果不是行末最后一个元素，添加空格
                                        stream << " ";
                                }
                                stream << endl; // 行结束后添加换行符
                            }
                            file.close();
                            ui->plainTextEdit->appendPlainText("Successfully drop field.");
                        }
                        else {
                            ui->plainTextEdit->appendPlainText("Failed to open file for updating;");
                        }
                    } else {
                        ui->plainTextEdit->appendPlainText("No field found to drop;");
                    }
            }else ui->plainTextEdit->appendPlainText ("Alter sentences wrong!");

        }
    }
}

//判断数据类型合理函数
bool operation::rightDataType(QString type) {
    if(type.compare("int")==0 || type.compare("boolean")==0 || type.compare("double")==0 ||
            type.compare("date")==0 || type.compare("time")==0 ||
            (type.startsWith("varchar(") && type.endsWith(")")) ||
            (type.startsWith("char(") && type.endsWith(")"))) {
        return true;
    }else return false;
}


//数据保存到特定名称数据库文件夹下，与表名相同的trd文件中
void operation::saveDataToFile (QString currentPath,QVector<QVector<QString>> dataRecord,QString tablename) {
    QFile file(currentPath+"/"+tablename+".trd");//数据存储文件路径
    if (file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {//以文本形式打开文件
        QTextStream out(&file);
        // 遍历二维数组，并将每一行写入文件
        for (const QVector<QString>& row : dataRecord)
        {
            QString line;
            for (const QString& element : row)
            {
                line += element + ","; // 使用逗号和空格连接行中的元素
            }
            line.chop(1); // 移除末尾多余的逗号
            out << line << endl; // 写入文件，并在行末添加换行符
        }
        file.close();
        qDebug()<<"successfully insert data;";
    }
    else
    {
      ui->plainTextEdit->appendPlainText("Failed to insert data;");
    }
}

void operation::processIndexFiles(QString currentPath,QString tableName) {
    QString filePath = currentPath + "/" + tableName + ".txt"; // 假设索引文件与表名相同，后缀为.txt
    QFile file(filePath);
    Index index(ui);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file:" << filePath;
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(" ");
        QString indexName = parts.at(2); // 假设索引名在每行的第三个部分
        //删除指定索引名的文件
        QStringList dropSen = {"drop","index",indexName,"on",tableName};//填充删除索引语句
        //调用删除索引文件的函数
        qDebug() << "到process了";
        index.drop_Index(dropSen,currentPath,0);//不更新创建索引文件集合
        //调用创建索引文件的函数
        index.build_Index_File(parts,currentPath);
    }
    file.close();
}


//检测一条数据记录是否正确匹配列参数表，若正确匹配，返回true
bool operation::dataRecordJudge(QString (*property)[5], QVector<QString>& dataRecord,int rowfield,int columndata,QStringList fieldNameList) {
    qDebug() << "传递过来：";
    for (int i = 0; i < rowfield; ++i)
    {
        for (int j = 0; j < 5; ++j)
        {
            qDebug() << property[i][j];
        }
    }

    //----------------------------------------------------------------
    for (int i = 0; i < rowfield; i++)
    {
        qDebug() << dataRecord[i];
    }
    //检查数据是否符合字段信息
    bool rightDType = false;//默认为不满足，直到通过下方检验
    bool rightDNull = true;//默认为可以为空
    for (int j = 0; j < rowfield; j++) {
        //若该值不为空，判断数据类型是否匹配
        if (dataRecord[j] != NULL) {
            rightDType = false;//判断数据类型是否正确
            bool isWrappedWithQuotes = false;//判断字符串是否被引号包裹
            if (dataRecord[j].startsWith("'") && dataRecord[j].endsWith("'")) {
                isWrappedWithQuotes = true;
                // 字符串被单引号包裹,暂定只能用单引号
            }
    //            else if (dataRecord.startsWith(""") && dataRecord.endsWith(""")) {
    //                isWrappedWithQuotes = true;
    //                // 字符串被双引号包裹
    //            }
            if (property[j][1].compare("int")==0) { //长整数，4字节
                dataRecord[j].toInt(&rightDType);//判断是否为整数
            }else if(property[j][1].compare("boolean")==0) { //逻辑布尔值
                if(dataRecord[j].compare("true")==0 || dataRecord[j].compare("false")==0){
                    rightDType = true;
                }
            }else if(property[j][1].compare("double")==0) { //双精度浮点数
                dataRecord[j].toDouble(&rightDType);
            }else if(property[j][1].compare("date")==0) { //日期，格式为YYYY-MM-DD
                if(isWrappedWithQuotes){
                    QDate date = QDate::fromString(dataRecord[j], "yyyy-MM-dd");
                    if(date.isValid()){
                        rightDType = true;
                    }
                }

            }else if(property[j][1].compare("time")==0) { //时间，格式为HH:MM:DD
                if(isWrappedWithQuotes){
                    QTime time = QTime::fromString(dataRecord[j], "hh:mm:ss");
                    if(time.isValid()){
                        rightDType = true;
                    }
                }

            }else if(property[j][1].startsWith("varchar(") && property[j][1].endsWith(")")) { //最大长度为n的变长字符串
                QString capturedText = property[j][1].mid(8, property[j][1].length() - 9);
                int n = capturedText.toInt();
                if(isWrappedWithQuotes){//字符串被引号包裹，说明可能为字符串类型
                    int startIndex = dataRecord[j].indexOf("'");
                    int endIndex = dataRecord[j].lastIndexOf("'");
                    QString data = dataRecord[j].mid(startIndex+1,endIndex-startIndex-1);
                    qDebug() << "varchardata:" << data;
                    if(data.length() <= n){
                        rightDType = true;
                    }
                }
            }else if(property[j][1].startsWith("char(") && property[j][1].endsWith(")")) { //长度为n的定长字符串
                QString capturedText = property[j][1].mid(8, property[j][1].length() - 9);
                int n = capturedText.toInt();
                if(isWrappedWithQuotes){
                    int startIndex = dataRecord[j].indexOf("'");
                    int endIndex = dataRecord[j].lastIndexOf("'");
                    QString data = dataRecord[j].mid(startIndex+1,endIndex-startIndex-1);
                    qDebug() << "chardata:" << data;
                    if(data.length() == n){
                        rightDType = true;
                    }
                }
            }else {
                qDebug() << "wrong data type;";
            }
            if (rightDType == false) {
                break;
            }
        }else { //若该值为空，判断该字段信息是否要求非空
            //判断是否可以为空
            if (property[j][2].compare("No")==0) { //字段表示不可以为空
                if(dataRecord[j] == NULL) { //但是数据为空，说明不满足字段约束
                    rightDNull = false;
                }
            }
            //判断有无默认值，有默认值则用默认值替代空值
            if (property[j][3].compare("None") != 0) { //字段有默认值
                dataRecord[j] = property[j][3];
            }
        }

        //判断是否有key约束
        if (property[j][4] != NULL) { //存在key约束
            //划分处理key约束
            if (property[j][4].compare("primary")==0) { //该字段为主键——不允许为空，不允许重复

            }
        }

    }

    qDebug() << "rightDType:" << rightDType;
    qDebug() << "rightDNull:" << rightDNull;
    if (rightDType && rightDNull) {
        return true;
    }else return false;
}
void operation::print(QStringList &strList,QString currentPath){
QFile file(currentPath + "/" + strList[3] + ".frm"); // 数据定义文件的路径
if (!file.exists()) // 如果数据结构文件不存在
{
    ui->plainTextEdit->appendPlainText("This table has not exists, please create it first;");

}
else { // 之前已经创建过这个表
    if (file.open(QIODevice::ReadOnly)) // 打开文件, 读取属性信息
    {
        QTextStream in(&file); // 使用QTextStream读取文件内容
        QStringList lines; // 存储每一行的内容
        while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
        {
            QString line = in.readLine(); // 一行一行读取内容
            lines.append(line); // 将读取的行添加到列表中
        }
        file.close(); // 关闭文件
        // 将读取的内容转为二维数组
        QVector<QVector<QString>> dataArray;
        for (int i = 0; i < lines.size(); i++) {
            QString line = lines[i];
            QStringList words = line.split(" "); // 假设每个词之间用空格分隔
            QVector<QString> row;
            for (int j = 0; j < words.size(); j++) {
                row.append(words[j]);
            }
            dataArray.append(row);
        }

        // 打印每一行的第一个词
        QString result;
        for (int i = 0; i < dataArray.size(); i++) {
            QVector<QString> row = dataArray[i];
            if (!row.isEmpty()) {
                QString firstWord = row[0];
                result.append(firstWord + "  |  ");
            }
        }
        ui->plainTextEdit->appendPlainText(result);
    }

}
}
void operation::selectTable(QStringList &strList,QString currentPath,QString str){
    if(currentPath.compare("")==0){//如果当前路径为空，则会报错
             ui->plainTextEdit->appendPlainText("Please select database first;");
        return;
    }
    if(strList[1].compare("*")==0){
            print(strList,currentPath);
            QFile file(currentPath+"/"+strList[3]+".frm");//数据定义文件的路径;



                    QFile f(currentPath+"/"+strList[3]+".trd");
                    if (!f.exists()) // 如果数据文件不存在
                    {
                        ui->plainTextEdit->appendPlainText("This table is empty;");

                    }else{
                    if (f.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                    {
                        QTextStream in2(&f); // 使用QTextStream读取文件内容
                        QStringList lines2; // 存储每一行的内容
                        while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                        {
                            QString line2 = in2.readLine(); // 一行一行读取内容
                            lines2.append(line2); // 将读取的行添加到列表中
                        }
                        f.close(); // 关闭文件

                        // 将读取的内容转为二维数组
                        QVector<QVector<QString>> dataArray2;
                        for (int i = 0; i < lines2.size(); i++) {
                            QString line2 = lines2[i];
                            QStringList words = line2.split(" "); // 假设每个词之间用空格分隔
                            QVector<QString> row2;
                            for (int j = 0; j < words.size(); j++) {
                                QString data = words[j];

                                row2.append(data);
                            }
                            dataArray2.append(row2);
                        }
                        for (int i = 0; i < dataArray2.size(); i++) {
                            QVector<QString> row2 = dataArray2[i]; // 获取每一行的数据
                            for (int j = 0; j < row2.size(); j++) {
                                QString data2 = row2[j];
                                data2.replace("'", ""); // 去掉单引号
                                data2.replace(",", "   |  "); // 将逗号改为竖杠
                                QString allRow;
                                allRow+=data2+"   |   ";
                                ui->plainTextEdit->appendPlainText(allRow); // 打印所有数据
                                ui->plainTextEdit->appendPlainText("- -- -- -- -- -- --");

                            }
                        }
                     ui->plainTextEdit->appendPlainText("select successfully;");




                     }
                    }




      }
    else{
        QStringList result;
        QRegularExpression regex("select\\s+(.*?)\\s+from", QRegularExpression::CaseInsensitiveOption);
        //匹配select和from之间的词
        QRegularExpressionMatch match = regex.match(str);

        // 如果匹配成功，则获取匹配到的词并添加到结果列表中
        if (match.hasMatch()) {
            QString word = match.captured(1);
            word.replace(",","  |  ");
            result.append(word);
            //如果匹配成功，则获取匹配到的词并添加到结果列表中
            ui->plainTextEdit->appendPlainText(word);
                  ui->plainTextEdit->appendPlainText("\n");
              QFile fi(currentPath+"/"+strList[3]+".frm");
              if (!fi.exists()) // 如果数据结构文件不存在
              {//报错
                  ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                  return;
              }else{

              QStringList linenumber;// 存储行数的数组

              if (fi.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
              {
                  QTextStream in2(&fi); // 使用QTextStream读取文件内容
                  QStringList lines2; // 存储每一行的内容

                  while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                  {
                      QString line2 = in2.readLine(); // 一行一行读取内容
                      QStringList words=line2.split(" ");

                      lines2.append(line2); // 将读取的行添加到列表中
                  }
                  fi.close(); // 关闭文件
                  for (int i = 0; i < lines2.size(); i++) {
                      QString firstWord = lines2[i].split(" ").first();
                      //匹配字段名
                      if (word.contains(firstWord)) {
                          linenumber.append(QString::number(i + 1));
                      }
                  }
                  //存储读取到的行数
                  for (int i = 0; i < linenumber.size(); i++) {
                      qDebug() << linenumber[i];
                  }
                  QFile fil(currentPath+"/"+strList[3]+".trd");
                                if (!fil.exists()) // 如果数据文件不存在
                                {
                                    ui->plainTextEdit->appendPlainText("This table is empty;");
                                    return;
                                }else{
                                if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                                {
                                    QTextStream in2(&fil); // 使用QTextStream读取文件内容
                                    QStringList lines2; // 存储每一行的内容

                                    while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                    {
                                        QString line2 = in2.readLine(); // 一行一行读取内容
                                        lines2.append(line2);

                                    }
                                    fil.close(); // 关闭文件
                                    int rowSize = lines2.size(); // 二维数组的行数
                                    int colSize = linenumber.size(); // linenumber里存储的数的个数
                                    //遍历二维数组中每一行，找到列值符合linenumber存储的数值条件的数并打印出来
                                    for (int row = 0; row < rowSize; row++) {
                                        QString line = lines2[row];
                                        QStringList columns = line.split(",");

                                        for (int col = 0; col < colSize; col++) {
                                            //linenumber转化为数值
                                            int lineNumber = linenumber[col].toInt();

                                            if (lineNumber <= columns.size()) {
                                                //列索引为linenumber-1
                                                QString column = columns[lineNumber - 1];
                                                column = column.remove("'");
                                                ui->plainTextEdit->insertPlainText(column);
                                            }

                                            if (col != colSize - 1) {
                                                ui->plainTextEdit->insertPlainText("   |   ");
                                            }
                                        }

                                        ui->plainTextEdit->insertPlainText("\n-----------\n");

                                    }
                                     ui->plainTextEdit->appendPlainText(" select successfully;");

                                }
    }
    }


}
    }else{
          ui->plainTextEdit->appendPlainText("Sorry,the table does not have;");
        }

}

}
void operation::whereTable(QStringList &strList,QString currentPath,QString str){
     Index in(ui);
    if(currentPath.compare("")==0){//如果当前路径为空，则会报错
             ui->plainTextEdit->appendPlainText("Please select database first;");
        return;
    }
    if(strList[1].compare("*")==0){
         print(strList,currentPath);
         QString targetWord = strList[5];
         QFile fii(currentPath+"/"+strList[3]+".frm");
            if (!fii.exists()) // 如果数据结构文件不存在
            {
                ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                return;
            }else{
                int number;// 存储行数

                if (fii.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                {
                    QTextStream in2(&fii); // 使用QTextStream读取文件内容
                    QStringList lines2; // 存储每一行的内容

                    while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line2 = in2.readLine(); // 一行一行读取内容
                        QStringList words=line2.split(" ");

                        lines2.append(line2); // 将读取的行添加到列表中
                    }
                    fii.close(); // 关闭文件
                    for (int i = 0; i < lines2.size(); i++) {
                        QString f = lines2[i].split(" ").first();
                        if (f == targetWord) {
                            number = i+1;  // 将行数赋值给number
                            break;  // 找到匹配的行后，跳出循环
                        }
                    }
                    qDebug() << number;
                    QFile fil(currentPath+"/"+strList[3]+".trd");
                    if (!fil.exists()) // 如果数据文件不存在
                    {
                        ui->plainTextEdit->appendPlainText("This table is empty;");
                        return;
                    }else{
                        if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                        {
                            QTextStream in2(&fil); // 使用QTextStream读取文件内容
                            QStringList lines2; // 存储每一行的内容

                            while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                            {
                                QString line2 = in2.readLine(); // 一行一行读取内容
                                lines2.append(line2);

                            }
                            fil.close(); // 关闭文件
                            // 将读取到的内容转为二维数组
                            QVector<QVector<QString>> array2;
                            for (int i = 0; i < lines2.size(); i++) {
                                //按照逗号分开为列
                                QStringList row = lines2[i].split(",");
                                QVector<QString> arrayRow;
                                for (int j = 0; j < row.size(); j++) {
                                    arrayRow.append(row[j]);
                                }
                                array2.append(arrayRow);
                            }

                            // 找到列数与number相等的列并存储下来
                            QVector<QString> targetColumn;
                            for (int i = 0; i < array2.size(); i++) {
                                if (array2[i].size() >= number) {
                                    targetColumn.append(array2[i][number - 1]);
                                }
                            }

                            //输出结果
                            for (int i = 0; i < targetColumn.size(); i++) {
                                  qDebug() <<targetColumn[i];
                            }

                            QString secondWord = strList[6];
                            QString symbol = secondWord;
                            qDebug()<<symbol;
                            //存储比较的数值
                            QString thirdWord = strList[7];
                            thirdWord.prepend("'");
                            thirdWord.append("'");
                            qDebug() << thirdWord;
                            QVector<int> matchingRows; // 存储满足条件的行数
                            //找到满足条件的行，并将行数存储到数组中

                            for (int i = 0; i < array2.size(); i++) {
                                QString value = targetColumn[i];
                                if (symbol == "=") {
                                       if (value == thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else if (symbol == "<>") {
                                       if (value != thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else if (symbol == ">") {
                                       if (value > thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else if (symbol == "<") {
                                       if (value < thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else if (symbol == ">=") {
                                       if (value >= thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else if (symbol == "<=") {
                                       if (value <= thirdWord) {
                                           matchingRows.append(i);
                                       }
                                   } else {
                                       ui->plainTextEdit->appendPlainText("Error: the operation is wrong;");
                                   }
                            }
                            //打印出符合条件的行的所有值

                            if (matchingRows.isEmpty()) {
                                ui->plainTextEdit->appendPlainText("No matching rows found;");
                            } else {
                                QString output;
                                for (int i = 0; i < matchingRows.size(); i++) {
                                    int rowIndex = matchingRows[i];
                                    QVector<QString> row = array2[rowIndex];
                                    for (int j = 0; j < row.size(); j++) {
                                        QString data = row[j];
                                        data.replace("'", "");
                                        output += data + "   |   ";

                                    }
                                    output += "\n";
                                    output += "--------------\n";
                                }
                                ui->plainTextEdit->appendPlainText(output);
 ui->plainTextEdit->appendPlainText("select successfully;");
                            }

                    }

            }

    }

}

    }else{
        QStringList result;
        QRegularExpression regex("select\\s+(.*?)\\s+from", QRegularExpression::CaseInsensitiveOption);
        //匹配select和from之间的词
        QRegularExpressionMatch match = regex.match(str);

        // 如果匹配成功，则获取匹配到的词并添加到结果列表中
        if (match.hasMatch()){
            QString word = match.captured(1);
            word.replace(",","  |  ");
            result.append(word);
            //如果匹配成功，则获取匹配到的词并添加到结果列表中
            ui->plainTextEdit->appendPlainText(word);
                  ui->plainTextEdit->appendPlainText("\n");
                  QFile fi(currentPath+"/"+strList[3]+".frm");
                 if (!fi.exists()) // 如果数据结构文件不存在
                  {//报错
                    ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                    return;
                                   }else{

                 QStringList linenumber;// 存储行数的数组

                  if (fi.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                      {
                   QTextStream in2(&fi); // 使用QTextStream读取文件内容
                   QStringList lines2; // 存储每一行的内容

                   while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                   {
               QString line2 = in2.readLine(); // 一行一行读取内容
              QStringList words=line2.split(" ");

             lines2.append(line2); // 将读取的行添加到列表中
                          }
                  fi.close(); // 关闭文件
                 for (int i = 0; i < lines2.size(); i++) {
                 QString firstWord = lines2[i].split(" ").first();
                   //匹配字段名
                if (word.contains(firstWord)) {
                  linenumber.append(QString::number(i + 1));
                             }
                                       }
                 //存储读取到的行数
                 for (int i = 0; i < linenumber.size(); i++) {
                                           qDebug() << linenumber[i];
                                       }
                         }


                  // 将字符串按照空格分开
               QStringList words = strList.join(" ").split(" ");
              // 找到where的位置
               int whereIndex = words.indexOf("where");

           // 获取第一个、第二个和第三个单词
              QString firstword = words.value(whereIndex + 1);
               QString secondword = words.value(whereIndex + 2);
            QString symbol = secondword;
            QString thirdword = words.value(whereIndex + 3);
             qDebug() << firstword;
          qDebug()<<symbol;
            thirdword.prepend("'");
           thirdword.append("'");
           QFile fii(currentPath+"/"+strList[3]+".frm");
           if (!fii.exists()) // 如果数据结构文件不存在
               {
              ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
              return;
                   }else{
                       int number;// 存储行数

                     if (fii.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                                                     {
                 QTextStream in2(&fii); // 使用QTextStream读取文件内容
                 QStringList lines2; // 存储每一行的内容

                 while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                                         {
                   QString line2 = in2.readLine(); // 一行一行读取内容
               QStringList words=line2.split(" ");

        lines2.append(line2); // 将读取的行添加到列表中
                              }
            fii.close(); // 关闭文件
             for (int i = 0; i < lines2.size(); i++) {
         QString f = lines2[i].split(" ").first();
         if (f == firstword) {
              number = i+1;  // 将行数赋值给number
               break;  // 找到匹配的行后，跳出循环
                                   }
                           }
                 qDebug() << number;
              QFile fil(currentPath+"/"+strList[3]+".trd");
         if (!fil.exists()) // 如果数据文件不存在
                        {
             ui->plainTextEdit->appendPlainText("This table is empty;");
         return;
        }else{
       if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                                                             {
QTextStream in2(&fil); // 使用QTextStream读取文件内容
 QStringList lines2; // 存储每一行的内容

                       while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                              {
            QString line2 = in2.readLine(); // 一行一行读取内容
            lines2.append(line2);

                 }
                   fil.close(); // 关闭文件
           // 将读取到的内容转为二维数组
           QVector<QVector<QString>> array2;
          for (int i = 0; i < lines2.size(); i++) {
                   //按照逗号分开为列
             QStringList row = lines2[i].split(",");
          QVector<QString> arrayRow;
          for (int j = 0; j < row.size(); j++) {
                arrayRow.append(row[j]);
                                          }
                        array2.append(arrayRow);
                                                                 }

             // 找到列数与number相等的列并存储下来
                       QVector<QString> targetColumn;
                   for (int i = 0; i < array2.size(); i++) {
                if (array2[i].size() >= number) {
               targetColumn.append(array2[i][number - 1]);
                                                                     }
                                                                 }

                    //输出结果
        for (int i = 0; i < targetColumn.size(); i++) {
                                qDebug() <<targetColumn[i];
                                                                 }
                 QVector<int> matchingRows; // 存储满足条件的行数
                     //找到满足条件的行，并将行数存储到数组中

                    for (int i = 0; i < array2.size(); i++) {
               QString value = targetColumn[i];

               if (symbol == "=") {
             if (value == thirdword) {

       matchingRows.append(i);
                         }
             } else if (symbol == "<>") {
                 if (value != thirdword) {
                     matchingRows.append(i);
                             }
                } else if (symbol == ">") {
                     if (value > thirdword) {
                  matchingRows.append(i);


                                }
              }else if (symbol == ">=") {
               if (value >= thirdword) {
                matchingRows.append(i);
                        }
               } else if (symbol == "<=") {
                       if (value <= thirdword) {
               matchingRows.append(i);
                         }
                  } else {
            ui->plainTextEdit->appendPlainText("Error: the operation is wrong;");
                         }
                       }
         QString output;
      for (int i = 0; i < matchingRows.size(); i++) {
         int rowIndex = matchingRows[i];
    QVector<QString> row = array2[rowIndex];
       QStringList columns = row.toList().join(",").split(",");
      bool allColumnsMatched = true;
    for (int k = 0; k < linenumber.size(); k++) {
      int columnNumber = linenumber[k].toInt();
      if (columnNumber <= columns.size()) {
     QString data = columns[columnNumber - 1];
     data.replace("'", "");
     output += data + "   |   ";
        } else {
     allColumnsMatched = false;
     break;
              }
            }

         if (allColumnsMatched) {
        output += "\n";
       output+="-------------\n";
                         }
            }

              ui->plainTextEdit->appendPlainText(output);
             ui->plainTextEdit->appendPlainText("select successfully;");

}
    }
}
                                 }

        }

    }
        else{
    ui->plainTextEdit->appendPlainText("Sorry,this table does not have;");
                }
}
}
void operation::deleteTable(QStringList &strList,QString currentPath,QString str){

    if(strList.contains("where")){
          QString targetWord = strList[4];
        QFile fii(currentPath+"/"+strList[2]+".frm");
        if (!fii.exists()) // 如果数据结构文件不存在
        {
            ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
            return;
        }else{
            int number;// 存储行数

            if (fii.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
            {
                QTextStream in2(&fii); // 使用QTextStream读取文件内容
                QStringList lines2; // 存储每一行的内容

                while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                {
                    QString line2 = in2.readLine(); // 一行一行读取内容
                    QStringList words=line2.split(" ");

                    lines2.append(line2); // 将读取的行添加到列表中
                }
                fii.close(); // 关闭文件
                for (int i = 0; i < lines2.size(); i++) {
                    QString f = lines2[i].split(" ").first();
                    if (f == targetWord) {
                        number = i+1;  // 将行数赋值给number
                        break;  // 找到匹配的行后，跳出循环
                    }
                }
                qDebug() << number;

    }
            QFile fil(currentPath+"/"+strList[2]+".trd");
                           if (!fil.exists()) // 如果数据文件不存在
                           {
                               ui->plainTextEdit->appendPlainText("This table is empty;");
                               return;
                           }else{
                               if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                               {
                                   QTextStream in2(&fil); // 使用QTextStream读取文件内容
                                   QStringList lines2; // 存储每一行的内容

                                   while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                   {
                                       QString line2 = in2.readLine(); // 一行一行读取内容
                                       lines2.append(line2);

                                   }
                                fil.close();

                                   // 将读取到的内容转为二维数组
                                   QVector<QVector<QString>> array2;
                                   for (int i = 0; i < lines2.size(); i++) {
                                       //按照逗号分开为列
                                       QStringList row = lines2[i].split(",");
                                       QVector<QString> arrayRow;
                                       for (int j = 0; j < row.size(); j++) {
                                           arrayRow.append(row[j]);
                                       }
                                       array2.append(arrayRow);
                                   }

                                   // 找到列数与number相等的列并存储下来
                                   QVector<QString> targetColumn;
                                   for (int i = 0; i < array2.size(); i++) {
                                       if (array2[i].size() >= number) {
                                           targetColumn.append(array2[i][number - 1]);
                                       }
                                   }

                                   //输出结果
                                   for (int i = 0; i < targetColumn.size(); i++) {
                                         qDebug() <<targetColumn[i];
                                   }

                                   QString secondWord = strList[5];
                                   QString symbol = secondWord;
                                   qDebug()<<symbol;
                                   //存储比较的数值
                                   QString thirdWord = strList[6];
                                   thirdWord.prepend("'");
                                   thirdWord.append("'");
                                   qDebug() << thirdWord;
                                   QVector<int> matchingRows; // 存储满足条件的行数
                                   //找到满足条件的行，并将行数存储到数组中

                                   for (int i = 0; i < array2.size(); i++) {
                                       QString value = targetColumn[i];
                                       if (symbol == "=") {
                                              if (value == thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else if (symbol == "<>") {
                                              if (value != thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else if (symbol == ">") {
                                              if (value > thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else if (symbol == "<") {
                                              if (value < thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else if (symbol == ">=") {
                                              if (value >= thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else if (symbol == "<=") {
                                              if (value <= thirdWord) {
                                                  matchingRows.append(i);
                                              }
                                          } else {
                                              ui->plainTextEdit->appendPlainText("Error: the operation is wrong.");
                                          }
                                   }
                                   for (int i = 0; i < matchingRows.size(); i++) {
                                       qDebug() << matchingRows[i];
                                   }
                                   if (matchingRows.isEmpty()) {
                                       ui->plainTextEdit->appendPlainText("No matching rows found.");
                                   } else {
                                       for (int i = 0; i < matchingRows.size(); i++) {
                                           int rowIndex = matchingRows[i];
                                        qDebug()<<rowIndex;
                                   // 删除符合条件的行
                                        QVector<int> rowsToRemove; // 存储需要删除的行的索引
                                           for (int i = 0; i < matchingRows.size(); i++) {
                                               int rowIndex = matchingRows[i];

                                               // 将需要删除的行的索引添加到rowsToRemove中
                                               rowsToRemove.append(rowIndex);
                                           }

                                           // 根据rowsToRemove中的索引，从array2中删除对应的行
                                           for (int i = rowsToRemove.size() - 1; i >= 0; i--) {
                                               int rowIndex = rowsToRemove[i];
                                               array2.remove(rowIndex);
                                           }
                                       }
                                   }
            QFile sfile(currentPath+"/"+strList[2]+".trd");
          if (sfile.open(QIODevice::WriteOnly | QIODevice::Text)) {
      QTextStream out(&sfile); // 创建一个QTextStream对象，与文件关联

           for (int i = 0; i < array2.size(); i++) {
               for (int j = 0; j < array2[i].size(); j++) {
             out << array2[i][j]; // 将数组元素写入到文件中
               if (j < array2[i].size() - 1) {
               out << ","; // 在元素之间添加逗号分隔符
                     }
                    }
               out << "\n"; // 换行
          }

            sfile.close(); // 关闭文件
                                           }


           ui->plainTextEdit->appendPlainText("delete successfully;");
                                   }
        }
    }
    }


else{
        QFile files(currentPath+"/"+strList[2]+".trd");
        if (!files.exists()) // 如果数据文件不存在
        {
            ui->plainTextEdit->appendPlainText("This table is empty;");
            return;
        }else{

                if (files.open(QIODevice::ReadWrite | QIODevice::Truncate)) // 打开文件并清空内容
                {
                    files.resize(0); // 清空文件内容

                    files.close(); // 关闭文件
                }
            }
            ui->plainTextEdit->appendPlainText("Successfully;");


    }
}
void operation::updateTable(QStringList &strList,QString currentPath,QString str){
    QStringList commands;
    QString command;
    bool isSet = false;

    for (int i = 0; i < strList.size(); i++) {
        QString str = strList[i];

        if (str == "set") {
     isSet = true;
            continue;
        }
        if (str == "where") {
            break;
        }

        if (isSet) {
            command += str + " ";
        }
    }

    command = command.trimmed();
    commands = command.split(",");
    for (int i = 0; i < commands.size(); i++) {
           qDebug() << commands[i];
       }

      QStringList words = strList.join(" ").split(" ");
       // 找到where的位置
      int whereIndex = words.indexOf("where");

        // 获取第一个、第二个和第三个单词
                                 QString firstword = words.value(whereIndex + 1);
                                  QString secondword = words.value(whereIndex + 2);
                               QString symbol = secondword;
                               QString thirdWord = words.value(whereIndex + 3);
                                qDebug() << firstword;
                             qDebug()<<symbol;
                               thirdWord.prepend("'");
                              thirdWord.append("'");
     QFile fii(currentPath+"/"+strList[1]+".frm");
    if (!fii.exists()) // 如果数据结构文件不存在
    {
        ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
        return;
    }else{
        int number;// 存储行数

        if (fii.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
        {
            QTextStream in2(&fii); // 使用QTextStream读取文件内容
            QStringList lines2; // 存储每一行的内容

            while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
            {
                QString line2 = in2.readLine(); // 一行一行读取内容
                QStringList words=line2.split(" ");

                lines2.append(line2); // 将读取的行添加到列表中
            }
            fii.close(); // 关闭文件
            for (int i = 0; i < lines2.size(); i++) {
                QString f = lines2[i].split(" ").first();
                if (f == firstword) {
                    number = i+1;  // 将行数赋值给number
                    break;  // 找到匹配的行后，跳出循环
                }
            }
             qDebug() << number;
             QStringList lnumber; // 存储行数的数组
             QString firstChar;
             // 获取每一个命令的第一个单词
             for (int i = 0; i < commands.size(); i++) {
                 QStringList commandWords = commands[i].split(" ");
                 if (!commandWords.isEmpty()) {
                     QString firstChar = commandWords.first();
                     qDebug() << firstChar;

                     // 获取文件中的每一行的第一个词
                     for (int j = 0; j < lines2.size(); j++) {
                         QString firstWord = lines2[j].split(" ").first();
                         // 匹配字段名
                         if (firstChar == firstWord) {
                             lnumber.append(QString::number(j + 1));
                         }
                     }
                 }
             }
             for (int i = 0; i < lnumber.size(); i++) {
                 qDebug() << lnumber[i];
             }


            QFile fil(currentPath+"/"+strList[1]+".trd");
                                  if (!fil.exists()) // 如果数据文件不存在
                                  {
                                      ui->plainTextEdit->appendPlainText("This table is empty;");
                                      return;
                                  }else{
                                      if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                                      {
                                          QTextStream in2(&fil); // 使用QTextStream读取文件内容
                                          QStringList lines2; // 存储每一行的内容

                                          while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                          {
                                              QString line2 = in2.readLine(); // 一行一行读取内容
                                              lines2.append(line2);

                                          }
                                       fil.close();

                                          // 将读取到的内容转为二维数组
                                          QVector<QVector<QString>> array2;
                                          for (int i = 0; i < lines2.size(); i++) {
                                              //按照逗号分开为列
                                              QStringList row = lines2[i].split(",");
                                              QVector<QString> arrayRow;
                                              for (int j = 0; j < row.size(); j++) {
                                                  arrayRow.append(row[j]);
                                              }
                                              array2.append(arrayRow);
                                          }

                                          // 找到列数与number相等的列并存储下来
                                          QVector<QString> targetColumn;
                                          for (int i = 0; i < array2.size(); i++) {
                                              if (array2[i].size() >= number) {
                                                  targetColumn.append(array2[i][number - 1]);
                                              }
                                          }

                                          //输出结果
                                          for (int i = 0; i < targetColumn.size(); i++) {
                                                qDebug() <<targetColumn[i];
                                          }
                                          QVector<int> matchingRows; // 存储满足条件的行数
                                                                      //找到满足条件的行，并将行数存储到数组中

    for (int i = 0; i < array2.size(); i++) {
    QString value = targetColumn[i];
     if (symbol == "=") {
 if (value == thirdWord) {
    matchingRows.append(i);
  }
    } else if (symbol == "<>") {
           if (value != thirdWord) {
        matchingRows.append(i);
              }
         } else if (symbol == ">") {
            if (value > thirdWord) {
          matchingRows.append(i);
           }
          } else if (symbol == "<") {
           if (value < thirdWord) {
       matchingRows.append(i);
       }
     } else if (symbol == ">=") {
     if (value >= thirdWord) {
      matchingRows.append(i);
   }
     } else if (symbol == "<=") {
 if (value <= thirdWord) {
    matchingRows.append(i);
     }
   } else {
  ui->plainTextEdit->appendPlainText("Error: the operation is wrong;");
      }
     }
 for (int i = 0; i < matchingRows.size(); i++) {
         qDebug() << matchingRows[i];
    }
 QString third;
 QList<QString> thirdValues; // 定义一个存储third值的数组
 for (int i = 0; i < commands.size(); i++) {
     QStringList commandWords = commands[i].split(" ");
     if (commandWords.size() >= 3) {
         third = commandWords.at(2);
         third.prepend("'");
         third.append("'");
          qDebug() << third;
          thirdValues.append(third); // 将third值添加到数组中
     }
     }
 //找到符合条件的每一行的对应列
 for (int j = 0; j < matchingRows.size(); j++) {
     int rowIndex = matchingRows[j];
     QVector<QString> row = array2[rowIndex];
     QStringList columns = row.toList().join(",").split(",");
     bool allColumnsMatched = true;

     for (int k = 0; k < lnumber.size(); k++) {
         int columnNumber = lnumber[k].toInt();
           if (columnNumber <= columns.size()) {
             columns[columnNumber - 1] = thirdValues[k]; // 将对应列的数值改为thirdValues中数
           } else {
             allColumnsMatched = false;
             break;
         }
     }

     if (allColumnsMatched) {
         array2[rowIndex] = QVector<QString>::fromList(columns);
     }
 }

 QFile sfile(currentPath+"/"+strList[1]+".trd");
if (sfile.open(QIODevice::WriteOnly | QIODevice::Text)) {
QTextStream out(&sfile); // 创建一个QTextStream对象，与文件关联

for (int i = 0; i < array2.size(); i++) {
    for (int j = 0; j < array2[i].size(); j++) {
  out << array2[i][j]; // 将数组元素写入到文件中
    if (j < array2[i].size() - 1) {
    out << ","; // 在元素之间添加逗号分隔符
          }
         }
    out << "\n"; // 换行
}

 sfile.close(); // 关闭文件
                                }


ui->plainTextEdit->appendPlainText("update successfully;");
   }

}

}
   }
    }



