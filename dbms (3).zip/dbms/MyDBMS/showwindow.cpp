#include "showwindow.h"
#include "ui_showwindow.h"
#include "cmd.h"
#include <QDebug>
#include "operation.h"
#include <QString>
#include <QStringList>
#include <QApplication>
#include <QFile>
#include <QTextStream>
#include <QWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "user.h"
#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QRadioButton>
#include <QButtonGroup>
#include <QGroupBox>
//全局变量区域
operation *op_ui;
user *use_ui;
QString databaseName;
QString tableName;


showwindow::showwindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::showwindow)
{
    ui->setupUi(this);
    resize(1500, 1200); // 初始大小
    op_ui = new operation(ui);
    use_ui = new user(ui);
    //先设置表等按钮不可见，直到use了数据库再显示可见

    ui->btnCreateTb->hide();
    ui->btnDropTb->hide();
    ui->btnUseTb->hide();
    ui->cbnDropTb->hide();
    ui->cbnUseTb->hide();
    ui->btnCreateIndex->hide();
    ui->btnCreateView->hide();
    ui->btnUpdateField->hide();
    ui->btnDropIndex->hide();
    ui->btnDropView->hide();
    ui->btnRefershTb->hide();


    refreshDatabases(); // 初始加载数据库列表
}

void showwindow::setUsername(const QString &username) {
    this->username = username;  // 设置成员变量username
}

QString showwindow::getUsername() const {
    return username;  // 返回成员变量username
}

showwindow::~showwindow()
{
    delete ui;
}

void showwindow::on_btnReturn_clicked()
{
    this->hide(); // 隐藏当前窗口
    emit returnToCmd(); // 发出信号，通知 cmd 窗口重新显示
}

//初始刷新库函数
void showwindow::refreshDatabases()
{
    QFile file("D:/dbms/File/database.txt");
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
//        ui->cbnDropDb->clear();
//        ui->cbnUseDb->clear();
        while (!in.atEnd()) {
            QString line = in.readLine();
            ui->cbnDropDb->addItem(line);
            ui->cbnUseDb->addItem(line);
        }
        file.close();
    }
}
//创建数据库
void showwindow::on_btnCreateDb_clicked()
{
    //获取数据库名, 清空
    QString createDatabaseName = ui->lenCreateDb->text();
    qDebug() << getUsername();
    ui->lenCreateDb->clear();
    //调用创建数据库的函数
    QStringList strList = {"create","database",createDatabaseName};
    op_ui->createDataBase(strList);
}
//刷新数据库
void showwindow::on_btnRefreshDb_clicked()
{
    QFile file("D:/dbms/File/database.txt");
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
        ui->cbnDropDb->clear();
        ui->cbnUseDb->clear();
        while (!in.atEnd()) {
            QString line = in.readLine();
            ui->cbnDropDb->addItem(line);
            ui->cbnUseDb->addItem(line);
        }
        file.close();
    }
}
//删除数据库
void showwindow::on_btnDropDb_clicked()
{
    // 获取选中的数据库名，清空
    QString dropDatabaseName = ui->cbnDropDb->currentText();  // 从下拉菜单获取数据库名
    qDebug() << "Database to be deleted:" << dropDatabaseName;

    // 从下拉框中移除已选择的数据库名
    int currentIndex = ui->cbnDropDb->currentIndex();
    ui->cbnDropDb->removeItem(currentIndex);

    // 调用删除数据库的函数
    QStringList strList = {"drop", "database", dropDatabaseName};
    op_ui->dropDatabase(strList);
}

//使用数据库
void showwindow::on_btnUseDb_clicked()
{
    // 获取选中的数据库名，并存储到全局变量
    databaseName = ui->cbnUseDb->currentText();
    qDebug() << "Using database:" << databaseName;

    // 显示与表操作相关的界面组件
    ui->btnCreateTb->show();
    ui->btnDropTb->show();
    ui->btnUseTb->show();
    ui->cbnDropTb->show();
    ui->cbnUseTb->show();
    ui->btnRefershTb->show();

    // 隐藏表详细操作组件
    ui->btnCreateIndex->hide();
    ui->btnCreateView->hide();
    ui->btnUpdateField->hide();
    ui->btnDropIndex->hide();
    ui->btnDropView->hide();

    // 读取表文件并填充表相关的下拉框
    loadTables();
}
//刷新表名
void showwindow::loadTables() {
    QString filePath = "D:/dbms/File/" + databaseName + "/table.txt";  // 构造表文件的路径
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
        ui->cbnDropTb->clear();  // 清空下拉框
        ui->cbnUseTb->clear();
        while (!in.atEnd()) {
            QString line = in.readLine();
            ui->cbnDropTb->addItem(line);  // 添加表名到下拉框
            ui->cbnUseTb->addItem(line);
        }
        file.close();
    } else {
        qDebug() << "Failed to open table file:" << filePath;
    }
}
//创建表
void showwindow::on_btnCreateTb_clicked()
{
    QDialog *dialog = new QDialog(this);
    dialog->setWindowTitle("Create Table");

    // 创建和设置 UI 组件
    QLabel *labelTableName = new QLabel("表名", dialog);
    QLineEdit *editTableName = new QLineEdit(dialog);

    QLabel *labelFields = new QLabel("字段", dialog);
    QTextEdit *editFields = new QTextEdit(dialog);

    QPushButton *buttonApply = new QPushButton("Apply", dialog);
    //qDebug() << "ui中的用户名称now"<< getUsername();
    connect(buttonApply, &QPushButton::clicked, [dialog,editTableName, editFields](){
        QString tableName = editTableName->text();
        QString fields = editFields->toPlainText();
        //qDebug() << getUsername();
        qDebug() << "Table Name:" << tableName << "Fields:" << fields;
        QString str = "create table " + tableName + " (" + fields + ")";
        QStringList strList = str.split(" ");
        QString currentList = "D:/dbms/File/"+databaseName;
        //调用创建表的函数
        op_ui->createTable(strList,currentList);
        dialog->accept();
    });

    QPushButton *buttonCancel = new QPushButton("Cancel", dialog);
    connect(buttonCancel, &QPushButton::clicked, dialog, &QDialog::reject);

    // 配置布局
    QVBoxLayout *layoutMain = new QVBoxLayout(dialog);
    QHBoxLayout *layoutTableName = new QHBoxLayout();
    layoutTableName->addWidget(labelTableName);
    layoutTableName->addWidget(editTableName);

    QHBoxLayout *layoutFields = new QHBoxLayout();
    layoutFields->addWidget(labelFields);
    layoutFields->addWidget(editFields);

    QHBoxLayout *layoutButtons = new QHBoxLayout();
    layoutButtons->addWidget(buttonApply);
    layoutButtons->addWidget(buttonCancel);

    layoutMain->addLayout(layoutTableName);
    layoutMain->addLayout(layoutFields);
    layoutMain->addLayout(layoutButtons);

    dialog->setLayout(layoutMain);
    dialog->setAttribute(Qt::WA_DeleteOnClose);
    dialog->exec(); // 显示对话框为模态
}
//删除表
void showwindow::on_btnDropTb_clicked()
{
    // 获取要删除的表名
    QString dropTablename = ui->cbnDropTb->currentText();
    //移除对应表名
    int currentIndex = ui->cbnDropTb->currentIndex();
    ui->cbnDropTb->removeItem(currentIndex);
    //调用删除表的函数
    QStringList strList = {"drop", "table",dropTablename};
    QString currentList = "D:/dbms/File/"+databaseName;
    op_ui->dropTable(strList,currentList);
}
//刷新表按钮
void showwindow::on_btnRefershTb_clicked()
{
    //调用刷新表名函数
    loadTables();
}
//使用表
void showwindow::on_btnUseTb_clicked()
{
    // 获取选中的表名，并存储到全局变量
    tableName = ui->cbnUseTb->currentText();
    qDebug() << "Using table:" << tableName;
    //显示组件
    ui->btnCreateIndex->show();
    ui->btnCreateView->show();
    ui->btnUpdateField->show();
    ui->btnDropIndex->show();
    ui->btnDropView->show();
}
//更新字段
void showwindow::on_btnUpdateField_clicked()
{
    QDialog *dialog = new QDialog(this);
    dialog->setWindowTitle("Update Field");
    dialog->resize(400, 300);  // 设置初始窗口大小

    // 主布局
    QVBoxLayout *mainLayout = new QVBoxLayout(dialog);

    // 选择操作类型：add, modify, drop
    QGroupBox *choiceGroup = new QGroupBox("Operation Type", dialog);
    QHBoxLayout *choiceLayout = new QHBoxLayout(choiceGroup);
    QRadioButton *addButton = new QRadioButton("Add");
    QRadioButton *modifyButton = new QRadioButton("Modify");
    QRadioButton *dropButton = new QRadioButton("Drop");
    choiceLayout->addWidget(addButton);
    choiceLayout->addWidget(modifyButton);
    choiceLayout->addWidget(dropButton);
    mainLayout->addWidget(choiceGroup);

    // 中间部分的组件初始化，但会根据选择显示
    QVBoxLayout *middleLayout = new QVBoxLayout();
    QLabel *actionLabel = new QLabel(dialog);
    QLineEdit *inputLineEdit = new QLineEdit(dialog);
    QComboBox *choiceComboBox = new QComboBox(dialog);
    QStringList items{"Item1", "Item2", "Item3"}; // 示例数组
    choiceComboBox->addItems(items);

    // 默认隐藏中间组件
    actionLabel->setVisible(false);
    inputLineEdit->setVisible(false);
    choiceComboBox->setVisible(false);
    middleLayout->addWidget(actionLabel);
    middleLayout->addWidget(choiceComboBox);
    middleLayout->addWidget(inputLineEdit);
    mainLayout->addLayout(middleLayout);

    // 按钮
    QHBoxLayout *buttonsLayout = new QHBoxLayout();
    QPushButton *applyButton = new QPushButton("Apply", dialog);
    QPushButton *cancelButton = new QPushButton("Cancel", dialog);
    buttonsLayout->addWidget(applyButton);
    buttonsLayout->addWidget(cancelButton);
    applyButton->setVisible(false); // 默认隐藏Apply按钮
    mainLayout->addLayout(buttonsLayout);

    // 单选按钮逻辑
    QObject::connect(addButton, &QRadioButton::toggled, [actionLabel, inputLineEdit, choiceComboBox, applyButton](bool checked) {
        if (checked) {
            actionLabel->setText("Add");
            actionLabel->setVisible(true);
            inputLineEdit->setVisible(true);
            choiceComboBox->setVisible(false);
            applyButton->setVisible(true);
        }
    });

    QObject::connect(modifyButton, &QRadioButton::toggled, [this,actionLabel, inputLineEdit, choiceComboBox, applyButton](bool checked) {
        if (checked) {
            //填充下拉框
            this->updateComboBoxWithFields("D:/dbms/File/"+databaseName+"/"+tableName+".frm",choiceComboBox);
            actionLabel->setText("Modify DataType:");
            actionLabel->setVisible(true);
            inputLineEdit->setVisible(true);
            choiceComboBox->setVisible(true);
            applyButton->setVisible(true);
        }
    });

    QObject::connect(dropButton, &QRadioButton::toggled, [this,actionLabel, choiceComboBox, inputLineEdit, applyButton](bool checked) {
        if (checked) {
            //填充下拉框
            this->updateComboBoxWithFields("D:/dbms/File/"+databaseName+"/"+tableName+".frm",choiceComboBox);
            actionLabel->setText("Drop:");
            actionLabel->setVisible(true);
            choiceComboBox->setVisible(true);
            inputLineEdit->setVisible(false);
            applyButton->setVisible(true);
        }
    });

    // 应用按钮逻辑
    connect(applyButton, &QPushButton::clicked, [addButton, modifyButton, dropButton, inputLineEdit, choiceComboBox](){
        if (addButton->isChecked()) {
            QString field = inputLineEdit->text();
            qDebug() << "Added field:" << field;
            //添加字段函数
            QString str = "alter table " + tableName +" add " + field;
            QStringList strList = str.split(" ");
            QString currentList = "D:/dbms/File/"+databaseName;
            op_ui->alterTableField(strList,currentList,str);
        } else if (modifyButton->isChecked()) {
            QString fieldName = choiceComboBox->currentText();
            QString dataType = inputLineEdit->text();
            qDebug() << "Modified field:" << fieldName << "to data type:" << dataType;
            //修改字段函数
            QString str = "alter table " + tableName + " modify column " + fieldName + " " + dataType;
            QStringList strList = str.split(" ");
            QString currentList = "D:/dbms/File/"+databaseName;
            op_ui->alterTableField(strList,currentList,str);
        } else if (dropButton->isChecked()) {
            QString fieldName = choiceComboBox->currentText();
            qDebug() << "Dropped field:" << fieldName;
            choiceComboBox->removeItem(choiceComboBox->currentIndex());
            //删除字段函数
            QString str = "alter table " + tableName + " drop " + fieldName;
            QStringList strList = str.split(" ");
            QString currentList = "D:/dbms/File/"+databaseName;
            op_ui->alterTableField(strList,currentList,str);
        }
    });

    // 取消按钮逻辑
    connect(cancelButton, &QPushButton::clicked, dialog, &QDialog::reject);

    // 显示对话框
    dialog->setLayout(mainLayout);
    dialog->exec();  // 以模态方式运行对话框
}
//获取字段名称
void showwindow::updateComboBoxWithFields(const QString& filePath, QComboBox* comboBox) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open the file:" << filePath;
        return;
    }

    QStringList fieldNames;
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        int firstSpaceIndex = line.indexOf(' ');  // 查找第一个空格的位置
        if (firstSpaceIndex != -1) {
            QString fieldName = line.left(firstSpaceIndex);  // 获取空格前的字符串
            fieldNames.append(fieldName);
        }
    }

    file.close();

    comboBox->clear(); // 清空当前下拉列表中的项
    comboBox->addItems(fieldNames); // 添加新的列表项
}
