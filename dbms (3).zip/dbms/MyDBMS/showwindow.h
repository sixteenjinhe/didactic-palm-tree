#ifndef SHOWWINDOW_H
#define SHOWWINDOW_H

#include <QWidget>
#include <QLineEdit>
#include <QComboBox>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
#include <QTextEdit>

namespace Ui {
class showwindow;
}

class showwindow : public QWidget
{
    Q_OBJECT

public:
    explicit showwindow(QWidget *parent = nullptr);
    ~showwindow();

    void setUsername(const QString &username);  // 添加设置用户名的方法
    QString getUsername() const;                // 添加获取用户名的方法

signals:
    void returnToCmd(); // 定义一个信号，用于通知 cmd 窗口重新显示

private slots:
    void on_btnReturn_clicked(); // 返回按钮的槽函数
//    void createDatabase();
//    void deleteDatabase();
//    void useDatabase();
    void refreshDatabases();
    void on_btnCreateDb_clicked();

    void on_btnRefreshDb_clicked();

    void on_btnDropDb_clicked();

    void on_btnUseDb_clicked();

    void loadTables();

    void on_btnCreateTb_clicked();

    void on_btnDropTb_clicked();

    void on_btnRefershTb_clicked();

    void on_btnUseTb_clicked();

    void on_btnUpdateField_clicked();
    void updateComboBoxWithFields(const QString& filePath, QComboBox* comboBox);
private:
    Ui::showwindow *ui;
    QString username;  // 新增私有成员变量来存储用户名
//    QPushButton *btnReturn;
//    QPushButton *btnHelp;
//    QPushButton *btnCreateDb;
//    QPushButton *btnCreateTb;
//    QPushButton *btnDropDb;
//    QPushButton *btnDropTb;
//    QPushButton *btnUseDb;
//    QPushButton *btnUseTb;
//    QPushButton *btnRefreshDb;
//    QPushButton *btnCreateIndex;
//    QPushButton *btnCreateView;
//    QPushButton *btnUpdateField;
//    QLineEdit *lenCreateDb;
//    QComboBox *cbnDropDb;
//    QComboBox *cbnUseDb;
//    QComboBox *cbnDropTb;
//    QComboBox *cbnUseTb;
//    QTextEdit *leftText;
//    QTextEdit *rightText;
};

#endif // SHOWWINDOW_H
