#include "operation.h"
#include <QRegularExpression>
#include <QDate>
operation::operation()
{

}



void operation::createDataBase(QStringList &strList){
     if(strList.size()==3){//语句输入形式正确
         QString databasefolderPath = "D:/dbms/File/"+strList[2];
         QDir dir(databasefolderPath);
         if (dir.exists()) {//如果该文件夹已经存在
            qDebug() << "Database already exists;";
          }
         else
         {
            if (dir.mkpath(".")) {//if语句判断dir.mkpath(".")的返回值是否为真。如果为真，则目录创建成功
                qDebug() << "Database created successfully;";
            }
            else
                qDebug() << "Failed to create Database;";
         }
     }
     else qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
}

QString operation::useDataBase(QStringList &strList){

    QString currentPath;
    if(strList.size()==2){//语句输入形式正确
        QString DataBaseName = strList[1];//用户要打开的数据库名称
        QDir dir("D:/dbms/File");

        if(dir.exists(DataBaseName))//如果已经存在这个数据库
        {
            currentPath = "D:/dbms/File/"+DataBaseName;//改变全局变量，获取当前数据库的目录地址，相当于打开数据库
            qDebug()<<"Database changed;";
        }
        else//不存在这个数据库，报错
        {
            qDebug() << "Error:The Database is not exist;";
        }
    }
    else {
        qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
    }
    return currentPath;//返回数据库路径

}


void operation::createTable(QStringList &strList,QString currentPath){
    //qDebug()<<currentPath;
    QString str = strList.join(" ");//把字符串数组重新变回QString,为了找出（）中间的语句，相当于恢复之前的命令语句
    int index1 = str.indexOf('(');//第一个出现的‘（’
    int index2 = str.lastIndexOf(')');//查找最后出现的一个‘）’，因为中间语句也许有），比如VARCHAR(10)
    if(index2!=str.length()-1){//容错：最后）和；之间还有字符
        qDebug() << "Wrong Sentence;";
    }
    if (index1 == -1||index2==-1) {//容错：没有（或）
        qDebug() << "Error Character( or ) not found;";
    }
     else {
        QString result = str.mid(index1+1, index2-index1-1);//找到（ ）中间的语句，即要存储的内容
        QStringList  resultList = result.split(",");//把中间的命令用，拆分,也就是拆分为一个个属性
//        for(int i=0;i<resultList.size();i++)
//            qDebug()<<resultList[i];

        QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名

        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
            qDebug() << "Please select database first;";
        }
        else//已经选择了使用的数据库
        {
            QFile file(currentPath+"/"+tablename+".frm");//数据定义文件的路径;

            if (file.exists()) // 检查数据结构文件是否已经存在
            {
                qDebug() << "This table has already exists;";
                return;
            }
            else
            {
                if (file.open(QIODevice::WriteOnly)| QIODevice::Text)//文件创建成功,以文本模式打开
                {
                    QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                    for(int i=0;i<resultList.size();i++)// 将用户写的表结构写入数据定义文件.frm
                       stream << resultList[i]<< endl;//在行末添加换行符，一个属性在文件里一行
                    file.close();
                    qDebug() << "successfully create this table;";
                }
                else
                {
                    qDebug() << "Failed to create this table;";
                }
            }
        }

    }
}

void operation::descTable(QStringList &strList,QString currentPath){
    QStringList fieldList;//字符串数组，每个元素存储一行，也就是一个属性的结构
    if(strList.size()==2){//语句输入形式正确
        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
            qDebug() << "Please select database first;";
        }
        else{//已经打开了数据库
            QFile file(currentPath+"/"+strList[1]+".frm");//数据定义文件的路径;
            if (!file.exists()) //如果数据结构文件不存在
            {
                qDebug() << "This table has not exists,please create it first;";
                return;
            }
            else{//之前已经创建过这个表，可以查询他的结构
                if (file.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
                {
                    QTextStream in(&file); // 使用QTextStream读取文件内容
                    while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line = in.readLine(); // 一行一行读取内容
                        fieldList<<line;//把每个属性的那一行追加到字符串数组中
                    }
                    file.close(); // 关闭文件

//                  for(int i=0;i<fieldList.size();i++)
//                    qDebug()<<fieldList[i];
                    int row=fieldList.size();//输出有几行，也就是一共几个属性
                    QString property[row][5];//输出的表结构相当于一个二维数组，列有fiel,type,null,key,default
                    for(int i=0;i<row;i++){
                       if(fieldList[i].size()<2)
                          qDebug()<<"Wrong sentence";
                       else{
                          property[i][0] = fieldList[i].section(" ", 0, 0);//获取第一个空格前的内容，即属性名

                          int SpaceIndex1=fieldList[i].indexOf(' ');  // 获取第一个和第二个空格的索引
                          int SpaceIndex2=fieldList[i].indexOf(' ',SpaceIndex1+1);
                          //获取第二个词语，也就是类型
                          property[i][1]=fieldList[i].mid(SpaceIndex1+1,SpaceIndex2-SpaceIndex1-1);

                          if (fieldList[i].contains("not null")) {//如果有‘not null'
                              property[i][2]="NO";
                              fieldList[i].remove(" not null");//删去该字符串，使得最后就剩key关键字
                          }
                          else property[i][2]="Yes";

                          if(fieldList[i].contains("default")){//如果有默认
                              QStringList rowList = fieldList[i].split(" ");//拆分，为了查default下一个
                              int indexdv = rowList.indexOf("default");
                              if (indexdv != -1 && indexdv + 1 < rowList.size()){
                                  property[i][3] = rowList.at(indexdv + 1);
                                  fieldList[i].remove(" default");
                                  fieldList[i].remove(property[i][3]);//删去该字符串，使得最后就剩key关键字
                              }
                          }
                          else property[i][3]="None";

                          if (SpaceIndex2!=-1)
                             property[i][4] = fieldList[i].mid(SpaceIndex2 + 1);//获取key关键字
                        }
                    }


//                    for(int i=0;i<row;i++)
//                        qDebug()<<fieldList[i];

                    qDebug()<<" Field  Type  Null  Default  key";//输出结构表
                    qDebug()<<"------------------------------------";
                    for(int i=0;i<row;i++){
                       qDebug()<<property[i][0]+" "+property[i][1]+" "+property[i][2]+" "
                               +property[i][3]+" "+property[i][4];
                       qDebug()<<"------------------------------------";
                    }
                    qDebug()<<"This is the table you want to check;";

                }
                else {
                    qDebug() << "Failed to open this table file;";
                    return;
                }
            }
        }
    }
    else{
        qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
    }
}

QStringList operation::getFieldList(QStringList &strList,QString currentPath) {
    QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名——规定表名前后都必须有空格
    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList;//字符串数组，每个元素存储一行，也就是一个属性的结构
    int rowfield = 0;
    QFile readfile(currentPath+"/"+tablename+".frm");//对应数据库与表名的文件
    if (!readfile.exists()) //如果数据结构文件不存在
    {
        qDebug() << "This table has not exists,please create it first;";
    }
    else {//存在表字段文件
        if (readfile.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
        {
            QTextStream in(&readfile); // 使用QTextStream读取文件内容
            while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
            {
                QString line = in.readLine(); // 一行一行读取内容
                fieldList<<line;//把每个属性的那一行追加到字符串数组中
            }
            readfile.close(); // 关闭文件
        }
        else {
            qDebug() << "Failed to open this table file;";
        }

    }
    return fieldList;
}
void operation::readField(QStringList &strList,QString currentPath,QString (*property)[5]) {
    QStringList fieldList = getFieldList(strList,currentPath);
    int rowfield=fieldList.size();//输出有几行，也就是一共几个属性
    for(int i=0;i<rowfield;i++){
       if(fieldList[i].size()<2)
          qDebug()<<"Wrong sentence";
       else{
          property[i][0] = fieldList[i].section(" ", 0, 0);//获取第一个空格前的内容，即属性名

          int SpaceIndex1=fieldList[i].indexOf(' ');  // 获取第一个和第二个空格的索引
          int SpaceIndex2=fieldList[i].indexOf(' ',SpaceIndex1+1);
          //获取第二个词语，也就是类型
          property[i][1]=fieldList[i].mid(SpaceIndex1+1,SpaceIndex2-SpaceIndex1-1);

          if (fieldList[i].contains("not null")) {//如果有‘not null'
              property[i][2]="NO";
              fieldList[i].remove(" not null");//删去该字符串，使得最后就剩key关键字
          }
          else property[i][2]="Yes";

          if(fieldList[i].contains("default")){//如果有默认
              QStringList rowList = fieldList[i].split(" ");//拆分，为了查default下一个
              int indexdv = rowList.indexOf("default");
              if (indexdv != -1 && indexdv + 1 < rowList.size()){
                  property[i][3] = rowList.at(indexdv + 1);
                  fieldList[i].remove(" default");
                  fieldList[i].remove(property[i][3]);//删去该字符串，使得最后就剩key关键字
              }
          }
          else property[i][3]="None";

          if (SpaceIndex2!=-1)
             property[i][4] = fieldList[i].mid(SpaceIndex2 + 1);//获取key关键字
        }
    }
}

void operation::insertToTable(QStringList &strList,QString currentPath,QString str){
    //调用insert语句检查函数，查验输入的str是否符合条件——如括号匹配，逗号等
    QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名——规定表名前后都必须有空格
    qDebug() << "tablename：" << tablename;

    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
    int rowfield = fieldList.size();
    QString property[rowfield][5];
    readField(strList,currentPath,property);//获取字段信息二维数组
    //打印查看获取的字段数组是否准确-----------------------
    qDebug()<<" Field  Type  Null  Default  key";//输出结构表
    qDebug()<<"------------------------------------";
    for(int i=0;i<rowfield;i++){
       qDebug()<<property[i][0]+" "+property[i][1]+" "+property[i][2]+" "
               +property[i][3]+" "+property[i][4];
       qDebug()<<"------------------------------------";
    }
    qDebug()<<"This is the table you want to check;";
    //--------------------------------------


    //strList[3]为列参数表，则为有列参数表，strList[3]为values，则为无列参数表，即全参
    bool hasFieldParameters;//标记有无列参数表
    int startpos = strList[3].indexOf("(");//查找第一个出现的 "("
    int endpos = strList[3].indexOf(")");//查找第一个出现的 ")"
    QString fieldresult;//存放列参数字符串
    QStringList fieldNameList;//存放获取的列参数表，即字段名称
    //判断有无参数列表
    if(startpos != -1 && endpos != -1 && endpos > startpos) {
        hasFieldParameters = true;
    }else if(strList[3].compare("values")==0) {
        hasFieldParameters = false;
    }else {
        qDebug() << "wrong insert sentence;";
        return;
    }

    if(hasFieldParameters){ //有参数列表
        //获取列参数表
        fieldresult = strList[3].mid(startpos+1,endpos-startpos-1);//获取参数列表
        fieldNameList = fieldresult.split(",");//把中间的命令用，拆分,获得列参数数组，如[sno,sname,sage]
    }else { //无参数列表，即为全参数
        for(int i = 0; i < rowfield; i++) {
            fieldNameList.append(property[i][0]);
        }
    }
    qDebug() << "fieldNameList:" << fieldNameList;//打印获取的列参数表验证


    //获取数据列表，以()括号内内容为一条数据，()间以，隔开，并判断语句正确性
    QStringList dataList;//一维数组，一个元素表示一条记录
    QString dataStr;//存放要插入的总数据
    int enddataIndex;//表示记录结束位置
    //获取数据记录dataStr
    if(hasFieldParameters) { //有参数列表，说明strList[5]为数据
        enddataIndex = strList[5].lastIndexOf(";") - 1;
        dataStr = strList[5].mid(0,enddataIndex);
    } else { //无参数列表，说明strList[4]为数据
        enddataIndex = strList[4].lastIndexOf(";") - 1;
        dataStr = strList[4].mid(0,enddataIndex);
    }
    //将dataStr拆分成dataList
    int bracketOpenIndex = -1;//左括号索引
    int bracketCloseIndex = -1;//右括号索引
    int rowdata = 0;//数据记录数

    if (dataStr.isEmpty()) {
        qDebug() << "Data string is empty!";
        return;
    }
    qDebug() << "dataStr:" << dataStr;
    //循环提取每对括号内的数据
    dataStr = " " + dataStr + " ";//在数据串前后加一个空格以整体判断
    for (int i = 0; i < dataStr.length(); i++) {
        if (dataStr.at(i) == '(' && (dataStr.at(i-1) == ' ' || dataStr.at(i-1) == ',')) {//匹配到左括号，左括号前是空格或，号
            bracketOpenIndex = i;//更新左括号索引为当前
        }
        else if (dataStr.at(i) == ')' && (dataStr.at(i+1) == ' ' || dataStr.at(i+1) == ',')) {//匹配到右括号,右括号后是,号
            bracketCloseIndex = i;//更新右括号索引为当前
            QString data = dataStr.mid(bracketOpenIndex + 1, bracketCloseIndex - bracketOpenIndex - 1);//将左右括号间的值放入数组中位一条记录
            dataList.append(data);
            rowdata++;//更新数据记录行数
        }
    }
    qDebug() << "DataList:" << dataList;
    qDebug() << "rowdata:" << rowdata;
    //将dataList按","拆分成dataRecord二维数组，之后用二维数组精准判断插入数据是否合法
    // 创建二维数组
    QVector<QVector<QString>> dataRecord(rowdata, QVector<QString>());
    int columndata[rowdata];
    memset(columndata, 0, sizeof(columndata));//显式循环初始化数组值为0
    // 遍历 dataList，对每个元素按逗号拆分并存入二维数组
    for (int i = 0; i < rowdata; i++) {
        QStringList elements = dataList[i].split(",");
        for (int j = 0; j < elements.size(); ++j) {
            dataRecord[i].append(elements[j]);
            columndata[i]++;
        }
    }
    for(int i = 0; i < rowdata; i++) {
       qDebug() << "columndata:" << columndata[i];
    }

    // 输出二维数组
    for (int i = 0; i < dataRecord.size(); ++i) {
        QString rowOutput; // 存储当前行的输出
        for (int j = 0; j < dataRecord[i].size(); ++j) {
            rowOutput += dataRecord[i][j] + " "; // 拼接每个元素的字符串形式，并添加空格分隔
        }
        qDebug() << rowOutput; // 打印整行
        qDebug() << "---------"; // 每行之间添加分隔符
    }


    //匹配判断插入数据的合理性——包括数据格式是否正确，数据是否和列参数表匹配，列参数表是否合法，是否符合约束条件
    bool isfieldNameListMatch = true;//标记列参数表是否匹配文件中字段
    for (const QString& fieldName : fieldNameList) {
        bool found = false;
        for (int i = 0; i < rowfield; i++) {
            if (fieldName == property[i][0]) {
                found = true;  // 找到了当前元素
                break;
            }
        }
        if (!found) {
            isfieldNameListMatch = false;  // 当前元素未找到，返回假
        }
    }
    qDebug() << "isfieldNameListMatch:" << isfieldNameListMatch;

    bool isdatacolumnListMatch = true;//标记单行数据个数是否匹配列参数表
    for (int i = 0; i < rowdata; i++) {
        if(columndata[i] != fieldNameList.size()){
            isdatacolumnListMatch = false;
        }
    }
    qDebug() << "isdatacolumnListMatch:" << isdatacolumnListMatch;

    bool rightdataStr = true;
    QVector<QVector<QString>> newdataRecord(rowdata, QVector<QString>());
    if(isfieldNameListMatch && isdatacolumnListMatch) { //列参数表和文件中匹配且每行数据的个数和列参数表一样
        //对于字段约束，循环判断一条记录
        for(int i = 0; i < rowdata; i++) {
            //调整dataRecord的数量和位置以符合文件中的全参数表，在列参数表未出现的地方赋NULL
            QVector<QString> dataRecordnew(rowfield,NULL);
            for (int k = 0; k < fieldNameList.size(); k++) {
                for(int j = 0; j < rowfield; j++) {
                    if(fieldNameList[k].compare(property[j][0]) == 0){//在全参中找到列参中对应的字段名
                        dataRecordnew[j] = dataRecord[i][k];
                    }
                }
            }
            bool caninsert0 = dataRecordJudge(property,dataRecordnew,rowfield,columndata[i],fieldNameList);//调用函数检查本条记录是否合法
            for (int k = 0; k < rowfield; k++)
            {
                qDebug() << "xin:" << dataRecordnew[k];
            }
            newdataRecord[i] = dataRecordnew; //获取填充好的数组存入文件

            bool caninsert1 = true;//检验Check条件——一个大工程

            if (caninsert0 == false || caninsert1 == false) {
                rightdataStr = false;
                break;//一旦检测到不能插入的数据记录，则退出循环
            }
        }
        for (int k = 0; k < rowdata; k++)
        {
            qDebug() << "xindata:" << newdataRecord[k];
        }
        //对于表约束，对全数据判断——表约束要先读取数据文件中所有数据
        if(!tableLC(strList,currentPath,tablename,newdataRecord)){
            rightdataStr = false;
        }

        if(rightdataStr == true) {
            //数据保存到文件中——在特定名数据库文件夹下，创建一个与表名同名文件，后缀为trd
            saveDataToFile(currentPath,newdataRecord,tablename);
            qDebug() << "successfully insert datas;";
        }else qDebug() << "Incorrect data format, insertion failed;";

    }
}

//从数据文件中读取所有数据
QVector<QVector<QString>> operation::readData(QString currentPath,QString tablename) {
    QStringList dataList;
    int rowdata = 0;
    QFile file(currentPath+"/"+tablename+".trd");  // 替换为实际的文件名
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) { //逐行读取文件内容，直到文件末尾
            QString line = in.readLine();
            dataList << line;//把每一行数据追加到字符串数组中
            rowdata++;
        }
        file.close();//关闭文件
        QVector<QVector<QString>> data(rowdata, QVector<QString>());
        qDebug() <<"dataList.size():" << dataList.size();
        // 遍历dataList，对每个元素按逗号拆分并存入二维数组
        for (int i = 0; i < dataList.size(); i++) {
            QStringList elements = dataList[i].split(",");
            qDebug() <<"elements.size():" << elements.size();
            for (int j = 0; j < elements.size(); j++) {
                data[i].append(elements[j]);
            }
        }
        qDebug() << data;
        return data;
    }else qDebug() << "Failed to open this data file";
}

//对数据文件中表约束条件的判断
bool operation::tableLC(QStringList &strList,QString currentPath,QString tablename,QVector<QVector<QString>> newdataRecord) { //
    //unique和primary
    QVector<QVector<QString>> data = readData(currentPath,tablename);//获取文件中数据的二维数组
    for (const auto &row : newdataRecord) { //将文件中数据和新添数据合并到一起
        data.append(row);
    }
    data.erase(std::remove(data.begin(), data.end(), QVector<QString>{""}), data.end());//去除空数据行
    //读取表字段文件，获取文件中表字段的二维数组
    QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
    int rowfield = fieldList.size();
    QString property[rowfield][5];
    readField(strList,currentPath,property);//获取字段信息二维数组
    //primary判断——唯一，非空
    qDebug() << data;
    for(int i = 0; i < rowfield; i++) {
        if(property[i][4].compare("primary")==0) {//第i个属性为主键
            qDebug() << "存在主键";
            for(int j = 0; j < data.size(); j++) {
                for(int k = 0; k < data.size(); k++) {
                    if(data[j][i]==data[k][i] && k != j) {//主键存在相同元素
                        return false;
                    }
                }
                if(data[j][i]==NULL) {//主键为空
                    return false;
                }
            }
        }else if(property[i][4].compare("unique")==0) {//第i个为unique
            for(int j = 0; j < data.size(); j++) {
                for(int k = 0; k < data.size(); k++) {
                    if(data[j][i]==data[k][i] && k != j) {//主键存在相同元素
                        return false;
                    }
                }
            }
        }
    }
    return true;
}


void operation::alterTableField(QStringList &strList,QString currentPath,QString str) {
    QString tablename = strList[2];//获取表名
    //检验数据库中是否存在表名
    if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
        qDebug() << "Please select database first;";
        return;
    }
    else{//已经打开了数据库
        QFile file(currentPath+"/"+tablename+".frm");//数据定义文件的路径;
        if (!file.exists()) //如果数据结构文件不存在
        {
            qDebug() << "This table has not exists,please create it first;";
            return;
        }
        else{//确保数据库打开，表存在，可执行表字段操作
            int addfieldNum = 0;
            QStringList addfieldstr;
            //定义正则表达式模式-例：add sno int
            QRegularExpression addregex("add ([^,]+)");
            QRegularExpressionMatchIterator matchIterator = addregex.globalMatch(str);//在字符串中查找匹配项
            // 遍历匹配结果
            while (matchIterator.hasNext()) {
                QRegularExpressionMatch match = matchIterator.next();
                QString data = match.captured(1);
                addfieldNum++;//获取新增的字段数量
                addfieldstr.append(data);
                qDebug() << data;
            }
            // 创建新字段信息二维数组，格式为{{列名，数据类型，[完整性约束]},{表级完整性约束}}
            // <表示句子错误，=2表示无完整性约束，=3表示有完整性约束，=1表示为表级完整性约束
            QVector<QVector<QString>> addfieldinfo(addfieldNum, QVector<QString>());//新增字段信息的二维数组
            //按空格拆分成二维数组
            for (int i = 0; i < addfieldNum; i++) {
                QStringList elements = addfieldstr[i].split(" ");
                for (int j = 0; j < elements.size(); ++j) {
                    addfieldinfo[i].append(elements[j]);
                }
            }
            qDebug() <<addfieldinfo;

            //读取表中已有字段信息，存储在property二维数组中
            QStringList fieldList = getFieldList(strList,currentPath);//获取从文件中读取的字段字符串
            int rowfield = fieldList.size();
            QString property[rowfield][5];
            readField(strList,currentPath,property);//获取字段信息二维数组
            bool canAddField = true;//标记新增字段能否插入表文件,默认为可添加，若遇到重复字段则不能添加

            for (int i = 0; i < addfieldinfo.size(); i++) {//循环判断每一行是否符合插入条件
                if(addfieldinfo[i].size() < 2) { //语句出错
                    qDebug() << "wrong alter sentence;";
                    return;
                }else if(addfieldinfo[i].size()>=2) { //该行不是表级约束条件
                    //判断字段名是否重复——与文件中比较
                    for(int k = 0; k < rowfield; k++) {
                        if(addfieldinfo[i][0].compare(property[k][0])==0) {
                            canAddField = false;
                            break;
                        }
                    }
                    qDebug() << "与文件canaddfield:" << canAddField;
                    //与自身比较
                    for(int k = 0; k < addfieldNum; k++) {
                        if(addfieldinfo[i][0].compare(addfieldinfo[k][0])==0 && i!=k) {
                            canAddField = false;
                            break;
                        }
                    }
                    qDebug() << "与自身canaddfield:" << canAddField;
                    //判断数据类型是否合理
                    if(!rightDataType(addfieldinfo[i][1])) {
                        canAddField = false;
                        break;
                    }
                    qDebug() << "数据类型canaddfield:" << canAddField;
                }else if(addfieldinfo[i].size()==1) {//该行是表级约束

                }
            }
            qDebug() << "canaddfield:" << canAddField;

            if(canAddField) { //没有被限制添加，则将新字段信息加入表定义文件中
                if (file.open(QIODevice::WriteOnly|QIODevice::Append | QIODevice::Text))//文件创建成功,以文本模式打开
                {
                    QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                    for(int i=0;i<addfieldstr.size();i++)// 将用户写的表结构写入数据定义文件.frm
                       stream << addfieldstr[i] << endl;//在行末添加换行符，一个属性在文件里一行
                    file.close();
                    qDebug() << "successfully add field;";
                }
                else
                {
                    qDebug() << "Failed to add field;";
                }
            }else qDebug() << "fieldname or fieldtype is wrong!";
        }
    }
}

//判断数据类型合理函数
bool operation::rightDataType(QString type) {
    if(type.compare("int")==0 || type.compare("boolean")==0 || type.compare("double")==0 ||
            type.compare("date")==0 || type.compare("time")==0 ||
            (type.startsWith("varchar(") && type.endsWith(")")) ||
            (type.startsWith("char(") && type.endsWith(")"))) {
        return true;
    }else return false;
}


//数据保存到特定名称数据库文件夹下，与表名相同的trd文件中
void operation::saveDataToFile (QString currentPath,QVector<QVector<QString>> dataRecord,QString tablename) {
    QFile file(currentPath+"/"+tablename+".trd");//数据存储文件路径
    if (file.open(QIODevice::Append | QIODevice::Text)) {//以文本形式打开文件
        QTextStream out(&file);
        // 遍历二维数组，并将每一行写入文件
        for (const QVector<QString>& row : dataRecord)
        {
            QString line;
            for (const QString& element : row)
            {
                line += element + ","; // 使用逗号和空格连接行中的元素
            }
            line.chop(1); // 移除末尾多余的逗号
            out << line << endl; // 写入文件，并在行末添加换行符
        }
        file.close();
        qDebug() << "successfully insert data;";
    }
    else
    {
        qDebug() << "Failed to insert data;";
    }
}

//检测一条数据记录是否正确匹配列参数表，若正确匹配，返回true
bool operation::dataRecordJudge(QString (*property)[5], QVector<QString>& dataRecord,int rowfield,int columndata,QStringList fieldNameList) {
    qDebug() << "传递过来：";
    for (int i = 0; i < rowfield; ++i)
    {
        for (int j = 0; j < 5; ++j)
        {
            qDebug() << property[i][j];
        }
    }

    //----------------------------------------------------------------
    for (int i = 0; i < rowfield; i++)
    {
        qDebug() << dataRecord[i];
    }
    //检查数据是否符合字段信息
    bool rightDType = false;//默认为不满足，直到通过下方检验
    bool rightDNull = true;//默认为可以为空
    for (int j = 0; j < rowfield; j++) {
        //若该值不为空，判断数据类型是否匹配
        if (dataRecord[j] != NULL) {
            rightDType = false;//判断数据类型是否正确
            bool isWrappedWithQuotes = false;//判断字符串是否被引号包裹
            if (dataRecord[j].startsWith("'") && dataRecord[j].endsWith("'")) {
                isWrappedWithQuotes = true;
                // 字符串被单引号包裹,暂定只能用单引号
            }
    //            else if (dataRecord.startsWith(""") && dataRecord.endsWith(""")) {
    //                isWrappedWithQuotes = true;
    //                // 字符串被双引号包裹
    //            }
            if (property[j][1].compare("int")==0) { //长整数，4字节
                dataRecord[j].toInt(&rightDType);//判断是否为整数
            }else if(property[j][1].compare("boolean")==0) { //逻辑布尔值
                if(dataRecord[j].compare("true")==0 || dataRecord[j].compare("false")==0){
                    rightDType = true;
                }
            }else if(property[j][1].compare("double")==0) { //双精度浮点数
                dataRecord[j].toDouble(&rightDType);
            }else if(property[j][1].compare("date")==0) { //日期，格式为YYYY-MM-DD
                if(isWrappedWithQuotes){
                    QDate date = QDate::fromString(dataRecord[j], "yyyy-MM-dd");
                    if(date.isValid()){
                        rightDType = true;
                    }
                }

            }else if(property[j][1].compare("time")==0) { //时间，格式为HH:MM:DD
                if(isWrappedWithQuotes){
                    QTime time = QTime::fromString(dataRecord[j], "hh:mm:ss");
                    if(time.isValid()){
                        rightDType = true;
                    }
                }

            }else if(property[j][1].startsWith("varchar(") && property[j][1].endsWith(")")) { //最大长度为n的变长字符串
                QString capturedText = property[j][1].mid(8, property[j][1].length() - 9);
                int n = capturedText.toInt();
                if(isWrappedWithQuotes){//字符串被引号包裹，说明可能为字符串类型
                    int startIndex = dataRecord[j].indexOf("'");
                    int endIndex = dataRecord[j].lastIndexOf("'");
                    QString data = dataRecord[j].mid(startIndex+1,endIndex-startIndex-1);
                    qDebug() << "varchardata:" << data;
                    if(data.length() <= n){
                        rightDType = true;
                    }
                }
            }else if(property[j][1].startsWith("char(") && property[j][1].endsWith(")")) { //长度为n的定长字符串
                QString capturedText = property[j][1].mid(8, property[j][1].length() - 9);
                int n = capturedText.toInt();
                if(isWrappedWithQuotes){
                    int startIndex = dataRecord[j].indexOf("'");
                    int endIndex = dataRecord[j].lastIndexOf("'");
                    QString data = dataRecord[j].mid(startIndex+1,endIndex-startIndex-1);
                    qDebug() << "chardata:" << data;
                    if(data.length() == n){
                        rightDType = true;
                    }
                }
            }else {
                qDebug() << "wrong data type;";
            }
            if (rightDType == false) {
                break;
            }
        }else { //若该值为空，判断该字段信息是否要求非空
            //判断是否可以为空
            if (property[j][2].compare("No")==0) { //字段表示不可以为空
                if(dataRecord[j] == NULL) { //但是数据为空，说明不满足字段约束
                    rightDNull = false;
                }
            }
            //判断有无默认值，有默认值则用默认值替代空值
            if (property[j][3].compare("None") != 0) { //字段有默认值
                dataRecord[j] = property[j][3];
            }
        }

        //判断是否有key约束
        if (property[j][4] != NULL) { //存在key约束
            //划分处理key约束
            if (property[j][4].compare("primary")==0) { //该字段为主键——不允许为空，不允许重复

            }
        }

    }

    qDebug() << "rightDType:" << rightDType;
    qDebug() << "rightDNull:" << rightDNull;
    if (rightDType && rightDNull) {
        return true;
    }else return false;
}
