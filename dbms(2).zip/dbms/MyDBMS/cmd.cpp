#include "cmd.h"
#include "ui_cmd.h"
#include "operation.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPlainTextEdit>

cmd::cmd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::cmd)
{
    ui->setupUi(this);
    ui->plainTextEdit->setPlainText("Welcome to mydatabase;\n"); //显示提示语
    ui->plainTextEdit->moveCursor(QTextCursor::End);//把光标移动到文本框末尾 
    this->resize( QSize( 1000, 700 ));//设置大小
}

cmd::~cmd()
{
    delete ui;
}

void cmd::on_plainTextEdit_textChanged()//命令行文本框的槽函数
{
    QString str;//存放每条命令的字符串
    QString inputText = ui->plainTextEdit->toPlainText();//随键盘输入不断获取字符
    str += inputText;//追加到字符串
    //qDebug()<<str;
    QChar lastChar =str.right(1).at(0);//获取最后输入的字符
    QChar secondlastChar =str.right(2).at(0);//获取倒数第二输入的字符
    if(bool bl=operator ==(lastChar,'\n'))//如果最后是‘；\n’说明用户输入命令结束，该执行操作
    {
        if(bool bl=operator ==(secondlastChar,';')){
            QStringList strList = str.split(";");//根据‘;’划分语句，字符串数组中每个元素都是一条命令
            if (strList.size() >= 2) {//确保字符串数组长度大于等于2
                //获取倒数第二个元素，也就是要执行的命令（因为最后一个是换行符）
                QString secondLast = strList.at(strList.size() - 2);
                secondLast.replace("\n", " ");//把要执行的命令中的换行符换成空格
                //如果命令语句第一个为空格，则删除（一般都是，因为之前把\n换成了空格）
                if (secondLast.startsWith(" ")) {
                    secondLast.remove(0, 1);
                }
                secondLast=secondLast.toLower();//统一变成小写字母，方便识别
//                qDebug() << "倒数第二个元素是：" << secondLast;
                split(secondLast);//拆分命令，调用拆分函数
            } else {
                qDebug() << "QStringList大小不够，无法获取倒数第二个元素。";
            }
        }
    }
}

void cmd::split(QString str){//拆分命令
    QStringList strList = str.split(" ");//根据空格拆分，把每个单词存储到字符串数组里,方便识别命令
    operation op(ui);
    if(strList[0].compare("use")==0)//打开数据库
    {
        currentPath=op.useDataBase(strList);//调用打开数据库的函数,同时全局变量currentPath获得数据库地址路径
    }
    else if(strList[0].compare("create")==0)//如果命令第一个词为create,有两种情况：database和table
    {
        if(strList[1].compare("database")==0)//创建数据库
            op.createDataBase(strList);//调用创建数据库函数
        else if(strList[1].compare("table")==0){//创建表
            op.createTable(strList,currentPath);//调用创建表函数
        }
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
    else if(strList[0].compare("desc")==0){//查询表结构
        op.descTable(strList,currentPath);//调用查询表结构函数
    }
    else if(strList[0].compare("insert")==0){//向表中插入信息
        if(strList[1].compare("into")==0)
            op.insertToTable(strList,currentPath,str);//调用向表中插入信息函数
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
    else if(strList[0].compare("alter")==0){//修改表的字段
        if(strList[1].compare("table")==0){
            op.alterTableField(strList,currentPath,str);
        }
    }
    else if(strList[0].compare("select")==0){//查询表的内容
        if(strList.contains("where")){
        op.whereTable(strList,currentPath,str);
        }else
        op.selectTable(strList,currentPath,str);
    }else if(strList[0].compare("delete")==0){//删除记录
         op.deleteTable(strList,currentPath,str);
    }else if(strList[0].compare("update")==0){//更新纪录
         op.updateTable(strList,currentPath,str);
    }else if(strList[0].compare("drop")==0){//删除数据库和表
        if(strList[1].compare("database")==0)//删除数据库
            op.dropDatabase(strList);//调用删除数据库函数
        else if(strList[1].compare("table")==0){//删除表
            op.dropTable(strList,currentPath);//调用删除表函数
        }
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }

}
