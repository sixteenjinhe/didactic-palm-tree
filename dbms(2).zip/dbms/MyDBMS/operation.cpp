#include "operation.h"


operation::operation()
{

}



void operation::createDataBase(QStringList &strList){
     if(strList.size()==3){//语句输入形式正确
         QString databasefolderPath = "D:/dbms/File/"+strList[2];
         QDir dir(databasefolderPath);
         if (dir.exists()) {//如果该文件夹已经存在
            qDebug() << "Database already exists;";
          }
         else
         {
            if (dir.mkpath(".")) {//if语句判断dir.mkpath(".")的返回值是否为真。如果为真，则目录创建成功
                qDebug() << "Database created successfully;";
            }
            else
                qDebug() << "Failed to create Database;";
         }
     }
     else qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
}

QString operation::useDataBase(QStringList &strList){

    QString currentPath;
    if(strList.size()==2){//语句输入形式正确
        QString DataBaseName = strList[1];//用户要打开的数据库名称
        QDir dir("D:/dbms/File");

        if(dir.exists(DataBaseName))//如果已经存在这个数据库
        {
            currentPath = "D:/dbms/File/"+DataBaseName;//改变全局变量，获取当前数据库的目录地址，相当于打开数据库
            qDebug()<<"Database changed;";
        }
        else//不存在这个数据库，报错
        {
            qDebug() << "Error:The Database is not exist;";
        }
    }
    else {
        qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
    }
    return currentPath;//返回数据库路径

}



void operation::createTable(QStringList &strList,QString currentPath){
    //qDebug()<<currentPath;
    QString str = strList.join(" ");//把字符串数组重新变回QString,为了找出（）中间的语句，相当于恢复之前的命令语句
    int index1 = str.indexOf('(');//第一个出现的‘（’
    int index2 = str.lastIndexOf(')');//查找最后出现的一个‘）’，因为中间语句也许有），比如VARCHAR(10)
    if(index2!=str.length()-1){//容错：最后）和；之间还有字符
        qDebug() << "Wrong Sentence;";
    }
    if (index1 == -1||index2==-1) {//容错：没有（或）
        qDebug() << "Error Character( or ) not found;";
    }
     else {
        QString result = str.mid(index1+1, index2-index1-1);//找到（ ）中间的语句，即要存储的内容
        QStringList  resultList = result.split(",");//把中间的命令用，拆分,也就是拆分为一个个属性
//        for(int i=0;i<resultList.size();i++)
//            qDebug()<<resultList[i];

        QString tablename = strList[2].mid(0,strList[2].indexOf('('));//获取表名

        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
            qDebug() << "Please select database first;";
        }
        else//已经选择了使用的数据库
        {
            QFile file(currentPath+"/"+tablename+".frm");//数据定义文件的路径;

            if (file.exists()) // 检查数据结构文件是否已经存在
            {
                qDebug() << "This table has already exists;";
                return;
            }
            else
            {
                if (file.open(QIODevice::WriteOnly)| QIODevice::Text)//文件创建成功,以文本模式打开
                {
                    QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                    for(int i=0;i<resultList.size();i++)// 将用户写的表结构写入数据定义文件.frm
                       stream << resultList[i]<< endl;//在行末添加换行符，一个属性在文件里一行
                    file.close();
                    qDebug() << "successfully create this table;";
                }
                else
                {
                    qDebug() << "Failed to create this table;";
                }
            }
        }

    }
}

void operation::descTable(QStringList &strList,QString currentPath){
    QStringList fieldList;//字符串数组，每个元素存储一行，也就是一个属性的结构
    if(strList.size()==2){//语句输入形式正确
        if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
            qDebug() << "Please select database first;";
        }
        else{//已经打开了数据库
            QFile file(currentPath+"/"+strList[1]+".frm");//数据定义文件的路径;
            if (!file.exists()) //如果数据结构文件不存在
            {
                qDebug() << "This table has not exists,please create it first;";
                return;
            }
            else{//之前已经创建过这个表，可以查询他的结构
                if (file.open(QIODevice::ReadOnly)) //打开文件,读取属性信息
                {
                    QTextStream in(&file); // 使用QTextStream读取文件内容
                    while (!in.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line = in.readLine(); // 一行一行读取内容
                        fieldList<<line;//把每个属性的那一行追加到字符串数组中
                    }
                    file.close(); // 关闭文件

//                  for(int i=0;i<fieldList.size();i++)
//                    qDebug()<<fieldList[i];
                    int row=fieldList.size();//输出有几行，也就是一共几个属性
                    QString property[row][5];//输出的表结构相当于一个二维数组，列有fiel,type,null,key,default
                    for(int i=0;i<row;i++){
                       if(fieldList[i].size()<2)
                          qDebug()<<"Wrong sentence";
                       else{
                          property[i][0] = fieldList[i].section(" ", 0, 0);//获取第一个空格前的内容，即属性名

                          int SpaceIndex1=fieldList[i].indexOf(' ');  // 获取第一个和第二个空格的索引
                          int SpaceIndex2=fieldList[i].indexOf(' ',SpaceIndex1+1);
                          //获取第二个词语，也就是类型
                          property[i][1]=fieldList[i].mid(SpaceIndex1+1,SpaceIndex2-SpaceIndex1-1);

                          if (fieldList[i].contains("not null")) {//如果有‘not null'
                              property[i][2]="NO";
                              fieldList[i].remove(" not null");//删去该字符串，使得最后就剩key关键字
                          }
                          else property[i][2]="Yes";

                          if(fieldList[i].contains("default")){//如果有默认
                              QStringList rowList = fieldList[i].split(" ");//拆分，为了查default下一个
                              int indexdv = rowList.indexOf("default");
                              if (indexdv != -1 && indexdv + 1 < rowList.size()){
                                  property[i][3] = rowList.at(indexdv + 1);
                                  fieldList[i].remove(" default");
                                  fieldList[i].remove(property[i][3]);//删去该字符串，使得最后就剩key关键字
                              }
                          }
                          else property[i][3]="None";

                          if (SpaceIndex2!=-1)
                             property[i][4] = fieldList[i].mid(SpaceIndex2 + 1);//获取key关键字
                        }
                    }


//                    for(int i=0;i<row;i++)
//                        qDebug()<<fieldList[i];

                    qDebug()<<" Field  Type  Null  Default  key";//输出结构表
                    qDebug()<<"------------------------------------";
                    for(int i=0;i<row;i++){
                       qDebug()<<property[i][0]+" "+property[i][1]+" "+property[i][2]+" "
                               +property[i][3]+" "+property[i][4];
                       qDebug()<<"------------------------------------";
                    }
                    qDebug()<<"This is the table you want to check;";
                }
                else {
                    qDebug() << "Failed to open this table file;";
                    return;
                }
            }
        }
    }
    else{
        qDebug()<<"Wrong Sentence";//容错：语句输入格式错误
    }
}

