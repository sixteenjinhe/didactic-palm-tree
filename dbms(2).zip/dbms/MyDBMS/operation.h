#ifndef OPERATION_H
#define OPERATION_H
#include <QDir>
#include <QDebug>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QCoreApplication>
#include "cmd.h"
#include "ui_cmd.h"

class operation
{
public:
    operation();
    void createDataBase(QStringList &strList);
    void createTable(QStringList &strList,QString currentPath);
    QString useDataBase(QStringList &strList);//返回用户选择的数据库地址路径
    void descTable(QStringList &strList,QString currentPath);

};



#endif // OPERATION_H
