/********************************************************************************
** Form generated from reading UI file 'cmd.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CMD_H
#define UI_CMD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cmd
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *plainTextEdit;

    void setupUi(QWidget *cmd)
    {
        if (cmd->objectName().isEmpty())
            cmd->setObjectName(QString::fromUtf8("cmd"));
        cmd->resize(662, 389);
        gridLayout = new QGridLayout(cmd);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));

        gridLayout->addLayout(verticalLayout, 1, 0, 1, 1);

        plainTextEdit = new QPlainTextEdit(cmd);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        plainTextEdit->setFont(font);
        plainTextEdit->setStyleSheet(QString::fromUtf8("background-image:url(:/picture/cmd.jpg)"));

        gridLayout->addWidget(plainTextEdit, 0, 0, 1, 1);


        retranslateUi(cmd);

        QMetaObject::connectSlotsByName(cmd);
    } // setupUi

    void retranslateUi(QWidget *cmd)
    {
        cmd->setWindowTitle(QCoreApplication::translate("cmd", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cmd: public Ui_cmd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CMD_H
