#ifndef INDEX_H
#define INDEX_H
#include <stdio.h>
#include <stdlib.h>
#include <QDir>
#include <QDebug>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QCoreApplication>
#include <algorithm> // 包含sort函数
#include <vector>
#include "cmd.h"
#include "ui_cmd.h"
#include "operation.h"
#include <QString>
#include <QDate>
#include <QtCore/QQueue>
#include <QHash>
#define N 13
#define ADDR_SIZE 8


class Index
{
public:
    Index(Ui::cmd *ui);
    Index(Ui::showwindow *ui);
    typedef  struct Data{
        QString content;
        int rownumber;
    }data;
    //hash表的链表的节点
    typedef struct node {
        data data;//存数据
        struct node *next;//存指针
    }HASH;

    static bool compareData(const data& a, const data& b) {
        return a.content < b.content;
    }
    void build_Index_File(QStringList &strList,QString currentPath);
    void drop_Index(QStringList &strList,QString currentPath,int defaultValue = 1);
    bool build_struct(QString currentPath,QString tablename,QString attribute,QString value,int &rownum);


private:
    Ui::cmd *ui;
    Ui::showwindow *uis;
};

#endif // INDEX_H
