#include "cmd.h"
#include "ui_cmd.h"
#include "operation.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "view.h"
#include "Index.h"
#include "user.h"
#include <QPlainTextEdit>
#include "showwindow.h"

cmd::cmd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::cmd)
{
    ui->setupUi(this);
    ui->plainTextEdit->setPlainText("Welcome to mydatabase;\n"); //显示提示语
    ui->plainTextEdit->moveCursor(QTextCursor::End);//把光标移动到文本框末尾 
    this->resize( QSize( 1000, 700 ));//设置大小
    //btnshowWindow = new QPushButton();
    showWindow = new showwindow(); // 实例化 ShowWindow
    //qDebug() << "获取的用户名：" << getUsername();
    connect(showWindow, &showwindow::returnToCmd, this, &cmd::show); // 连接信号
    connect(ui->btnshowWindow, &QPushButton::clicked, this, &cmd::on_btnshowWindow_clicked); // 连接按钮点击信号
}

cmd::~cmd()
{
    delete ui;
}

void cmd::on_btnshowWindow_clicked()
{
    this->hide(); // 隐藏当前窗口
    showWindow->setUsername(getUsername());
    showWindow->show(); // 显示 ShowWindow
}

void cmd::setUsername(const QString &username) {
    this->username = username;  // 设置成员变量username
}

QString cmd::getUsername() const {
    return username;  // 返回成员变量username
}


void cmd::on_plainTextEdit_textChanged()//命令行文本框的槽函数
{
    QString str;//存放每条命令的字符串
    QString inputText = ui->plainTextEdit->toPlainText();//随键盘输入不断获取字符
    str += inputText;//追加到字符串
    //qDebug()<<str;
    QChar lastChar =str.right(1).at(0);//获取最后输入的字符
    QChar secondlastChar =str.right(2).at(0);//获取倒数第二输入的字符
    if(bool bl=operator ==(lastChar,'\n'))//如果最后是‘；\n’说明用户输入命令结束，该执行操作
    {
        if(bool bl=operator ==(secondlastChar,';')){
            QStringList strList = str.split(";");//根据‘;’划分语句，字符串数组中每个元素都是一条命令
            if (strList.size() >= 2) {//确保字符串数组长度大于等于2
                //获取倒数第二个元素，也就是要执行的命令（因为最后一个是换行符）
                QString secondLast = strList.at(strList.size() - 2);
                secondLast.replace("\n", " ");//把要执行的命令中的换行符换成空格
                //如果命令语句第一个为空格，则删除（一般都是，因为之前把\n换成了空格）
                if (secondLast.startsWith(" ")) {
                    secondLast.remove(0, 1);
                }
                secondLast=secondLast.toLower();//统一变成小写字母，方便识别
//                qDebug() << "倒数第二个元素是：" << secondLast;
                split(secondLast);//拆分命令，调用拆分函数
            } else {
                qDebug() << "QStringList大小不够，无法获取倒数第二个元素。";
            }
        }
    }
}

void cmd::split(QString str){//拆分命令
    QStringList strList = str.split(" ");//根据空格拆分，把每个单词存储到字符串数组里,方便识别命令
    operation op(ui);
    user use(ui);
    Index in(ui);
    View vi(ui);
    if(getUsername() != NULL) {
        use.setUsername(getUsername());
    }
    if(strList[0].compare("use")==0)//打开数据库
    {
        currentPath=op.useDataBase(strList);//调用打开数据库的函数,同时全局变量currentPath获得数据库地址路径
    }
    else if(strList[0].compare("create")==0)//如果命令第一个词为create,有三种情况：database、table、user
    {
        if(strList[1].compare("database")==0)//创建数据库
            op.createDataBase(strList);//调用创建数据库函数
        else if(strList[1].compare("table")==0){//创建表
            op.createTable(strList,currentPath);//调用创建表函数
        }
        else if(strList[1].compare("index")==0){//创建索引
            in.build_Index_File(strList,currentPath);
            QString tableName=strList[4].split("(").first().trimmed();
            QFile file(currentPath+"/"+tableName+".txt");//数据定义存储文件的路径;
            if (file.exists()) // 检查数据结构文件是否已经存在
            {
                if (file.open(QIODevice::Append | QIODevice::Text)) // 文件存在，以文本模式追加打开
                    {
                        QTextStream stream(&file); // 创建一个 QTextStream 对象，并关联文件

                        for(int i = 0; i < strList.size(); i++) {  // 循环遍历 strList 并写入到文件中
                            stream << strList.at(i) << " ";
                        }
                        stream << "\n"; // 写入一个换行符，使得新的 strList 内容写在新的一行中
                        file.close();
                    }
                    else
                    {
                        ui->plainTextEdit->appendPlainText("Wrong;");
                    }
            }
            else
            {
                if (file.open(QIODevice::ReadWrite| QIODevice::Text))//文件创建成功,以文本模式打开
                {
                    QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
                    for(int i=0;i<strList.size();i++){  // 循环遍历strList并写入到文件中
                        stream<<strList.at(i)<<" ";
                    }
                    file.close();
                }
                else
                {
                    ui->plainTextEdit->appendPlainText("Wrong;");
                }
         }
//            int rownum=0;
//            in.build_struct(currentPath,"sc","cno","11",rownum);
//            qDebug()<<rownum;
        }
        else if(strList[1].compare("view")==0){//创建视图
            vi.createview(strList,currentPath);
        }
        else if(strList[1].compare("user")==0){//创建用户——只有根用户才可以创建用户
            //判断为根用户？？？？
            use.createUser(str);//调用创建用户函数
        }
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
    else if(strList[0].compare("desc")==0){//查询表结构
        op.descTable(strList,currentPath);//调用查询表结构函数
    }
    else if(strList[0].compare("show")==0){//展示视图语句
        vi.showview(strList,currentPath);
    }
    else if(strList[0].compare("insert")==0){//向表中插入信息
        if(strList[1].compare("into")==0){
            op.insertToTable(strList,currentPath,str);//调用向表中插入信息函数
        }
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }
    else if(strList[0].compare("alter")==0){//修改表的字段
        if(strList[1].compare("table")==0){
            op.alterTableField(strList,currentPath,str);
        }
    }
    else if(strList[0].compare("select")==0){//查询表的内容
        QFile file(currentPath+"/"+strList[3]+".tdf");
        if(!file.exists()){
            if(strList.contains("where")){
            op.whereTable(strList,currentPath,str);
            }else{
            op.selectTable(strList,currentPath,str);
            }}else{
             vi.selectview(strList,currentPath);
    }
    }else if(strList[0].compare("delete")==0){//删除记录
         op.deleteTable(strList,currentPath,str);
    }else if(strList[0].compare("update")==0){//更新纪录
         op.updateTable(strList,currentPath,str);
    }else if(strList[0].compare("drop")==0){//删除数据库和表、用户
        if(strList[1].compare("database")==0)//删除数据库
            op.dropDatabase(strList);//调用删除数据库函数
        else if(strList[1].compare("table")==0)//删除表
            op.dropTable(strList,currentPath);//调用删除表函数
        else if(strList[1].compare("index")==0){//删除索引
            in.drop_Index(strList,currentPath);//调用删除索引函数
        }
        else if(strList[1].compare("view")==0){
            vi.dropview(strList,currentPath);
        }
        else if(strList[1].compare("user")==0){//删除用户——只有根用户才可以删除用户
            //判断为根用户？？？
            use.dropUser(str);
        }
        else ui->plainTextEdit->appendPlainText("Wrong Sentence;");//容错：语句输入格式错误
    }else if(strList[0].compare("grant")==0){//授予权限
        use.grantPrivileges(str);//调用授予权限函数
    }else if(strList[0].compare("revoke")==0){//撤销权限
        use.revokePrivileges(str);
    }else if(strList[0].compare("show")==0){//展示权限
        if(strList[1].compare("grants")==0 && strList[2].compare("for")==0){
            use.showGrants(str);//调用展示指定用户权限函数
        }
    }

}
