#include "createtbwidget.h"
#include "ui_createtbwidget.h"

CreateTbWidget::CreateTbWidget(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateTbWidget)
{
    ui->setupUi(this);
    this->setAttribute(Qt::WA_DeleteOnClose);
}

CreateTbWidget::~CreateTbWidget()
{
    delete ui;
}
