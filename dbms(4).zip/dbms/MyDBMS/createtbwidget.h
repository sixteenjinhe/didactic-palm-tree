#ifndef CREATETBWIDGET_H
#define CREATETBWIDGET_H

#include <QDialog>

namespace Ui {
class CreateTbWidget;
}

class CreateTbWidget : public QDialog
{
    Q_OBJECT

public:
    explicit CreateTbWidget(QWidget *parent = nullptr);
    ~CreateTbWidget();

private:
    Ui::CreateTbWidget *ui;
};

#endif // CREATETBWIDGET_H
