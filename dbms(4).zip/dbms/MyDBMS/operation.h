#ifndef OPERATION_H
#define OPERATION_H
#include <QDir>
#include <QDebug>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ui_showwindow.h"
#include "showwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QCoreApplication>
#include "cmd.h"
#include "ui_cmd.h"

class operation
{
public:
    operation(Ui::cmd *ui);
    operation(Ui::showwindow *ui);
    void createDataBase(QStringList &strList);
    void createTable(QStringList &strList,QString currentPath);
    QString useDataBase(QStringList &strList);//返回用户选择的数据库地址路径
    void descTable(QStringList &strList,QString currentPath);
    void dropDatabase(QStringList &strList);
    void dropTable(QStringList &strList,QString currentPath);
    QStringList getFieldList(QStringList &strList,QString currentPath);
    void readField(QStringList &strList,QString currentPath,QString (*property)[5]);
    void insertToTable(QStringList &strList,QString currentPath,QString str);
    QVector<QVector<QString>> readData(QString currentPath,QString tablename);
    bool tableLC(QStringList &strList,QString currentPath,QString tablename,QVector<QVector<QString>> newdataRecord);
    void alterTableField(QStringList &strList,QString currentPath,QString str);
    bool rightDataType(QString type);
    void saveDataToFile(QString currentPath,QVector<QVector<QString>> dataRecord,QString tablename);
    bool dataRecordJudge(QString (*property)[5], QVector<QString>& dataRecord,int rowfield,int columndata,QStringList fieldNameList);
    void selectTable(QStringList &strList,QString currentPath,QString str);
    void print(QStringList &strList,QString currentPath);
    void whereTable(QStringList &strList,QString currentPath,QString str);
    void deleteTable(QStringList &strList,QString currentPath,QString str);
    void updateTable(QStringList &strList,QString currentPath,QString str);
    void processIndexFiles(QString currentPath,QString tableName);
    int iscmd;

private:
     Ui::cmd *ui;
     Ui::showwindow *uis;
};



#endif // OPERATION_H
