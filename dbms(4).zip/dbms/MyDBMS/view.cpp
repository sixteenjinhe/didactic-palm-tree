#include "view.h"
#include "operation.h"
#include "cmd.h"
#include "ui_cmd.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QVector>
#include <QRegularExpression>
#include <QDebug>
#include <QString>
#include <QDate>
View::View(Ui::cmd *ui): ui(ui)
{

}
void View::createview(QStringList &strList, QString currentPath) {
    if(currentPath.compare("")==0){//如果当前路径为空，则会报错
        ui->plainTextEdit->appendPlainText("Please select database first;");
        return;
    }
    //将命令存储到文件中
     QFile file(currentPath+"/"+strList[2]+".tdf");//数据定义存储视图文件的路径;
    if (file.exists()) // 检查数据结构文件是否已经存在
    {
        ui->plainTextEdit->appendPlainText("This view has already exists;");
        return;
    }
    else
    {
        if (file.open(QIODevice::ReadWrite| QIODevice::Text))//文件创建成功,以文本模式打开
        {
            QTextStream stream(&file); //创建一个 QTextStream 对象，并关联文件
            for(int i=0;i<strList.size();i++){  // 循环遍历strList并写入到文件中
                stream<<strList.at(i)<<" ";
            }
            file.close();
            ui->plainTextEdit->appendPlainText("successfully create this view;");
        }
        else
        {
            ui->plainTextEdit->appendPlainText("Failed to create this view;");
        }
    }
    qDebug()<<strList;

    }
 void View::showview(QStringList &strList,QString currentPath){
     QFile file(currentPath+"/"+strList[3]+".tdf");
     if (file.open(QIODevice::ReadOnly | QIODevice::Text))
     {
         QTextStream in(&file);
         while (!in.atEnd())
         {
             QString line = in.readLine();
             ui->plainTextEdit->appendPlainText(line+";");
         }
         file.close();
     }else{
         ui->plainTextEdit->appendPlainText("The view does not have;");
     }
 }
 void View::selectview(QStringList &strList, QString currentPath) {
     operation op(ui);
     QFile file(currentPath + "/" + strList[3] + ".tdf");
     QStringList s;
     if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
         QTextStream in(&file);
         while (!in.atEnd()) {
             QString line = in.readLine();
             QStringList lineList = line.split(" ");
            // 从第五个词开始将单词存储到另一个字符串s中
             for (int i = 4; i < lineList.size(); ++i) {
                 s.append(lineList[i]);
             }
         }
           QString st = s.join(" ");
         file.close();
         if (strList.size() > 1 && strList[1].compare("*") == 0) {//查询视图的所有内容
           if(strList.contains("where")){//查询语句含有where
              if (s.contains("where")){
                   complexwhereselect(strList,s,currentPath,st);//子查询里含有where
               }else {
                   complexselect(strList,s, currentPath,st);//子查询中不含有where
               }
             }else{//查询语句不含有where
             if (s.contains("where")) {
                 op.whereTable(s, currentPath,st);//子查询里含有where
             } else {
                 op.selectTable(s, currentPath,st);//子查询中不含有where
             }
         }
         }else{//查询视图的部分内容


             if(strList.contains("where")){//查询语句含有where
                 if (s.contains("where")) {
                   //whereview(strList,currentPath,str);//子查询里含有where
                  }else {
                      //view(strList,s, currentPath);//子查询中不含有where
                  }
             }else{//查询语句中不含有where
                 if (s.contains("where")) {
                   complexwhere(strList,s,currentPath,st);//子查询里含有where
                  }else {
                      complex(strList, s,currentPath,st);//子查询中不含有where
                  }
             }
     }
 }
 }
void View::dropview(QStringList &strList,QString currentPath){
         if(currentPath.compare("")==0){//如果还没有输入过use语句(当前路径为空），则会报错
              ui->plainTextEdit->appendPlainText("Please select database first;");
         }
         else//已经选择了使用的数据库
         {
             QFile file(currentPath+"/"+strList[2]+".tdf");//要删除的数据内容文件的路径;
             if (file.exists()) // 检查要删除的数据结构文件是否存在
             {
                 if (file.remove()) {
                         ui->plainTextEdit->appendPlainText("the view successfully drop;");
                     } else {
                         ui->plainTextEdit->appendPlainText("Failed to drop the view;");
                     }
               }
                 else{
            ui->plainTextEdit->appendPlainText("The view does not exist;");

                 }
         }

 }
void View::complexselect(QStringList &strList,  QStringList s,QString currentPath,QString st){
     operation op(ui);
      QString targetWord = strList[5];
      QString secondWord = strList[6];
      QString symbol = secondWord;
      qDebug()<<symbol;
      //存储比较的数值
      QString thirdWord = strList[7];
      thirdWord.prepend("'");
      thirdWord.append("'");
      qDebug() << thirdWord;
        if(s[1].compare("*")==0){
            op.print(s,currentPath);
            QFile file(currentPath+"/"+s[3]+".frm");//数据定义文件的路径;
            QFile f(currentPath+"/"+s[3]+".trd");
            if (!f.exists()) // 如果数据文件不存在
            {
                ui->plainTextEdit->appendPlainText("This table is empty;");

            }else{
                if (f.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                {
                    QTextStream in2(&f); // 使用QTextStream读取文件内容
                    QStringList lines2; // 存储每一行的内容
                    while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                    {
                        QString line2 = in2.readLine(); // 一行一行读取内容
                        lines2.append(line2); // 将读取的行添加到列表中
                    }
                    f.close(); // 关闭文件

                    // 将读取的内容转为二维数组
                    QVector<QVector<QString>> dataArray2;
                    for (int i = 0; i < lines2.size(); i++) {
                        //按照逗号分开为列
                        QStringList row = lines2[i].split(",");
                        QVector<QString> arrayRow;
                        for (int j = 0; j < row.size(); j++) {
                            arrayRow.append(row[j]);
                        }
                        dataArray2.append(arrayRow);
                    }
                    QFile fii(currentPath+"/"+s[3]+".frm");
                    if (!fii.exists()) // 如果数据结构文件不存在
                    {
                        ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                        return;
                    }else{
                        int number;// 存储行数

                        if (fii.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                        {
                            QTextStream in2(&fii); // 使用QTextStream读取文件内容
                            QStringList lines2; // 存储每一行的内容

                            while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                            {
                                QString line2 = in2.readLine(); // 一行一行读取内容
                                QStringList words=line2.split(" ");

                                lines2.append(line2); // 将读取的行添加到列表中
                            }
                            fii.close(); // 关闭文件
                            for (int i = 0; i < lines2.size(); i++) {
                                QString f = lines2[i].split(" ").first();
                                if (f == targetWord) {
                                    number = i+1;  // 将行数赋值给number
                                    break;  // 找到匹配的行后，跳出循环
                                }
                            }
                            qDebug() << number;


                                    // 找到列数与number相等的列并存储下来
                                    QVector<QString> targetColumn;
                                    for (int i = 0; i < dataArray2.size(); i++) {
                                        if (dataArray2[i].size() >= number) {
                                            targetColumn.append(dataArray2[i][number - 1]);
                                        }
                                    }

                                    //输出结果
                                    for (int i = 0; i < targetColumn.size(); i++) {
                                          qDebug() <<targetColumn[i];
                                    }


                                    QVector<int> matchingRows; // 存储满足条件的行数
                                    //找到满足条件的行，并将行数存储到数组中

                                    for (int i = 0; i < dataArray2.size(); i++) {
                                        QString value = targetColumn[i];
                                        if (symbol == "=") {
                                               if (value == thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else if (symbol == "<>") {
                                               if (value != thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else if (symbol == ">") {
                                               if (value > thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else if (symbol == "<") {
                                               if (value < thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else if (symbol == ">=") {
                                               if (value >= thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else if (symbol == "<=") {
                                               if (value <= thirdWord) {
                                                   matchingRows.append(i);
                                               }
                                           } else {
                                               ui->plainTextEdit->appendPlainText("Error: the operation is wrong;");
                                           }
                                    }
                                    //打印出符合条件的行的所有值

                                    if (matchingRows.isEmpty()) {
                                        ui->plainTextEdit->appendPlainText("No matching rows found.");
                                    } else {
                                        QString output;
                                        for (int i = 0; i < matchingRows.size(); i++) {
                                            int rowIndex = matchingRows[i];
                                            QVector<QString> row = dataArray2[rowIndex];
                                            for (int j = 0; j < row.size(); j++) {
                                                QString data = row[j];
                                                data.replace("'", "");
                                                output += data + "   |   ";

                                            }
                                            output += "\n";
                                            output += "--------------\n";
                                        }
                                        ui->plainTextEdit->appendPlainText(output);
         ui->plainTextEdit->appendPlainText("This is  what you select;");
                                    }}}}}}
        else{
            QStringList result;
            QRegularExpression regex("select\\s+(.*?)\\s+from", QRegularExpression::CaseInsensitiveOption);
            //匹配select和from之间的词
            QRegularExpressionMatch match = regex.match(st);

            // 如果匹配成功，则获取匹配到的词并添加到结果列表中
            if (match.hasMatch()){
                QString word = match.captured(1);
                word.replace(",","  |  ");
                result.append(word);
                //如果匹配成功，则获取匹配到的词并添加到结果列表中
                ui->plainTextEdit->appendPlainText(word);
                      ui->plainTextEdit->appendPlainText("\n");
                        QStringList words = word.split(" ");
                  QFile fi(currentPath+"/"+s[3]+".frm");
                  if (!fi.exists()) // 如果数据结构文件不存在
                  {//报错
                      ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                      return;
                  }else{

                  QStringList linenumber;// 存储行数的数组

                  if (fi.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                  {
                      QTextStream in2(&fi); // 使用QTextStream读取文件内容
                      QStringList lines2; // 存储每一行的内容

                      while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                      {
                          QString line2 = in2.readLine(); // 一行一行读取内容
                          QStringList words=line2.split(" ");

                          lines2.append(line2); // 将读取的行添加到列表中
                      }
                      fi.close(); // 关闭文件
                      for (int i = 0; i < lines2.size(); i++) {
                          QString firstWord = lines2[i].split(" ").first();
                          //匹配字段名
                          if (word.contains(firstWord)) {
                              linenumber.append(QString::number(i + 1));
                          }
                      }
                      //存储读取到的行数
                      for (int i = 0; i < linenumber.size(); i++) {
                          qDebug() << linenumber[i];
                      }
                      QFile fil(currentPath+"/"+s[3]+".trd");
                                    if (!fil.exists()) // 如果数据文件不存在
                                    {
                                        ui->plainTextEdit->appendPlainText("This table is empty;");
                                        return;
                                    }else{
                                    if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                                    {
                                        QTextStream in2(&fil); // 使用QTextStream读取文件内容
                                        QStringList lines2; // 存储每一行的内容

                                        while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                        {
                                            QString line2 = in2.readLine(); // 一行一行读取内容
                                            lines2.append(line2);

                                        }
                                        fil.close(); // 关闭文件
                                        int rowSize = lines2.size(); // 二维数组的行数
                                        int colSize = linenumber.size(); // linenumber里存储的数的个数

                                        QVector<QVector<QString>> re(rowSize + 1, QVector<QString>(colSize));

                                        for (int row = 0; row < rowSize; row++) {
                                            QString line = lines2[row];
                                            QStringList columns = line.split(",");
                                            for (int col = 0; col < colSize; col++) {
                                                int lineNumber = linenumber[col].toInt();
                                                if (lineNumber <= columns.size()) {
                                                    re[row + 1][col] = columns[lineNumber - 1];
                                                }
                                            }
                                        }
                                        // 打印结果
                                        for (int row = 0; row < rowSize; row++) {
                                            for (int col = 0; col < colSize; col++) {
                                                qDebug() << re[row][col];
                                            }
                                        }
                                        QVector<QString> targetColumn;
                                        for (int col = 0; col < colSize; col++) {
                                         re[0][col] = words[col];
                                           qDebug() << re[0][col];
                                                                                }
                                        for (int col = 0; col < colSize; col++) {
                                            if (re[0][col] == targetWord) {
                                                  for (int row = 0; row < rowSize; row++){
                                                targetColumn.append(re[row][col]);
                                                  }
                                            }
                                        }
                                        // 打印目标列

                                        for (int i = 0; i < targetColumn.size(); i++) {
                                            qDebug() << targetColumn[i];
                                        }
                                        QVector<int> matchingRows; // 存储满足条件的行数
                                        //找到满足条件的行，并将行数存储到数组中
                                        for (int i = 0; i < rowSize; i++) {
                                                QString value = targetColumn[i];
                                                if (symbol == "=") {
                                                    if (value == thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else if (symbol == "<>") {
                                                    if (value != thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else if (symbol == ">") {
                                                    if (value > thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else if (symbol == "<") {
                                                    if (value < thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else if (symbol == ">=") {
                                                    if (value >= thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else if (symbol == "<=") {
                                                    if (value <= thirdWord) {
                                                        matchingRows.append(i);
                                                    }
                                                } else {
                                                    ui->plainTextEdit->appendPlainText("Error: the operation is wrong;");
                                                }
                                            }

                                        //打印出符合条件的行的所有值
                                        if (matchingRows.isEmpty()) {
                                            ui->plainTextEdit->appendPlainText("No matching rows found;");
                                        } else {
                                            QString output;
                                            for (int i = 0; i < rowSize; i++) {
                                                if (matchingRows.contains(i)) {
                                                    QVector<QString> row = re[i];
                                                    for (int j = 0; j < colSize; j++) {
                                                        QString data = row[j];
                                                        data.replace("'", "");
                                                        output += data + " | ";
                                                    }
                                                    output += "\n";
                                                    output += "--------------\n";
                                                }
                                            }
                                            ui->plainTextEdit->appendPlainText(output);
                                            ui->plainTextEdit->appendPlainText("This is what you select;");
                                        }

                                    }}}}}
}}
void View::complexwhere(QStringList &strList, QStringList s, QString currentPath, QString st){










}
void View::complexwhereselect(QStringList &strList, QStringList s, QString currentPath, QString st){

}
void View::complex(QStringList &strList, QStringList s, QString currentPath, QString st){
     operation op(ui);
     QString stt= strList.join(" ");
     QStringList result;
     QRegularExpression regex("select\\s+(.*?)\\s+from", QRegularExpression::CaseInsensitiveOption);
     //匹配select和from之间的词
     QRegularExpressionMatch match = regex.match(stt);

     // 如果匹配成功，则获取匹配到的词并添加到结果列表中
     if (match.hasMatch()){
         QString word = match.captured(1);
         word.replace(",","  |  ");
         result.append(word);
         //如果匹配成功，则获取匹配到的词并添加到结果列表中
         ui->plainTextEdit->appendPlainText(word);
               ui->plainTextEdit->appendPlainText("\n");
    if(s[1].compare("*")==0){
            QFile file(currentPath+"/"+s[3]+".frm");//数据定义文件的路径;
            if (!file.exists()) // 如果数据结构文件不存在
            {//报错
                ui->plainTextEdit->appendPlainText("This table has not exists,please create it first;");
                return;
            }else{

            QStringList linenumber;// 存储行数的数组

            if (file.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
            {
                QTextStream in2(&file); // 使用QTextStream读取文件内容
                QStringList lines2; // 存储每一行的内容

                while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                {
                    QString line2 = in2.readLine(); // 一行一行读取内容
                    QStringList words=line2.split(" ");

                    lines2.append(line2); // 将读取的行添加到列表中
                }
                file.close(); // 关闭文件
                for (int i = 0; i < lines2.size(); i++) {
                    QString firstWord = lines2[i].split(" ").first();
                    //匹配字段名
                    if (word.contains(firstWord)) {
                        linenumber.append(QString::number(i + 1));
                    }
                }
                //存储读取到的行数
                for (int i = 0; i < linenumber.size(); i++) {
                    qDebug() << linenumber[i];
                }
                QFile fil(currentPath+"/"+s[3]+".trd");
                              if (!fil.exists()) // 如果数据文件不存在
                              {
                                  ui->plainTextEdit->appendPlainText("This table is empty;");
                                  return;
                              }else{
                              if (fil.open(QIODevice::ReadOnly)) // 打开文件, 读取数据信息
                              {
                                  QTextStream in2(&fil); // 使用QTextStream读取文件内容
                                  QStringList lines2; // 存储每一行的内容

                                  while (!in2.atEnd()) // 逐行读取文件内容，直到文件末尾
                                  {
                                      QString line2 = in2.readLine(); // 一行一行读取内容
                                      lines2.append(line2);

                                  }
                                  fil.close(); // 关闭文件
                                  int rowSize = lines2.size(); // 二维数组的行数
                                  int colSize = linenumber.size(); // linenumber里存储的数的个数
                                  //遍历二维数组中每一行，找到列值符合linenumber存储的数值条件的数并打印出来
                                  for (int row = 0; row < rowSize; row++) {
                                      QString line = lines2[row];
                                      QStringList columns = line.split(",");

                                      for (int col = 0; col < colSize; col++) {
                                          //linenumber转化为数值
                                          int lineNumber = linenumber[col].toInt();

                                          if (lineNumber <= columns.size()) {
                                              //列索引为linenumber-1
                                              QString column = columns[lineNumber - 1];
                                              column = column.remove("'");
                                              ui->plainTextEdit->insertPlainText(column);
                                          }

                                          if (col != colSize - 1) {
                                              ui->plainTextEdit->insertPlainText("   |   ");
                                          }
                                      }

                                      ui->plainTextEdit->insertPlainText("\n-----------\n");

                                  }
                                   ui->plainTextEdit->appendPlainText(" select successfully;");

                              }
  }
  }
                     }
                    }
      }
  }

