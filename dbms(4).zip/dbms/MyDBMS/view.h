#ifndef VIEW_H
#define VIEW_H
#include <QDir>
#include <QDebug>
#include "operation.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QCoreApplication>
#include "cmd.h"
#include "ui_cmd.h"
class View
{
public:
    View(Ui::cmd *ui);
    void createview(QStringList &strList,QString currentPath);
    void showview(QStringList &strList,QString currentPath);
    void selectview(QStringList &strList,QString currentPath);
    void dropview(QStringList &strList,QString currentPath);
    void complexselect(QStringList &strList,QStringList s,QString currentPath,QString st);
    void complexwhereselect(QStringList &strList,QStringList s,QString currentPath,QString st);
    void complexwhere(QStringList &strList,QStringList s,QString currentPath,QString st);
    void complex(QStringList &strList,QStringList s,QString currentPath,QString st);
private slots:

private:
     Ui::cmd *ui;
};

#endif // VIEW_H
