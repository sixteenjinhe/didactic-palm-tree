/********************************************************************************
** Form generated from reading UI file 'cmd.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CMD_H
#define UI_CMD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cmd
{
public:
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *plainTextEdit;
    QPushButton *btnshowWindow;

    void setupUi(QWidget *cmd)
    {
        if (cmd->objectName().isEmpty())
            cmd->setObjectName(QString::fromUtf8("cmd"));
        cmd->resize(650, 389);
        verticalLayout = new QVBoxLayout(cmd);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        plainTextEdit = new QPlainTextEdit(cmd);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        plainTextEdit->setFont(font);
        plainTextEdit->setStyleSheet(QString::fromUtf8("background-image:url(:/picture/cmd.jpg)"));

        verticalLayout->addWidget(plainTextEdit);

        btnshowWindow = new QPushButton(cmd);
        btnshowWindow->setObjectName(QString::fromUtf8("btnshowWindow"));

        verticalLayout->addWidget(btnshowWindow);


        retranslateUi(cmd);

        QMetaObject::connectSlotsByName(cmd);
    } // setupUi

    void retranslateUi(QWidget *cmd)
    {
        cmd->setWindowTitle(QCoreApplication::translate("cmd", "Form", nullptr));
        btnshowWindow->setText(QCoreApplication::translate("cmd", "\344\272\244\344\272\222\347\225\214\351\235\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cmd: public Ui_cmd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CMD_H
