/********************************************************************************
** Form generated from reading UI file 'createtbwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATETBWIDGET_H
#define UI_CREATETBWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CreateTbWidget
{
public:
    QDialogButtonBox *buttonBox;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *labeltablename;
    QLineEdit *lenTablename;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelfieldname;
    QTextEdit *textEdit;

    void setupUi(QDialog *CreateTbWidget)
    {
        if (CreateTbWidget->objectName().isEmpty())
            CreateTbWidget->setObjectName(QString::fromUtf8("CreateTbWidget"));
        CreateTbWidget->resize(390, 240);
        buttonBox = new QDialogButtonBox(CreateTbWidget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(10, 200, 301, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        horizontalLayoutWidget = new QWidget(CreateTbWidget);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(30, 20, 311, 41));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        labeltablename = new QLabel(horizontalLayoutWidget);
        labeltablename->setObjectName(QString::fromUtf8("labeltablename"));

        horizontalLayout->addWidget(labeltablename);

        lenTablename = new QLineEdit(horizontalLayoutWidget);
        lenTablename->setObjectName(QString::fromUtf8("lenTablename"));

        horizontalLayout->addWidget(lenTablename);

        horizontalLayoutWidget_2 = new QWidget(CreateTbWidget);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(30, 80, 311, 80));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        labelfieldname = new QLabel(horizontalLayoutWidget_2);
        labelfieldname->setObjectName(QString::fromUtf8("labelfieldname"));

        horizontalLayout_2->addWidget(labelfieldname);

        textEdit = new QTextEdit(horizontalLayoutWidget_2);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        horizontalLayout_2->addWidget(textEdit);


        retranslateUi(CreateTbWidget);
        QObject::connect(buttonBox, SIGNAL(accepted()), CreateTbWidget, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), CreateTbWidget, SLOT(reject()));

        QMetaObject::connectSlotsByName(CreateTbWidget);
    } // setupUi

    void retranslateUi(QDialog *CreateTbWidget)
    {
        CreateTbWidget->setWindowTitle(QCoreApplication::translate("CreateTbWidget", "Dialog", nullptr));
        labeltablename->setText(QCoreApplication::translate("CreateTbWidget", "\350\241\250\345\220\215\357\274\232", nullptr));
        labelfieldname->setText(QCoreApplication::translate("CreateTbWidget", "\345\255\227\346\256\265\345\220\215\344\270\216\347\261\273\345\236\213\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CreateTbWidget: public Ui_CreateTbWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATETBWIDGET_H
