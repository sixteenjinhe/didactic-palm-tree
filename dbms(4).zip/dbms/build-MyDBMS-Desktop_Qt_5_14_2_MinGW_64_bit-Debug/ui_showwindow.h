/********************************************************************************
** Form generated from reading UI file 'showwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWWINDOW_H
#define UI_SHOWWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_showwindow
{
public:
    QHBoxLayout *horizontalLayout_9;
    QVBoxLayout *left;
    QHBoxLayout *ReturnAHelp;
    QPushButton *btnReturn;
    QPushButton *btnHelp;
    QTextEdit *leftText;
    QVBoxLayout *Db;
    QHBoxLayout *CreateDb;
    QPushButton *btnCreateDb;
    QLineEdit *lenCreateDb;
    QHBoxLayout *DropDb;
    QPushButton *btnDropDb;
    QComboBox *cbnDropDb;
    QHBoxLayout *UseDb;
    QPushButton *btnUseDb;
    QComboBox *cbnUseDb;
    QPushButton *btnRefreshDb;
    QHBoxLayout *allTb;
    QVBoxLayout *Tb;
    QPushButton *btnCreateTb;
    QHBoxLayout *DropTb;
    QPushButton *btnDropTb;
    QComboBox *cbnDropTb;
    QHBoxLayout *UseTb;
    QPushButton *btnUseTb;
    QComboBox *cbnUseTb;
    QGridLayout *gridLayout_2;
    QPushButton *btnUpdateField;
    QPushButton *btnRefershTb;
    QPushButton *btnCreateIndex;
    QPushButton *btnCreateView;
    QPushButton *btnDropView;
    QPushButton *btnDropIndex;
    QPushButton *pushButton;
    QTableWidget *tableWidget;

    void setupUi(QWidget *showwindow)
    {
        if (showwindow->objectName().isEmpty())
            showwindow->setObjectName(QString::fromUtf8("showwindow"));
        showwindow->setEnabled(true);
        showwindow->resize(1500, 1200);
        horizontalLayout_9 = new QHBoxLayout(showwindow);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        left = new QVBoxLayout();
        left->setObjectName(QString::fromUtf8("left"));
        ReturnAHelp = new QHBoxLayout();
        ReturnAHelp->setObjectName(QString::fromUtf8("ReturnAHelp"));
        ReturnAHelp->setContentsMargins(-1, -1, -1, 50);
        btnReturn = new QPushButton(showwindow);
        btnReturn->setObjectName(QString::fromUtf8("btnReturn"));
        btnReturn->setStyleSheet(QString::fromUtf8("font: 12pt \"Agency FB\";"));

        ReturnAHelp->addWidget(btnReturn);

        btnHelp = new QPushButton(showwindow);
        btnHelp->setObjectName(QString::fromUtf8("btnHelp"));
        btnHelp->setStyleSheet(QString::fromUtf8("font: 12pt \"Agency FB\";"));

        ReturnAHelp->addWidget(btnHelp);


        left->addLayout(ReturnAHelp);

        leftText = new QTextEdit(showwindow);
        leftText->setObjectName(QString::fromUtf8("leftText"));

        left->addWidget(leftText);

        Db = new QVBoxLayout();
        Db->setObjectName(QString::fromUtf8("Db"));
        Db->setContentsMargins(-1, 50, -1, 50);
        CreateDb = new QHBoxLayout();
        CreateDb->setObjectName(QString::fromUtf8("CreateDb"));
        CreateDb->setContentsMargins(-1, -1, 200, -1);
        btnCreateDb = new QPushButton(showwindow);
        btnCreateDb->setObjectName(QString::fromUtf8("btnCreateDb"));
        btnCreateDb->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(btnCreateDb->sizePolicy().hasHeightForWidth());
        btnCreateDb->setSizePolicy(sizePolicy);
        btnCreateDb->setMinimumSize(QSize(111, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Agency FB"));
        font.setPointSize(12);
        btnCreateDb->setFont(font);

        CreateDb->addWidget(btnCreateDb);

        lenCreateDb = new QLineEdit(showwindow);
        lenCreateDb->setObjectName(QString::fromUtf8("lenCreateDb"));

        CreateDb->addWidget(lenCreateDb);


        Db->addLayout(CreateDb);

        DropDb = new QHBoxLayout();
        DropDb->setObjectName(QString::fromUtf8("DropDb"));
        DropDb->setContentsMargins(-1, -1, 170, -1);
        btnDropDb = new QPushButton(showwindow);
        btnDropDb->setObjectName(QString::fromUtf8("btnDropDb"));
        btnDropDb->setFont(font);

        DropDb->addWidget(btnDropDb);

        cbnDropDb = new QComboBox(showwindow);
        cbnDropDb->setObjectName(QString::fromUtf8("cbnDropDb"));

        DropDb->addWidget(cbnDropDb);


        Db->addLayout(DropDb);

        UseDb = new QHBoxLayout();
        UseDb->setObjectName(QString::fromUtf8("UseDb"));
        btnUseDb = new QPushButton(showwindow);
        btnUseDb->setObjectName(QString::fromUtf8("btnUseDb"));
        btnUseDb->setFont(font);

        UseDb->addWidget(btnUseDb);

        cbnUseDb = new QComboBox(showwindow);
        cbnUseDb->setObjectName(QString::fromUtf8("cbnUseDb"));

        UseDb->addWidget(cbnUseDb);

        btnRefreshDb = new QPushButton(showwindow);
        btnRefreshDb->setObjectName(QString::fromUtf8("btnRefreshDb"));
        btnRefreshDb->setFont(font);

        UseDb->addWidget(btnRefreshDb);


        Db->addLayout(UseDb);


        left->addLayout(Db);

        allTb = new QHBoxLayout();
        allTb->setObjectName(QString::fromUtf8("allTb"));
        allTb->setContentsMargins(-1, 50, 0, 50);
        Tb = new QVBoxLayout();
        Tb->setObjectName(QString::fromUtf8("Tb"));
        btnCreateTb = new QPushButton(showwindow);
        btnCreateTb->setObjectName(QString::fromUtf8("btnCreateTb"));
        btnCreateTb->setFont(font);

        Tb->addWidget(btnCreateTb);

        DropTb = new QHBoxLayout();
        DropTb->setObjectName(QString::fromUtf8("DropTb"));
        btnDropTb = new QPushButton(showwindow);
        btnDropTb->setObjectName(QString::fromUtf8("btnDropTb"));
        btnDropTb->setFont(font);

        DropTb->addWidget(btnDropTb);

        cbnDropTb = new QComboBox(showwindow);
        cbnDropTb->setObjectName(QString::fromUtf8("cbnDropTb"));

        DropTb->addWidget(cbnDropTb);


        Tb->addLayout(DropTb);

        UseTb = new QHBoxLayout();
        UseTb->setObjectName(QString::fromUtf8("UseTb"));
        btnUseTb = new QPushButton(showwindow);
        btnUseTb->setObjectName(QString::fromUtf8("btnUseTb"));
        btnUseTb->setFont(font);

        UseTb->addWidget(btnUseTb);

        cbnUseTb = new QComboBox(showwindow);
        cbnUseTb->setObjectName(QString::fromUtf8("cbnUseTb"));

        UseTb->addWidget(cbnUseTb);


        Tb->addLayout(UseTb);


        allTb->addLayout(Tb);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(20, -1, 20, -1);
        btnUpdateField = new QPushButton(showwindow);
        btnUpdateField->setObjectName(QString::fromUtf8("btnUpdateField"));
        btnUpdateField->setFont(font);

        gridLayout_2->addWidget(btnUpdateField, 2, 1, 1, 1);

        btnRefershTb = new QPushButton(showwindow);
        btnRefershTb->setObjectName(QString::fromUtf8("btnRefershTb"));
        btnRefershTb->setFont(font);

        gridLayout_2->addWidget(btnRefershTb, 2, 0, 1, 1);

        btnCreateIndex = new QPushButton(showwindow);
        btnCreateIndex->setObjectName(QString::fromUtf8("btnCreateIndex"));
        btnCreateIndex->setFont(font);

        gridLayout_2->addWidget(btnCreateIndex, 1, 0, 1, 1);

        btnCreateView = new QPushButton(showwindow);
        btnCreateView->setObjectName(QString::fromUtf8("btnCreateView"));
        btnCreateView->setFont(font);

        gridLayout_2->addWidget(btnCreateView, 0, 0, 1, 1);

        btnDropView = new QPushButton(showwindow);
        btnDropView->setObjectName(QString::fromUtf8("btnDropView"));
        btnDropView->setFont(font);

        gridLayout_2->addWidget(btnDropView, 0, 1, 1, 1);

        btnDropIndex = new QPushButton(showwindow);
        btnDropIndex->setObjectName(QString::fromUtf8("btnDropIndex"));
        btnDropIndex->setFont(font);

        gridLayout_2->addWidget(btnDropIndex, 1, 1, 1, 1);


        allTb->addLayout(gridLayout_2);


        left->addLayout(allTb);


        horizontalLayout_9->addLayout(left);

        pushButton = new QPushButton(showwindow);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_9->addWidget(pushButton);

        tableWidget = new QTableWidget(showwindow);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        horizontalLayout_9->addWidget(tableWidget);


        retranslateUi(showwindow);

        QMetaObject::connectSlotsByName(showwindow);
    } // setupUi

    void retranslateUi(QWidget *showwindow)
    {
        showwindow->setWindowTitle(QCoreApplication::translate("showwindow", "Form", nullptr));
        btnReturn->setText(QCoreApplication::translate("showwindow", "\350\277\224\345\233\236", nullptr));
        btnHelp->setText(QCoreApplication::translate("showwindow", "\345\270\256\345\212\251", nullptr));
        btnCreateDb->setText(QCoreApplication::translate("showwindow", "\345\210\233\345\273\272\346\225\260\346\215\256\345\272\223", nullptr));
        btnDropDb->setText(QCoreApplication::translate("showwindow", "\345\210\240\351\231\244\346\225\260\346\215\256\345\272\223", nullptr));
        btnUseDb->setText(QCoreApplication::translate("showwindow", "\344\275\277\347\224\250\346\225\260\346\215\256\345\272\223", nullptr));
        btnRefreshDb->setText(QCoreApplication::translate("showwindow", "\345\210\267\346\226\260\346\225\260\346\215\256\345\272\223", nullptr));
        btnCreateTb->setText(QCoreApplication::translate("showwindow", "\345\210\233\345\273\272\350\241\250", nullptr));
        btnDropTb->setText(QCoreApplication::translate("showwindow", "\345\210\240\351\231\244\350\241\250", nullptr));
        btnUseTb->setText(QCoreApplication::translate("showwindow", "\351\200\211\346\213\251\350\241\250", nullptr));
        btnUpdateField->setText(QCoreApplication::translate("showwindow", "\345\255\227\346\256\265\346\233\264\346\226\260", nullptr));
        btnRefershTb->setText(QCoreApplication::translate("showwindow", "\345\210\267\346\226\260\350\241\250", nullptr));
        btnCreateIndex->setText(QCoreApplication::translate("showwindow", "\345\210\233\345\273\272\347\264\242\345\274\225", nullptr));
        btnCreateView->setText(QCoreApplication::translate("showwindow", "\345\210\233\345\273\272\350\247\206\345\233\276", nullptr));
        btnDropView->setText(QCoreApplication::translate("showwindow", "\345\210\240\351\231\244\350\247\206\345\233\276", nullptr));
        btnDropIndex->setText(QCoreApplication::translate("showwindow", "\345\210\240\351\231\244\347\264\242\345\274\225", nullptr));
        pushButton->setText(QCoreApplication::translate("showwindow", "apply", nullptr));
    } // retranslateUi

};

namespace Ui {
    class showwindow: public Ui_showwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWWINDOW_H
