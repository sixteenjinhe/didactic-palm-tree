#ifndef CMD_H
#define CMD_H

#include <QWidget>

namespace Ui {
class cmd;
}

class cmd : public QWidget
{
    Q_OBJECT

public:
    explicit cmd(QWidget *parent = nullptr);
    ~cmd();
    void split(QString str);
    QString currentPath;//用户选择的数据库地址路径

    void setUsername(const QString &username);  // 添加设置用户名的方法
    QString getUsername() const;                // 添加获取用户名的方法

private slots:
    void on_plainTextEdit_textChanged();

private:
    Ui::cmd *ui;
    QString username;  // 新增私有成员变量来存储用户名
};

#endif // CMD_H
