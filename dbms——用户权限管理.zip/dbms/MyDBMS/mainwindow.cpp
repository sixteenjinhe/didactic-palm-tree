//#include "mainwindow.h"
//#include "ui_mainwindow.h"
//#include "cmd.h"

//MainWindow::MainWindow(QWidget *parent)
//    : QMainWindow(parent)
//    , ui(new Ui::MainWindow)
//{
//    ui->setupUi(this);
//    this->setStyleSheet("QMainWindow {background-image:url(D:/dbms/picture/login.jpg)}");

//}

//MainWindow::~MainWindow()
//{
//    delete ui;
//}




//void MainWindow::on_pushButton_clicked()
//{
//    FILE * froot;//存放root密码的文件
//    char c;
//    QString str;
//    QString strTxtEdt = ui->textEdit->toPlainText();//获取textedit中的内容
//    froot = fopen ("D:/dbms/File/root.txt", "r");//打开文件
//    if (froot == NULL)
//        qDebug()<<"Error opening root file"; // 打开失败
//      else//打开成功
//      {
//        while ((c = fgetc(froot)) != EOF)// 获取字符
//        {
//          str.push_back(c);//追加到字符串中，str字符串存储root密码
//        }
//        //qDebug()<<str;
//        fclose (froot); // 关闭root文件
//      }
//    if(str.compare(strTxtEdt)==0){//密码输入正确
//        //界面跳转
//        this->close();//隐藏父界面
//        cmd *cmdwindow=new cmd();
//        cmdwindow->show();//显示子界面
//      }
//    else
//    {
//        //显示密码输错的提示信息
//    }
//}
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "cmd.h"
#include "user.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setStyleSheet("QMainWindow {background-image:url(D:/dbms/picture/login.jpg)}");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    FILE *fusers; // 文件指针，用于存储用户名和密码
    char line[256]; // 用于读取文件中的每行数据
    bool found = false; // 标记是否找到匹配的用户名和密码

//    bool hasrange = user::hasPermission("lyx","all privileges","*","*");
//    if(hasrange){
//        qDebug()<<"有权限";
//    }else qDebug() << "无权限";

    QString username = ui->lineEdit_username->text(); // 获取输入的用户名
    QString password = ui->lineEdit_password->text(); // 获取输入的密码
    QString combined = username + ":" + password; // 将用户名和密码组合成一行

    fusers = fopen("D:/dbms/File/users.txt", "r"); // 打开存储用户数据的文件
    if (fusers == NULL) {
        qDebug() << "Error opening user file"; // 文件打开失败
    } else {
        while (fgets(line, sizeof(line), fusers)) { // 读取文件中的每一行
            if (QString(line).trimmed() == combined.trimmed()) { // 比较去除尾部空白的字符串
                found = true;
                break;
            }
        }
        fclose(fusers); // 关闭文件
    }

    if (found) {
        this->close(); // 隐藏当前窗口
        cmd *cmdwindow = new cmd();
        cmdwindow->setUsername(username);//传入当前用户名
        cmdwindow->show(); // 显示主命令窗口
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误，请重新输入！"); // 弹出错误提示
        ui->lineEdit_username->clear(); // 清空用户名输入框
        ui->lineEdit_password->clear(); // 清空密码输入框
        ui->lineEdit_username->setFocus(); // 将光标定位到用户名输入框
    }
}

