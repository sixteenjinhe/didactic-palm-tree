#include "user.h"
#include <iostream>
#include "operation.h"
#include "cmd.h"
#include "ui_cmd.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QRegularExpression>
#include <QDebug>
#include <QString>
#include <QDate>
#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QStringList>
#include <QJsonArray>

user::user(Ui::cmd *ui)
    : ui(ui)
{

}

QString user::username; // 静态成员变量的定义和初始化

void user::setUsername(const QString &newUsername) {
    user::username = newUsername;  // 设置静态成员变量
}

QString user::getUsername() {
    return user::username;  // 返回静态成员变量
}

//创建用户函数
void user::createUser(QString &str){
    qDebug() << "创建用户";
    qDebug() << str;
    //对获取的str句子进行解析——正则表达式
    // 使用正则表达式匹配用户名和密码
    QRegularExpression re("create user '([^']+)'@'localhost' identified by '([^']+)'");//默认在主机
    QRegularExpressionMatch match = re.match(str);
    qDebug() << match;
    if (match.hasMatch()) {
        QString username = match.captured(1);
        QString password = match.captured(2);

        // 打开文件
        QFile file("D:/dbms/File/users.txt");
        if (file.open(QIODevice::WriteOnly | QIODevice::Append)) {
            QTextStream out(&file);
            out << username << ":" << password << "\n";  // 写入用户名和密码
            file.close();
            qDebug() << "用户" << username << "已添加到文件";
        } else {
            qDebug() << "无法打开文件进行写入";
        }
    } else {
        qDebug() << "错误的创建用户语句";
    }
}

//删除用户函数
void user::dropUser(QString &str){
    qDebug() << "删除用户";
    qDebug() << str;
    qDebug() << "username" << getUsername();
    // 使用正则表达式来提取用户名
    QRegularExpression re("drop user '([^']+)'@'localhost'");
    QRegularExpressionMatch match = re.match(str);

    if (match.hasMatch()) {
        QString username = match.captured(1);

        QFile file("D:/dbms/File/users.txt");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qDebug() << "无法打开文件进行读取";
            return;
        }

        QString contents;
        QTextStream in(&file);
        bool found = false;

        // 读取文件内容，并排除包含特定用户名的行
        while (!in.atEnd()) {
            QString line = in.readLine();
            if (!line.startsWith(username + ":")) {
                contents += line + "\n";
            } else {
                found = true;
            }
        }
        file.close();

        // 如果找到并删除了用户，重新写入更新后的内容
        if (found) {
            if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                qDebug() << "无法打开文件进行写入";
                return;
            }

            QTextStream out(&file);
            out << contents;
            file.close();
            qDebug() << "用户" << username << "已从文件中删除";
        } else {
            qDebug() << "未找到用户" << username;
        }
    } else {
        qDebug() << "错误的删除用户语句";
    }
}

void user::grantPrivileges(QString &str){
    QRegularExpression grantSentence("grant ([\\w\\s,]+) on ([^\\.]+)\\.([^\\s]+) to '([^']+)'@'localhost'");//均默认为主机

    QRegularExpressionMatch match;

    // 检测“授予特定权限到特定数据库的特定表”的模式
    match = grantSentence.match(str);
    if (match.hasMatch()) {
        QString privileges = match.captured(1);//all privileges或特定权限->转换成权限列表
        QString database = match.captured(2);//* 或 指定数据库名
        QString table = match.captured(3);//* 或 指定表名
        QString username = match.captured(4);//指定用户名
        qDebug() << "p" << privileges << database << table << username;
        if(isUsernameExist(username)){
            //分类别判断
            if(privileges.compare("all privileges")==0){//全权限
                if(database.compare("*")==0){//全数据库，即全表
                    saveOrUpdatePrivileges(username,"*","*",{"all privileges"});
                }else{//指定数据库
                    if(isDatabaseExist(database)){//数据库存在
                        if(table.compare("*")==0){//全表
                            saveOrUpdatePrivileges(username,database,"*",{"all privileges"});
                        }else {//指定表
                            if(isTableExist(database,table)){
                                saveOrUpdatePrivileges(username,database,table,{"all privileges"});
                            }else qDebug() << "数据库中不存在该表。";
                        }
                    }else qDebug() << "数据库不存在。";
                }
            }else {//特定权限
                QStringList privilegesList = privileges.split(',');//按照逗号分隔权限
                if(isGrantRight(privilegesList)){//权限合理
                    if(database.compare("*")==0){//全数据库，即全表
                        saveOrUpdatePrivileges(username,"*","*",privilegesList);
                    }else{//指定数据库
                        if(isDatabaseExist(database)){//数据库存在
                            if(table.compare("*")==0){//全表
                                saveOrUpdatePrivileges(username,database,"*",privilegesList);
                            }else {//指定表
                                if(isTableExist(database,table)){
                                    saveOrUpdatePrivileges(username,database,table,privilegesList);
                                }else qDebug() << "数据库中不存在该表。";
                            }
                        }else qDebug() << "数据库不存在。";
                    }
                }else qDebug() << "授予权限类型不合法.";
            }
        }else qDebug() << "用户不存在";
    }else qDebug() << "授权语句错误。";
}

// 定义一个函数，用于保存或更新用户的权限设置到 JSON 文件
void user::saveOrUpdatePrivileges(const QString &username, const QString &database, const QString &table, const QStringList &privilegesList) {
    // 构建保存权限的 JSON 文件的完整路径
    QString fileName = "D:/dbms/File/" + username + "_privileges.json";

    // 创建 QFile 对象以操作文件
    QFile file(fileName);
    QJsonObject userObject;  // JSON 对象，用来存储最终的用户数据

    // 尝试打开现有的 JSON 文件以读取内容
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray jsonData = file.readAll();  // 读取文件中的所有数据
        file.close();  // 读取完成后关闭文件

        // 将读取的数据转换为 JSON 文档
        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
        // 检查 JSON 文档是否有效且为对象格式
        if (!doc.isNull() && doc.isObject()) {
            userObject = doc.object();  // 获取 JSON 对象
        }
    }

    // 获取 "privileges" 键对应的数组，存放所有权限数据
    QJsonArray privilegesArray = userObject["privileges"].toArray();
    bool globalPrivilegeExists = false;
    bool specificDatabaseGlobalPrivilegeExists = false;
    QJsonArray newArray;

    // 首先检查是否存在全局权限或针对要更新数据库的全表权限——存在全局权限/存在当前数据库的全表权限
    for (const QJsonValue &value : privilegesArray) {
        QJsonObject privilege = value.toObject();
        if (privilege["database"].toString() == "*" && privilege["table"].toString() == "*") {
            globalPrivilegeExists = true; // 全数据库全表权限存在
            break;
        }
        if (privilege["database"].toString() == database && privilege["table"].toString() == "*") {
            specificDatabaseGlobalPrivilegeExists = true; // 当前数据库的全表权限存在
        }
    }

    if (!globalPrivilegeExists && (!specificDatabaseGlobalPrivilegeExists || table != "*")) {
        bool found = false;

        // 遍历权限数组，更新或添加新权限
        for (int i = 0; i < privilegesArray.size(); ++i) {
            QJsonObject privilege = privilegesArray[i].toObject();
            if (privilege["database"].toString() == database && privilege["table"].toString() == table) {
                QSet<QString> currentRightsSet;
                QJsonArray currentRights = privilege["rights"].toArray();
                for (const QJsonValue &value : currentRights) {
                    currentRightsSet.insert(value.toString());
                }

                // 将新权限添加到集合中，确保不会重复
                for (const QString &priv : privilegesList) {
                    currentRightsSet.insert(priv);
                }

                // 转换回 QJsonArray
                QJsonArray updatedRights;
                for (const QString &right : currentRightsSet) {
                    updatedRights.append(right);
                }

                privilege["rights"] = updatedRights;
                privilegesArray[i] = privilege;
                found = true;
                break;
            }
        }

        if (!found) {
            // 创建新的权限对象
            QJsonObject newPrivilege;
            newPrivilege["database"] = database;
            newPrivilege["table"] = table;
            newPrivilege["rights"] = QJsonArray::fromStringList(privilegesList);
            privilegesArray.append(newPrivilege);
        }

        // 更新 JSON 对象的内容
        userObject["username"] = username;
        userObject["privileges"] = privilegesArray;

        // 尝试重新打开文件以写入更新后的数据
        if (file.open(QIODevice::WriteOnly)) {
            QJsonDocument document(userObject);
            file.write(document.toJson());
            file.close();
            qDebug() << "Permissions updated and saved to" << fileName;
        } else {
            qDebug() << "Failed to open file for writing.";
        }
    } else {
        qDebug() << "Global or specific database global privilege exists. No need to add specific privileges.";
    }
    refreshPrivileges(username);//更新文件扩展全权限
    mergeAndDeduplicatePrivileges(username);//去除重复权限
    qDebug()<< "刷新成功！";
}

void user::revokePrivileges(QString &str) {
    qDebug()<<"撤销权限开始";
    QRegularExpression revokeSentence("revoke ([\\w\\s,]+) on ([^\\.]+)\\.([^\\s]+) from '([^']+)'@'localhost'");

    QRegularExpressionMatch match = revokeSentence.match(str);
    if (match.hasMatch()) {
        QString privileges = match.captured(1); // all privileges或特定权限
        QString database = match.captured(2); // * 或 指定数据库名
        QString table = match.captured(3); // * 或 指定表名
        QString username = match.captured(4); // 指定用户名

        qDebug() << "Privileges to revoke:" << privileges << "from Database:" << database << "Table:" << table << "Username:" << username;

        if(isUsernameExist(username)){
            // 检查要撤销的权限范围
            if(privileges.compare("all privileges") == 0) {
                if(database.compare("*") == 0) {
                    // 撤销全数据库全表的所有权限
                    removePrivileges(username, "*", "*",{"all privileges"});
                } else {
                    // 撤销特定数据库的所有权限
                    removePrivileges(username, database, "*",{"all privileges"});
                }
            } else {
                // 撤销特定表的特定权限
                QStringList privilegesList = privileges.split(',');
                if(isGrantRight(privilegesList)) {
                    removePrivileges(username, database, table, privilegesList);
                } else {
                    qDebug() << "指定的权限类型不合法。";
                }
            }
        } else {
            qDebug() << "用户不存在。";
        }
    } else {
        qDebug() << "撤销权限语句格式错误。";
    }
}

void user::removePrivileges(const QString& username, const QString& database, const QString& table, const QStringList& privilegesList) {
    QString fileName = "D:/dbms/File/" + username + "_privileges.json";
    QFile file(fileName);
    if (!file.open(QIODevice::ReadWrite)) {
        qDebug() << "无法打开权限文件进行写入";
        return;
    }

    QByteArray jsonData = file.readAll();
    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    QJsonObject userObject = doc.object();
    QJsonArray privilegesArray = userObject["privileges"].toArray();
    QJsonArray newArray;
    bool found = false;

    // 如果是全数据库全表全权限删除
    if (database == "*" && table == "*" && privilegesList.contains("all privileges")) {
        found = true;  // 标记找到相应权限，将执行完全清空
    } else {
        foreach (const QJsonValue &value, privilegesArray) {
            QJsonObject privilege = value.toObject();
            QString db = privilege["database"].toString();
            QString tbl = privilege["table"].toString();
            QJsonArray rights = privilege["rights"].toArray();

            // 检查并处理指定数据库全表全权限
            if (db == database && table == "*" && privilegesList.contains("all privileges")) {
                found = true;  // 标记找到相应权限，将执行指定数据库清空
                continue;  // 不将当前权限块添加回新数组
            }

            // 如果非全删除操作，正常检查并修改权限
            if (!(db == database && table == tbl && privilegesList.contains("all privileges"))) {
                QJsonArray newRights;
                foreach (const QJsonValue &right, rights) {
                    if (!privilegesList.contains(right.toString()) || !(db == database && tbl == table)) {
                        newRights.append(right);
                    } else {
                        found = true;
                    }
                }
                if (!newRights.isEmpty()) {
                    privilege["rights"] = newRights;
                    newArray.append(privilege);
                }
            }
        }
    }

    // 完全删除所有权限或指定数据库的所有权限
    if (!found) {
        qDebug() << "No matching privileges found for removal or full removal executed.";
    } else {
        // 仅当不是全删除时，才更新为新数组
        if (!(database == "*" && table == "*" && privilegesList.contains("all privileges"))) {
            userObject["privileges"] = newArray;
        } else {
            userObject["privileges"] = QJsonArray();  // 清空所有权限
        }
    }

    // 保存更改到文件
    file.resize(0);  // 清空文件
    doc.setObject(userObject);
    file.write(doc.toJson());
    file.close();
    qDebug() << "Privileges updated successfully.";
}

//处理全数据库全表全权限的刷新，处理指定数据库全表全权限的刷新
void user::refreshPrivileges(const QString &username) {
    QString fileName = "D:/dbms/File/" + username + "_privileges.json";
    QFile file(fileName);
    QJsonObject userObject;

    // 打开并读取 JSON 文件
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray jsonData = file.readAll();
        file.close();
        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
        if (!doc.isNull() && doc.isObject()) {
            userObject = doc.object();
        }
    }

    QJsonArray privilegesArray = userObject["privileges"].toArray();
    QJsonArray newArray;

    // 检查全数据库全表权限
    QSet<QString> databasesToRefresh;
    bool globalPrivilegeRefresh = false;
    bool globaltablePrivilegeRefresh = false;

    for (int i = 0; i < privilegesArray.size(); ++i) {
        QJsonObject privilege = privilegesArray[i].toObject();
        if (privilege["rights"].toArray().contains("all privileges")) {
            if (privilege["database"].toString() == "*" && privilege["table"].toString() == "*") {
                globalPrivilegeRefresh = true;
                continue; // 删除全数据库全权限块
            } else if (privilege["table"].toString() == "*") {
                databasesToRefresh.insert(privilege["database"].toString());
                globaltablePrivilegeRefresh = true;
                continue; // 删除全表全权限块
            }
        }
        newArray.append(privilege); // 保留其他权限
    }

    if (globalPrivilegeRefresh) {//存在全数据库全表全权限
        // 为每个数据库的每个表创建权限块
        QStringList databaseNames;  //存储数据库名称
        QString filePath = "D:/dbms/File/database.txt";// 设置文件路径
        loadNames(databaseNames,filePath);//填充数据库名数组
        for (const QString &name : databaseNames) {
            QStringList tableNames;//存储对应数据库下表名
            QString filePath = "D:/dbms/File/" + name + "/table.txt";//设置文件路径
            loadNames(tableNames,filePath);//填充该数据库下表名数组
            for (const QString &tablename : tableNames){
                QJsonObject newPrivilege{{"database", name}, {"table", tablename}, {"rights", QJsonArray::fromStringList({"all privileges"})}};
                newArray.append(newPrivilege);
            }
        }
    } else if(globaltablePrivilegeRefresh){//存在指定数据库全表全权限
        // 为指定数据库的每个表创建权限块
        foreach (const QString &db, databasesToRefresh) {
            QStringList tableNames;//存储对应数据库下表名
            QString filePath = "D:/dbms/File/" + db + "/table.txt";//设置文件路径
            loadNames(tableNames,filePath);//填充该数据库下表名数组
            for (const QString &tablename : tableNames){
                QJsonObject newPrivilege{{"database", db}, {"table", tablename}, {"rights", QJsonArray::fromStringList({"all privileges"})}};
                newArray.append(newPrivilege);
            }
        }
    }

    // 重新写入更新后的权限
    userObject["privileges"] = newArray;
    if (file.open(QIODevice::WriteOnly)) {
        QJsonDocument document(userObject);
        file.resize(0); // 先清空文件
        file.write(document.toJson());
        file.close();
        qDebug() << "Privileges refreshed and saved to" << fileName;
    } else {
        qDebug() << "Failed to open file for writing.";
    }
}

//去重更新
void user::mergeAndDeduplicatePrivileges(const QString& username) {
    QString fileName = "D:/dbms/File/" + username + "_privileges.json";
    QFile file(fileName);
    QJsonObject userObject;

    // 打开并读取 JSON 文件
    if (!file.open(QIODevice::ReadOnly)) {
        qDebug() << "Failed to open file for reading";
        return;
    }

    QByteArray jsonData = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    if (!doc.isObject()) {
        qDebug() << "JSON document is not an object";
        return;
    }

    userObject = doc.object();
    QJsonArray privilegesArray = userObject["privileges"].toArray();
    QMap<QPair<QString, QString>, QSet<QString>> privilegeMap;

    // 遍历现有权限，合并重复的数据库和表权限
    for (const QJsonValue& value : privilegesArray) {
        QJsonObject privilege = value.toObject();
        QString database = privilege["database"].toString();
        QString table = privilege["table"].toString();
        QJsonArray rights = privilege["rights"].toArray();

        QPair<QString, QString> key(database, table);
        QSet<QString>& rightsSet = privilegeMap[key];

        for (const QJsonValue& right : rights) {
            rightsSet.insert(right.toString());
        }
    }

    // 创建新的权限数组
    QJsonArray newPrivilegesArray;
    for (auto it = privilegeMap.begin(); it != privilegeMap.end(); ++it) {
        QJsonObject newPrivilege;
        newPrivilege["database"] = it.key().first;
        newPrivilege["table"] = it.key().second;
        QJsonArray newRightsArray;
        for (const QString& right : it.value()) {
            newRightsArray.append(right);
        }
        newPrivilege["rights"] = newRightsArray;
        newPrivilegesArray.append(newPrivilege);
    }

    // 更新JSON对象并写入文件
    userObject["privileges"] = newPrivilegesArray;
    if (!file.open(QIODevice::WriteOnly)) {
        qDebug() << "Failed to open file for writing";
        return;
    }

    doc.setObject(userObject);
    file.write(doc.toJson());
    file.close();
    qDebug() << "Privileges have been merged and deduplicated";
}

//1. 如果存在全数据库全权限则只需保留这个；
//2. 如果存在某数据库全表全权限则去除该数据库其他表以及其权限块；
//3. 如果存在某数据库某表的权限块内容为全权限，则只需保留这个全权限，即ALL PRIVILEGES
//void user::refreshPrivileges(const QString &username) {//部分刷新
//    QString fileName = "D:/dbms/File/" + username + "_privileges.json";
//    QFile file(fileName);
//    QJsonObject userObject;

//    // 打开并读取 JSON 文件
//    if (file.open(QIODevice::ReadOnly)) {
//        QByteArray jsonData = file.readAll();
//        file.close();
//        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
//        if (!doc.isNull() && doc.isObject()) {
//            userObject = doc.object();
//        }
//    }

//    QJsonArray privilegesArray = userObject["privileges"].toArray();
//    QJsonArray newArray;
//    bool globalDatabasePrivilegeExists = false;

//    // 首先检查是否存在全数据库全权限
//    for (const QJsonValue &value : privilegesArray) {
//        QJsonObject privilege = value.toObject();
//        if (privilege["database"].toString() == "*" && privilege["table"].toString() == "*" &&
//            privilege["rights"].toArray().contains("all privileges")) {
//            globalDatabasePrivilegeExists = true;
//            newArray.append(privilege); // 保留全数据库全权限
//            break;
//        }
//    }

//    // 如果不存在全数据库全权限，则处理其他情况
//    if (!globalDatabasePrivilegeExists) {
//        QSet<QString> databasesWithGlobalTablePrivileges;

//        // 确定哪些数据库有全表全权限
//        for (const QJsonValue &value : privilegesArray) {
//            QJsonObject privilege = value.toObject();
//            if (privilege["table"].toString() == "*" && privilege["rights"].toArray().contains("all privileges")) {
//                databasesWithGlobalTablePrivileges.insert(privilege["database"].toString());
//            }
//        }

//        // 移除冗余权限并更新数组
//        for (const QJsonValue &value : privilegesArray) {
//            QJsonObject privilege = value.toObject();
//            if (databasesWithGlobalTablePrivileges.contains(privilege["database"].toString())) {
//                if (privilege["table"].toString() == "*") {
//                    newArray.append(privilege); // 保留全表全权限
//                }
//                // 跳过该数据库的其他表权限
//            } else {
//                newArray.append(privilege); // 不受影响的权限
//            }
//        }
//    }

//    // 重新写入更新后的权限
//    userObject["privileges"] = newArray;

//    if (file.open(QIODevice::WriteOnly)) {
//        QJsonDocument document(userObject);
//        file.write(document.toJson());
//        file.close();
//        qDebug() << "Privileges refreshed and saved to" << fileName;
//    } else {
//        qDebug() << "Failed to open file for writing.";
//    }
//}

// 函数定义：读取数据库或表名称并填充传入的QStringList
void user::loadNames(QStringList& Names, QString& filePath) {
    QFile file(filePath);  // 使用传入的文件路径创建QFile对象

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);  // 创建用于读取的文本流

        while (!in.atEnd()) {
            QString line = in.readLine().trimmed();  // 读取一行并去掉首尾的空格
            if (!line.isEmpty()) {
                Names.append(line);  // 如果行不是空的，添加到QStringList
            }
        }
        file.close();  // 读取完成后关闭文件
    } else {
        qDebug() << "Failed to open the file:" << filePath;
    }
}

bool user::isUsernameExist(QString &username){
    QFile file("D:/dbms/File/users.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream in(&file);
    QString line;
    while (!in.atEnd()) {
        line = in.readLine();
        // 文件中每行存储格式为 "username:password"
        QStringList parts = line.split(':');
        if (parts.size() > 0 && parts[0] == username) {
            file.close();
            return true;  // 找到用户名
        }
    }
    file.close();
    return false;  // 未找到用户
}

bool user::isDatabaseExist(QString &databasename){
    QFile file("D:/dbms/File/database.txt"); // 确保路径是正确的，或者使用相对路径
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open database list file for reading.";
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();  // 读取一行并去除两端的空白字符
        if (line == databasename) {
            file.close();
            return true;  // 找到匹配的数据库名
        }
    }

    file.close();
    return false;  // 文件中不存在该数据库名
}

bool user::isTableExist(QString &databasename,QString &tablename){
    QString filePath = "D:/dbms/File/" + databasename + "/table.txt";  // 构建文件路径
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open the table list file:" << filePath;
        return false;  // 文件打开失败，直接返回 false
    }

    QTextStream in(&file);
    QString line;
    while (!in.atEnd()) {
        line = in.readLine().trimmed();  // 读取一行，并去除两端空白字符
        if (line == tablename) {
            file.close();
            return true;  // 找到匹配的表名，返回 true
        }
    }

    file.close();
    return false;  // 遍历完文件未找到表名，返回 false
}

bool user::isGrantRight(QStringList &privilegesList){
    //循环判断列表每个元素是否合理
    // 定义合法的MySQL权限类型集合
    const QSet<QString> validPrivileges = {
        "SELECT", "INSERT", "UPDATE", "DELETE",
        "CREATE", "DROP", "LOCK TABLES", "CREATE VIEW",
        "EVENT", "TRIGGER", "SHOW VIEW", "ALTER",
        "REFERENCES", "INDEX", "EXECUTE", "CREATE TEMPORARY TABLES",
        "ALTER ROUTINE", "CREATE ROUTINE", "GRANT OPTION"
    };

    // 循环判断列表中的每个元素是否合法
    foreach (const QString &privilege, privilegesList) {
        if (!validPrivileges.contains(privilege.trimmed().toUpper())) {//忽略大小写和空格
            qDebug() << "Invalid privilege:" << privilege;
            return false; // 发现非法权限，返回false
        }
    }

    return true; // 所有权限都合法，返回true
}

bool user::hasPermission(const QString& username, const QString& permissionType, const QString& databaseName, const QString& tableName) {
    qDebug()<<"检查权限";
    QString fileName = "D:/dbms/File/" + username + "_privileges.json";
    QFile file(fileName);
    QJsonObject userObject;

    // 打开并读取 JSON 文件
    if (file.open(QIODevice::ReadOnly)) {
        QByteArray jsonData = file.readAll();
        file.close();
        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
        if (!doc.isNull() && doc.isObject()) {
            userObject = doc.object();
        }
    }

    QJsonArray privilegesArray = userObject["privileges"].toArray();

    // 遍历权限数组
    foreach (const QJsonValue &value, privilegesArray) {
        QJsonObject privilege = value.toObject();
        QString db = privilege["database"].toString();
        QString tbl = privilege["table"].toString();
        QJsonArray rights = privilege["rights"].toArray();

        //根据传入情况判断
        if(databaseName == "*"){
            //判断全数据库全表的属性，为all或包含所给
            if(db == "*" && tbl == "*" && (rights.contains(permissionType) || rights.contains("all privileges"))){//必须有全权限
                return true;
            }
        }else {//指定数据库
            if(db == databaseName){//检索到指定数据库的权限
                if(db == "*" && tbl == "*" && (rights.contains(permissionType) || rights.contains("all privileges"))){//有全权限先返回
                    return true;
                }else{
                    if(tableName == "*"){//要求全表
                        //判断是否有全表属性，为all或包含所给
                        if(tbl == "*" && (rights.contains(permissionType) || rights.contains("all privileges"))){
                            return true;
                        }
                    }else {//提供指定表
                        if(tbl == tableName && (rights.contains(permissionType) || rights.contains("all privileges"))){
                            return true;
                        }else if(tbl == "*" && (rights.contains(permissionType) || rights.contains("all privileges"))){//具有全表权限
                            return true;
                        }
                    }
                }
            }
        }
    }

    return false; // 如果没有找到匹配的权限
}

void user::showGrants(QString &str){
    //正则表达式
    QRegularExpression showGrantSentence("show grants for '([^']+)'@'localhost'");
    QRegularExpressionMatch match;

    match = showGrantSentence.match(str);
    if(match.hasMatch()) {
        QString username = match.captured(1);//获取要展示的用户名
        QString fileName = "D:/dbms/File/" + username + "_privileges.json";
        QFile file(fileName);

        if (!file.open(QIODevice::ReadOnly)) {
            qDebug() << "无法打开文件：" << fileName;
            return;
        }

        QByteArray jsonData = file.readAll();
        file.close();

        QJsonDocument doc = QJsonDocument::fromJson(jsonData);
        if (!doc.isObject()) {
            qDebug() << "JSON 数据格式错误";
            return;
        }

        QJsonObject userObject = doc.object();
        QJsonArray privilegesArray = userObject["privileges"].toArray();

        qDebug() << "Grants for '" << username << "'@'localhost':";
        for (const QJsonValue &value : privilegesArray) {
            QJsonObject privilege = value.toObject();
            QString database = privilege["database"].toString();
            QString table = privilege["table"].toString();
            QJsonArray rights = privilege["rights"].toArray();

            QStringList rightsList;
            for (const QJsonValue &right : rights) {
                rightsList.append(right.toString());
            }

            QString rightsStr = rightsList.join(", ");  // 将权限列表转换为字符串
            qDebug().noquote() << QString("GRANT %1 ON %2.%3 TO '%4'@'localhost'")
                                    .arg(rightsStr, database, table, username);
        }
    }else qDebug() << "展示权限语句错误。";
}
