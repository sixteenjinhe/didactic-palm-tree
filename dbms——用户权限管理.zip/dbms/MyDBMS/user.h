#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
#include <map>
#include <QDir>
#include <QDebug>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QUrl>
#include <QCoreApplication>
#include "cmd.h"
#include "ui_cmd.h"
class user
{
private:
    Ui::cmd *ui;


    QString password;   // 用户密码
    int role;               // 用户角色ID

public:
    user(Ui::cmd *ui);
    static QString username;   // 用户名
    void createUser(QString &str);
    void dropUser(QString &str);
    void grantPrivileges(QString &str);
    bool isUsernameExist(QString &username);
    bool isDatabaseExist(QString &databasename);
    bool isTableExist(QString &databasename,QString &tablename);
    bool isGrantRight(QStringList &privilegesList);//判断权限列表类型合理
    void loadNames(QStringList& Names, QString& filePath);
    void saveOrUpdatePrivileges(const QString &username, const QString &database, const QString &table, const QStringList &privilegesList);
    void revokePrivileges(QString &str);
    void removePrivileges(const QString& username, const QString& database, const QString& table, const QStringList& privilegesList);
    void refreshPrivileges(const QString &username);
    void mergeAndDeduplicatePrivileges(const QString& username);
    static bool hasPermission(const QString& username, const QString& permissionType, const QString& databaseName, const QString& tableName);
    void showGrants(QString &str);
    static void setUsername(const QString &newUsername);  // 设置用户名
    static QString getUsername();                   // 获取用户名




};

#endif // USER_H
